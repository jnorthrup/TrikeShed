#!/usr/bin/env bash
set -uo pipefail
source /workspace/.trikeshed-cloud/activate.sh
premise_proof=/workspace/library-files/reviewed-taxonomy-proof-path-ui-proof
export PROOF_ROOT=${1:?fresh prepared archive case required}
export PROOF_SNAPSHOT=${2:?immutable snapshot required}
premise_classes=${3:?fresh observer directory required}
: "${EXPECTED_SOURCE_HEAD:?pinned final source required}"
: "${EXPECTED_MAIN_SHA256:?pinned final JAR hash required}"
export EXPECTED_SOURCE_HEAD EXPECTED_MAIN_SHA256
export OUTBOUND_DENY_RECEIPT="$PROOF_ROOT/outbound-deny-profile.json"
premise_cp=$(cat "$PROOF_SNAPSHOT/classpath.txt")
timeout 780s python "$premise_proof/deny-egress.py" -- java -Xmx768m -cp "$premise_classes:$premise_cp" proof.reviewedpremisepaths.FixtureKt
premise_exit=$?
printf '%s\n' "$premise_exit" > "$PROOF_ROOT/fixture-attempt1.exit"
exit "$premise_exit"
