#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
premise_proof=/workspace/library-files/reviewed-taxonomy-proof-path-ui-proof
premise_snapshot=${1:?immutable snapshot required}
premise_output=${2:?fresh observer class directory required}
premise_cp=$(cat "$premise_snapshot/classpath.txt")
premise_compiler=$(rg --files --no-ignore /workspace/.trikeshed-cloud/gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.21 | rg '\.jar$' | head -n 1)
mkdir "$premise_output"
java -Xmx768m -cp "$premise_compiler:$premise_cp" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 25 -classpath "$premise_cp" -d "$premise_output" "$premise_proof/Fixture.kt" "$premise_proof/Reopen.kt"
