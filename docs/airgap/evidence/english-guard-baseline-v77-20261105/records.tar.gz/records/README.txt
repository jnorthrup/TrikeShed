Genuine local English syntax baseline — retained observations, not legal gold

Frozen source0219223a3846887fe283b93598942de332214cd2; actual main JAR SHA256
 d0a8133b10e4b18e1bd4076c1440688ad94a2eeb2bbcdefe743f4759ace75636
Snapshot /workspace/library-files/english-corpus-topics-v76-proof/snapshot.
All120classpathJARs and29installedmodulefiles were freshly hashed before and
again after execution against frozen-inputs.json;119dependency hashes match the
root snapshot. No production overlay, internal/friend access, source edits,
Git ref changes, Gradle build, browser, or production build-output write occurred.

Actual execution
Two Java25.0.4 processes used -Xmx3g -XX:ActiveProcessorCount=2 and taskset0,1,
with180second external process caps. TRIKESHED_AIRGAP=1 stayed active. Reader was
the unmodified DocumentEnglishWire default CoreNlpRuntime(Profile.SYNTAX), behind
its publicly registered ModuleRoute callback. This is actual production-owner
route execution, not an HTTP socket/browser/native UI proof. Observer compilation
against only the120frozenJARclasspath succeeded;4observerclasses in the isolated
proof.guardbaseline namespace were appended. No borg.trikeshed classes were
compiled or replaced. Compilation/launch scripts and logs are preserved.

Local module was /workspace/TrikeShed/utils/subvm/corenlp, with unchanged installed
CoreNLP4.6.0+models and syntax-v1 annotators tokenize,ssplit,pos,lemma,depparse,ner;
threads=1. Manifest CID sha256:3eef3e5150b437e61ce88523c11dbe3c6a75515784ca6327475560695e1dafcd.
Actual processor JAR SHA256277e42b16199e22e023d6b53335b2d633cecb740e0ebc9bedb9d36baf6db5431.
Every receipt records this metadata, profile, configuration, full Enhanced++
index:copy identities and source/parser-input normalization identities. No module
download/upgrade, model/provider endpoint, miner, review owner, or live bag was
constructed. OS outbound network denial and peak native/RSS memory were not
measured; model egress prohibition and the Java heap/CPU settings are the actual
observed controls. Do not describe this as a sealed OS sandbox or total3GiB RSS.

18source-retained inspections returned200:17invented guard challenges and the
one unchanged105byte corpus S12 source. Total996UTF8bytes,23sentences,201tokens,
201nodes,203dependencies,48lexicalmarkers. All0copiedvertices: actual copy handling
NOT_EXERCISED, including the gapping challenge. These are observed parser outputs,
not 18passed comprehension cases or an accuracy score. Exact per-case source
rows/requests/responses, source bytes and canonical CAS receipt readbacks remain
in attempt-first-G01/cases/G01 and attempt-remaining/cases/{G02..G17,S12}.
Rawretained CAS files also remain in each attempt/runtime, separate from exports.
G17 retained its emoji/CRLF full source and inspected only UTF16[4,59).

Preserved failures
The first external compilation attempt had observer import/name/bracket errors,
archived under compile-attempt1. They were corrected only in this external
observer. The first launch could not find /usr/bin/time, before Java executed;
launch-attempt1 preserves it. Bash time was used subsequently.
The first real process successfully parsed, retained and source-verified G01
(14.309s route;15.156s process), then exited1 on the observer's incorrect
ctx.lcncRunners.isEmpty assertion. Attaching the English owner intentionally
registers4read-only query/corpus/pattern runners. The immediately preceding
zero automatic/review intake, Rete facts and blackboard mutation assertion passed.
Its actual failure.txt/cleanup/logs/source/classes and validG01receipt are retained.
Only the observer invariant changed to compare unchanged attached runner identities.
The remaining17process exited0 (17.401s), recording all zero intake/Rete/blackboard
and absent bag/kifbank/provider/miner/reviewowner invariants;4attached read-only
runners remained the same instances. No semantic or production guard changed.
Do not label the first process green or erase its observer failure.
A recorded-data audit initially compared file:/ vs file:/// URI spellings as
strings; audit-attempt1 preserves that audit-only failure. URI path normalization
corrected it without changing actual records. audit02.stdout reports finalPASS.

Actual source-backed observations to guide the next small slice
G01/G02 show pay advcl:if/unless approves and the exact mark edge, including
fronted unless. G03 attaches matrix not by advmod to pay and conditionIssue is
null; G04 attaches guard not to approve and conditionIssue is NEGATED. G05 keeps
the two not occurrences on different governors. G06/G09 are MULTIPLE;
G07/G08 COORDINATED; G10 PASSIVE; G11 MODAL; G12/G14/G15 UNSUPPORTED; G17 NEGATED.
These diagnostics are existing pure NormClauses.conditionIssue outputs on the
reconstructed retained observations, not a second parser invocation.
G07's actual coordination is surprising: pay has advcl:if to approves AND Trustee,
with approves conj:or Trustee. Do not replace Trustee with an expected consents
head or treat enhanced duplicate attachment as two independently supported guards.
G13's quoted clause actually received record advcl:if approves, and approves has
advcl:without acting. Existing conditionIssue returns NEGATED from that subtree.
It must remain NEGATED in this baseline; it does not prove quote protection. A
future narrow attachment profile needs an explicit quoted-content gate rather
than treating an advcl edge or null conditionIssue as legal operative scope.
G15 reports only as guard advmod plus mark if; this must not become plain if.
G16 keeps two sentence namespaces; no cross-sentence attachment was manufactured.

S12 and next NARS slice
Exact original/extracted CID sha256:2d357e82bb8d7c51254eb88f162eaa5ba1dca5d2049ebd75f8b2ed58a166f3ac,
full[0,105),5sentences20tokens20edges. Inspection CID
sha256:b8d43e44fd90ed082538dee097f2eaad7f2eddc718baf5148afb5762da9e53f0.
Existing pure NlpcoreAxiomatics.recognize(snapshot.parsed,extractedTextCid.value)
actually returned5candidates and4distinct rule CIDs: ALPHA→BETA twice, BETA→GAMMA,
EPSILON→GAMMA,EPSILON→DELTA. Fixed structural weight0.9 and+900/-0evidence are
not parser probabilities or independent support. Both ALPHA→BETA occurrences
share sourceCID and ruleCID. Preserve exact surface identifiers: GAMMA's actual
lemma/tag differ between occurrences (gamma/NN versus GAMMA/NNP). Do not join
entities by lowercased noun lemma or by subjectCID==sourceCID. No NAL runtime,
attention, inference, rule admission, global facts, evidence promotion, or bag
training was executed. QuadStore.project/query is also UNOBSERVED here: graph
URIs are actual snapshot.graph values, not a claim that a quad query ran.

Rechecking retained data only
  python3 /workspace/library-files/english-guard-attachment-v76-baseline/audit.py
No JVM/parser is invoked by this audit. It independently decodes/reencodes actual
canonical CBOR and matches response fields, hashes source/receipt/frozenJAR/module
bytes, checks source/current-row metadata and exact UTF16 token/node/marker/quote
spans, full dependency endpoints, counts, graphIDs, existing recognizer output
and same-source duplicate rule identity. audit-result.json contains full actual
attachment edges and exact record paths. Checks do not grade pre-parse hypotheses.
No unsanitized path/secret publication is authorized by this external baseline.
