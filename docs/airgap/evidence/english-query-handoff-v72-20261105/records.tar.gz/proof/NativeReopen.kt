package proof.englishhandoffreopen

import borg.trikeshed.job.*
import borg.trikeshed.lib.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import kotlinx.coroutines.runBlocking
import java.io.File

/** Read exact retained bytes only after the fixture's live owners have drained. */
fun main() = runBlocking {
    val root = File(requireNotNull(java.lang.System.getenv("PROOF_ROOT")))
    val snapshot = File(requireNotNull(java.lang.System.getenv("PROOF_SNAPSHOT")))
    val finalJar = File(snapshot, "main.jar").toURI().toURL().toString()
    check(EnglishObservationGraph::class.java.protectionDomain.codeSource.location.toString() == finalJar)
    check(PackCasStore::class.java.protectionDomain.codeSource.location.toString() == finalJar)
    check(File(root, "fixture-attempt1.exit").readText().trim() == "0")
    val cleanup = reifyStrict(File(root, "cleanup.json").readText()) as Map<*, *>
    for (field in s_["allSupervisorsCompleted", "listenerStopped", "modulesDrained", "reviewClosed", "booksDrained", "scopesDrained"].view) check(cleanup[field] == true)
    check((cleanup["freshInspectionPosts"] as Number).toInt() == 0)
    check((cleanup["authoredRunPosts"] as Number).toInt() == 3 && (cleanup["queryCalls"] as Number).toInt() == 3)
    val evidence = reifyStrict(File(root, "fixture-evidence.json").readText()) as Map<*, *>
    check(evidence["sourceCurrent"] == true)
    for (entry in evidence["originalArchiveHeadsAndSource"] as List<*>) {
        val row = entry as Map<*, *>; val bytes = File(root, "runtime/" + row["path"]).readBytes()
        check(ContentId.of(bytes).value == row["sha256"] && bytes.size == (row["bytes"] as Number).toInt())
    }
    val requests = (evidence["requests"] as List<*>).map { it as Map<*, *> }
    val runs = requests.filter { it["method"] == "POST" && it["path"] == "/api/lcnc/run" }.map {
        check((it["status"] as Number).toInt() == 200)
        it["response"] as Map<*, *>
    }
    check(runs.size == 3 && runs.map { it["programCid"] }.distinct().size == 1 && runs.map { it["runId"] }.distinct().size == 3)
    val setup = reifyStrict(File(root, "setup.json").readText()) as Map<*, *>
    val receipt = ContentId(setup["inspectionCid"] as String)
    val cas = PackCasStore(JvmFileOperations(), File(root, "runtime/cas").absolutePath)
    try {
        val observation = EnglishObservationGraph.read(cas, receipt)
        check(observation.source.originalCid.value == (setup["selection"] as Map<*, *>)["cid"])
        check(reifyStrict(jsonOf(observation.sourceSnapshots?.map { it.toMap() })) == evidence["retainedSourceSnapshots"])
        val blocks = evidence["retainedReadbacks"] as List<*>
        val retained = mutableListOf<Map<String, Any?>>()
        for (entry in blocks) {
            val row = entry as Map<*, *>; val cid = ContentId(row["cid"] as String); val kind = row["encoding"] as String
            val bytes = requireNotNull(cas.getBounded(cid, 8 * 1024 * 1024))
            check(ContentId.of(bytes) == cid && File(root, "cas-readbacks/${cid.hex}.$kind").readBytes().contentEquals(bytes))
            retained.add(_m["cid" j cid.value, "bytes" j bytes.size, "encoding" j kind, "unchangedAfterClose" j true])
        }
        val ids = retained.map { it["cid"] }.toSet()
        val checkedRuns = runs.map { response ->
            val decoded = mutableMapOf<String, Map<*, *>>()
            for (field in s_["receiptCid", "programCid", "invocationsCid"].view) {
                val cid = ContentId(response[field] as String); check(cid.value in ids)
                val bytes = requireNotNull(cas.getBounded(cid, 4 * 1024 * 1024)); check(ContentId.of(bytes) == cid)
                decoded[field] = reifyStrict(bytes.decodeToString(throwOnInvalidSequence = true)) as Map<*, *>
            }
            val run = decoded.getValue("receiptCid")["lcncRun"] as Map<*, *>
            val ledger = decoded.getValue("invocationsCid")
            check(run["runId"] == response["runId"] && run["programCid"] == response["programCid"] && run["status"] == "completed")
            check(ledger["runId"] == response["runId"] && ledger["programCid"] == response["programCid"])
            check(ledger["observationSchema"] == "lcnc-observations/1" && (ledger["observations"] as List<*>).isNotEmpty())
            _m["runId" j run["runId"], "receiptCid" j response["receiptCid"], "programCid" j response["programCid"], "invocationsCid" j response["invocationsCid"], "observationSchema" j ledger["observationSchema"], "observationSummary" j ledger["observationSummary"]]
        }
        val report = _m["result" j "PASS", "scope" j "Production PackCasStore and EnglishObservationGraph bounded retained verification after all live owners close; three actual completed same-program runs and original current observation, no parser or new execution in this reader.",
            "frozenSourceHead" j File(snapshot, "source-head.txt").readText().trim(), "finalJar" j finalJar, "inspectionCid" j receipt.value, "originalSourceCid" j observation.source.originalCid.value, "recordedSourceSnapshots" j observation.sourceSnapshots?.map { it.toMap() }, "retainedBlocks" j retained, "runs" j checkedRuns,
            "EnglishObservationGraphCodeSource" j EnglishObservationGraph::class.java.protectionDomain.codeSource.location.toString()]
        File(root, "native-reopened-cas.json").writeText(jsonOf(report)); println(jsonOf(report))
    } finally { cas.close() }
}
