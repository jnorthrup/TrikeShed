package proof.reviewedproofqueryreopen

import borg.trikeshed.job.*
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.narsese.DocumentAppendLog
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import kotlinx.coroutines.*
import java.io.File

fun byteState(bytes: ByteArray): Map<String, Any?> = _m["bytes" j bytes.size, "sha256" j ContentId.of(bytes).hex]

/** Reads immutable carrier/source and actual CRC-framed review WAL after all live owners closed. */
fun main() = runBlocking {
    val root = File(requireNotNull(java.lang.System.getenv("PROOF_ROOT")))
    val snapshot = File(requireNotNull(java.lang.System.getenv("PROOF_SNAPSHOT")))
    val finalJar = File(snapshot, "main.jar").toURI().toURL().toString()
    check(File(snapshot, "source-head.txt").readText().trim() == requireNotNull(java.lang.System.getenv("EXPECTED_SOURCE_HEAD")))
    check(ContentId.of(File(snapshot, "main.jar").readBytes()).hex == requireNotNull(java.lang.System.getenv("EXPECTED_MAIN_SHA256")))
    val cleanup = reifyStrict(File(root, "cleanup.json").readText()) as Map<*, *>
    val startup = reifyStrict(File(root, "startup-evidence.json").readText()) as Map<*, *>
    val writerPid = cleanup["writerPid"] as String
    check(writerPid == startup["writerPid"] && writerPid != ProcessHandle.current().pid().toString())
    for (key in s_["reviewWireDrainedAndClosed", "booksDrained", "scopesDrained", "allSupervisorsCompleted", "executorTerminated", "casCloseReturned", "listenerStopped"].view) check(cleanup[key] == true)
    check((cleanup["remainingChildren"] as Number).toInt() == 0)
    check(EnglishTaxonomyCarrier::class.java.protectionDomain.codeSource.location.toString() == finalJar)
    check(DocumentAppendLog::class.java.protectionDomain.codeSource.location.toString() == finalJar)
    check(PackCasStore::class.java.protectionDomain.codeSource.location.toString() == finalJar)
    check(File(root, "fixture-attempt1.exit").readText().trim() == "0")
    val result = reifyStrict(File(root, "browser-result.json").readText()) as Map<*, *>; check(result["result"] == "PASS")
    val observed = result["observed"] as Map<*, *>; val prepared = observed["prepared"] as Map<*, *>
    val approved = observed["approved"] as Map<*, *>; val inspection = observed["inspection"] as Map<*, *>
    val frozen = (observed["frozen"] as Map<*, *>)["snapshot"] as Map<*, *>
    @Suppress("UNCHECKED_CAST") val frozenSelections = (frozen["selections"] as List<*>).map { it as Map<*, *> }
    for (name in s_["supported", "unknown", "reflexive", "restored"].view) {
        val response = observed[name] as Map<*, *>
        ReviewedTaxonomyProofPaths.validate(response["plan"] as Map<*, *>, frozenSelections)
    }
    val queryChecks = mutableListOf<Map<String, Any?>>()
    for (raw in observed["evidenceQueries"] as List<*>) {
        val record = raw as Map<*, *>; val expected = observed[if (record["label"] == "restored-before-source-amendment") "restored" else "supported"] as Map<*, *>
        val proof = ((expected["plan"] as Map<*, *>)["proofs"] as List<*>).first() as Map<*, *>
        val starter = ReviewedTaxonomyQueryView.starter(expected, proof["nodeId"] as String, record["english"] == true)
        val response = record["response"] as Map<*, *>
        val answer = ReviewedTaxonomyQueryView.answer(expected, response, starter)
        queryChecks.add(_m["label" j record["label"], "graph" j answer.value["graph"], "persistence" j answer.value["persistence"],
            "query" j answer.value["query"], "physicalSource" j answer.value["physicalSource"], "provenance" j answer.value["provenance"],
            "rows" j answer.rows.map { _m["ordinal" j it.ordinal, "sourceNodeId" j it.sourceNodeId, "bindings" j it.bindings] }])
    }
    val sourceMutation = observed["mutation"] as Map<*, *>
    val amended = sourceMutation["after"] as Map<*, *>
    val project = amended["project"] as String; val id = amended["id"] as String
    val mirror = File(root, "runtime/files/$project/$id").readBytes()
    check(ContentId.of(mirror).value == amended["cid"] && amended["cid"] != inspection["originalCid"])
    check(java.util.Base64.getDecoder().decode(sourceMutation["sourceMirrorAfterBase64"] as String).contentEquals(mirror))
    check(java.util.Base64.getDecoder().decode(sourceMutation["sourceHeadAfterBase64"] as String)
        .contentEquals(File(root, "runtime/project-couch/$project/HEAD").readBytes()))
    val files = JvmFileOperations(); val cas = PackCasStore(files, File(root, "runtime/cas").absolutePath)
    val docs = File(root, "runtime/owner/documents"); val wal = File(docs, "review.wal"); val before = wal.readBytes()
    val frames = mutableListOf<Map<String, Any?>>()
    val originalPrefix = File(root, "input-cas-prefix.bin").readBytes()
    val livePack = File(root, "runtime/cas/pack").readBytes()
    check(livePack.size >= originalPrefix.size && livePack.copyOfRange(0, originalPrefix.size).contentEquals(originalPrefix))
    var finalReport: Map<String, Any?>? = null
    try {
        val carrier = EnglishTaxonomyCarrier.verify(cas, ContentId(prepared["receiptCid"] as String))
        check(reifyStrict(jsonOf(EnglishTaxonomyCarrier.projection(carrier))) == prepared)
        check(carrier.built.snapshot.receiptCid.value == inspection["receiptCid"])
        check(carrier.built.snapshot.source.text.encodeToByteArray().contentEquals(File(root, "source.txt").readBytes()))
        val reread = EnglishObservationGraph.read(cas, ContentId(inspection["receiptCid"] as String))
        check(reread.sourceSnapshots?.size == 1)
        withContext(files) {
            val log = DocumentAppendLog.open(wal.absolutePath, docs.absolutePath)
            try { log.replay { sequence, payload ->
                val cid = ContentId(payload.decodeToString(throwOnInvalidSequence = true))
                val bytes = requireNotNull(cas.getBounded(cid, 1024 * 1024)); check(ContentId.of(bytes) == cid)
                val event = CanonicalCbor.decodeMapBounded(bytes, 1024 * 1024, 16, 100_000)
                check(event["snapshotCid"] == approved["snapshotCid"] && event["kind"] == "curation-review-event")
                frames.add(_m["sequence" j sequence, "eventCid" j cid.value, "event" j event])
            } } finally { log.close() }
        }
        check(frames.size == 2 && (frames.last()["event"] as Map<*, *>)["action"] == "approve")
        check(frames.last()["eventCid"] == approved["decisionCid"])
        check(wal.readBytes().contentEquals(before))
        File(root, "review.wal").writeBytes(before)
        val approvedWal = (observed["afterApproval"] as Map<*, *>)["reviewWal"] as Map<*, *>
        check(java.util.Base64.getDecoder().decode(approvedWal["base64"] as String).contentEquals(before))
        val exported = (result["evidence"] as Map<*, *>)["retainedReadbacks"] as List<*>
        val readbacks = mutableListOf<Map<String, Any?>>()
        for (raw in exported) {
            val row = raw as Map<*, *>; val cid = ContentId(row["cid"] as String)
            val bytes = requireNotNull(cas.getBounded(cid, 8 * 1024 * 1024)); check(ContentId.of(bytes) == cid)
            val suffix = if (row["encoding"] == "canonical-cbor") "cbor" else "txt"
            check(File(root, "cas-readbacks/${cid.hex}.$suffix").readBytes().contentEquals(bytes))
            readbacks.add(byteState(bytes) + _m["cid" j cid.value, "encoding" j row["encoding"]])
        }
        val report = _m["result" j "PASS", "writerPid" j writerPid, "readerPid" j ProcessHandle.current().pid().toString(),
            "readbacks" j readbacks, "queryChecks" j queryChecks, "walBeforeOpen" j byteState(before), "casPackBeforeRead" j byteState(livePack),
            "sourceMirror" j byteState(mirror), "sourceHead" j byteState(File(root, "runtime/project-couch/$project/HEAD").readBytes()), "scope" j "Exact closed PackCasStore, production EnglishTaxonomyCarrier verifier and CRC review WAL replay. No parser, new review decision, query, native execution or world admission. The current source was deliberately amended after the earlier conditional support result.",
            "translationCid" j carrier.declarationCid.value, "derivedKifCid" j carrier.record.source.originalCid.value,
            "receiptCid" j carrier.receiptCid.value, "inspectionCid" j reread.receiptCid.value,
            "sourceSnapshots" j reread.sourceSnapshots?.map { it.toMap() }, "canonicalProjectionEqualsActualUiPreview" j true,
            "retainedArtifactsUnchanged" j exported.size, "reviewWalBytes" j before.size, "reviewWalUnchangedByReplay" j true,
            "reviewWalCid" j ContentId.of(before).value, "reviewFrames" j frames,
            "currentSourceMatchesOldInspection" j false, "currentnessScope" j "Actual amendment and stale409 recorded separately after native proof reads; immutable old receipts remain retained, not current source",
            "codeSources" j _m["EnglishTaxonomyCarrier" j EnglishTaxonomyCarrier::class.java.protectionDomain.codeSource.location.toString(),
                "DocumentAppendLog" j DocumentAppendLog::class.java.protectionDomain.codeSource.location.toString()]]
        finalReport = report
    } finally { cas.close() }
    val walAfter = wal.readBytes(); val packAfter = File(root, "runtime/cas/pack").readBytes()
    check(walAfter.contentEquals(before) && packAfter.contentEquals(livePack))
    val closed = requireNotNull(finalReport) + _m["walAfterClose" j byteState(walAfter), "casPackAfterClose" j byteState(packAfter),
        "readerCasCloseReturned" j true, "readerWalCloseReturned" j true]
    File(root, "reopened-cas-wal.json").writeText(jsonOf(closed)); println(jsonOf(closed))
}
