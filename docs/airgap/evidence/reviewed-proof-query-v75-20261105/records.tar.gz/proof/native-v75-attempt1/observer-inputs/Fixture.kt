package proof.reviewedproofqueryui

import borg.trikeshed.couch.*
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.graal.ConfixBlackboard
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.lcnc.*
import borg.trikeshed.job.*
import borg.trikeshed.lib.*
import borg.trikeshed.memory.*
import borg.trikeshed.modelmux.*
import borg.trikeshed.module.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import com.sun.net.httpserver.HttpServer

class ObserverMarker

/** Synthetic native UI pilot. All retained-reader, review, source, translation and support routes are production owners; no fresh parser. */
fun main() = runBlocking {
    val out = File(requireNotNull(java.lang.System.getenv("PROOF_ROOT")))
    val snapshot = File(requireNotNull(java.lang.System.getenv("PROOF_SNAPSHOT")))
    val root = File(out, "runtime").apply { require(isDirectory) }
    val setup = reifyStrict(File(out, "setup.json").readText()) as Map<*, *>
    val selection = setup["selection"] as Map<*, *>
    val project = selection["project"] as String; val id = selection["id"] as String
    val source = File(root, "files/$project/$id").readBytes(); check(source.size == 41)
    val text = source.decodeToString(throwOnInvalidSequence = true)
    check(text == "Tenant is a Person. A Person is an Agent.")
    val sourceCid = ContentId.of(source); val inspectionCid = ContentId(setup["inspectionCid"] as String)
    val token = "synthetic-reviewed-proof-query-analyst"; val reviewerId = "synthetic:proof-query-pilot"
    val emptyHome = File(out, "empty-subvm").apply { mkdir(); check(listFiles().orEmpty().isEmpty()) }
    java.lang.System.setProperty(GuestModules.HOME_PROPERTY, emptyHome.absolutePath)
    check(GuestModules.installed().isEmpty() && GuestModules.mounted().isEmpty())
    val files = JvmFileOperations(); val cas = PackCasStore(files, File(root, "cas").absolutePath)
    val store = CouchStoreFactory.casBacked(cas); val gateway = CouchAttachmentGateway(store, cas)
    val registry = ProjectDbRegistry("primary")
    val scopes = ProjectScopes(files, gateway, CouchIndexBridge(gateway, MemoryIndexLayer(MemoryStore(cas, store))), cas, null,
        projectDbs = registry, ledgerFile = File(root, "projects.tsv"), filesRoot = File(root, "files"))
    scopes.remountLedger()
    val automatic = AtomicInteger(); val intake = AtomicInteger()
    scopes.onDocument = { _, _, _ -> automatic.incrementAndGet() }; scopes.onExplicitDocument = { _, _ -> intake.incrementAndGet() }
    scopes.onTextForReview = { intake.incrementAndGet() }
    val miner = ProjectMiner(registry, scopes, cas, null, File(root, "files"))
    val corpus = JvmProjectCorpus(registry, scopes, miner)
    val owner = SupervisorJob(coroutineContext[Job]); val scope = CoroutineScope(Dispatchers.IO + owner + files)
    val state = File(root, "owner").apply { mkdirs() }
    val ctx = ModuleContext(Couch("reviewed-proof-query-native-ui", store, cas), ReteNetwork(), ReteProductionRegistry(), null, null,
        ConfixBlackboard.empty(), cas, gateway, ModuleRouteRegistry(), scope, { 123L }, state)
    val docs = File(state, "documents").apply { mkdirs() }
    File(docs, "review-principals.json").writeText(jsonOf(_m["principals" j _l[_m[
        "tokenSha256" j ContentId.of(token.encodeToByteArray()).hex, "id" j reviewerId, "synthetic" j true]]]))
    val books = ConstellationNodes(stateDir = ctx.stateDir, blackboard = ctx.blackboard, files = files, scope = scope, cas = cas)
    val reviewWire = DocumentReviewWire.open(ctx, corpus, books, nativeHorn = null)
    val boardBaseline = ctx.blackboard.snapshot().values.toMap()
    val baselineCid = ContentId.of(CanonicalCbor.encodeMap(boardBaseline)).value
    val wal = File(docs, "review.wal"); val baselineWal = wal.length()
    val modelCalls = AtomicInteger()
    val brain = object : BrainClient(endpointSpecs = emptyList()) {
        override suspend fun chat(messages: List<Pair<String, String>>, maxTokens: Int, temperature: Double, contextId: String?): String { modelCalls.incrementAndGet(); error("No provider configured") }
        override suspend fun chat(options: BrainChatOptions, messages: List<Pair<String, String>>, contextId: String?): Pair<String, String> { modelCalls.incrementAndGet(); error("No provider configured") }
        override suspend fun chatExact(options: BrainChatOptions, messages: List<Pair<String, String>>, contextId: String?): Pair<String, String> { modelCalls.incrementAndGet(); error("No provider configured") }
        override suspend fun chatSeat(messages: List<Pair<String, String>>, maxTokens: Int, temperature: Double, contextId: String?, preferredModel: String?, timeoutMs: Long): Pair<String, String> { modelCalls.incrementAndGet(); error("No provider configured") }
    }
    check(brain.modelMux().listModels().isEmpty() && !brain.hasEndpoints())
    val patch = PatchWire(brain, scopes, attachments = gateway, corpus = corpus, miner = miner)
    val uploads = ProjectDbWire(registry, scopes)
    val inspectPosts = AtomicInteger(); val inspections = java.util.Collections.synchronizedList(mutableListOf<Map<*, *>>())
    val calls = java.util.Collections.synchronizedList(mutableListOf<Map<String, Any?>>())
    val retained = java.util.Collections.synchronizedSet(mutableSetOf(sourceCid.value, inspectionCid.value))
    val mutation = AtomicReference<Map<String, Any?>?>()
    val finish = CountDownLatch(1); val executor = Executors.newFixedThreadPool(8)
    fun network(): Map<String, Any?> {
        fun denied(action: () -> Unit): String = try { action(); error("Outgoing call unexpectedly succeeded") }
            catch (e: SocketException) { check(e.message.orEmpty().contains("Permission denied", true)); e.message.orEmpty() }
        return _m["tcpConnect" j denied { Socket().use { it.connect(InetSocketAddress("127.0.0.1", 9), 1000) } },
            "udpSend" j denied { DatagramSocket().use { it.send(DatagramPacket(byteArrayOf(1), 1, InetAddress.getByName("127.0.0.1"), 9)) } }]
    }
    val denyBefore = network()
    fun reviewWal(): Map<String, Any?> {
        val bytes = if (wal.isFile) wal.readBytes() else ByteArray(0)
        return _m["bytes" j bytes.size, "sha256" j ContentId.of(bytes).hex,
            "base64" j java.util.Base64.getEncoder().encodeToString(bytes)]
    }
    fun casPack(): Map<String, Any?> {
        val bytes = File(root, "cas/pack").readBytes()
        return _m["bytes" j bytes.size, "sha256" j ContentId.of(bytes).hex]
    }
    fun counters(): Map<String, Any?> = _m["inspectionPosts" j inspectPosts.get(), "inspectionResponses" j inspections.size,
        "parserObservability" j "Actual empty SDK, zero fresh Inspect POSTs, unmodified default retained reader and stored actual CoreNLP4.6 receipt; no parser reauthentication claim",
        "guestModules" j _m["installed" j GuestModules.installed(), "mounted" j GuestModules.mounted()],
        "walBytes" j wal.length(), "baselineWalBytes" j baselineWal, "reviewWal" j reviewWal(), "casPack" j casPack(),
        "modelCalls" j modelCalls.get(), "configuredModelCount" j brain.modelMux().listModels().size,
        "automaticIntake" j automatic.get(), "reviewIntakeCalls" j intake.get(),
        "analysisReteFacts" j runBlocking { ctx.rete.snapshot().size },
        "blackboardBaselineCid" j baselineCid, "blackboardCurrentCid" j ContentId.of(CanonicalCbor.encodeMap(ctx.blackboard.snapshot().values)).value,
        "blackboardUnchangedFromReadinessBaseline" j (ctx.blackboard.snapshot().values == boardBaseline),
        "readinessBaselineEntries" j boardBaseline.keys.sorted(), "beliefBagPresent" j (ctx.beliefBag != null), "kifBankPresent" j (ctx.kifBank != null), "narsRetePresent" j (ctx.narsRete != null),
        "globalQuadStoreBinding" j "not-configured-in-ModuleContext; optional endpoint constructs request-local SparqlSurface(projection.store)",
        "nativeHornConfigured" j false, "syntheticReviewer" j true]
    val codeSources = _m["DocumentReviewWire" j DocumentReviewWire::class.java.protectionDomain.codeSource.location.toString(),
        "DocumentEnglishWire" j DocumentEnglishWire::class.java.protectionDomain.codeSource.location.toString(),
        "EnglishTaxonomyCarrier" j EnglishTaxonomyCarrier::class.java.protectionDomain.codeSource.location.toString(),
        "ReviewedTaxonomyPlan" j ReviewedTaxonomyPlan::class.java.protectionDomain.codeSource.location.toString(),
        "CurationReview" j CurationReview::class.java.protectionDomain.codeSource.location.toString(),
        "DocumentAppendLog" j DocumentAppendLog::class.java.protectionDomain.codeSource.location.toString(),
        "PackCasStore" j PackCasStore::class.java.protectionDomain.codeSource.location.toString(),
        "ReviewedTaxonomyProofPaths" j ReviewedTaxonomyProofPaths::class.java.protectionDomain.codeSource.location.toString(),
        "ReviewedTaxonomyProofGraph" j ReviewedTaxonomyProofGraph::class.java.protectionDomain.codeSource.location.toString(),
        "ReviewedTaxonomyQueryView" j ReviewedTaxonomyQueryView::class.java.protectionDomain.codeSource.location.toString(),
        "SparqlSurface" j SparqlSurface::class.java.protectionDomain.codeSource.location.toString(),
        "QuadStore" j QuadStore::class.java.protectionDomain.codeSource.location.toString(),
        "SparqlWire" j SparqlWire::class.java.protectionDomain.codeSource.location.toString(),
        "ProjectScopes" j ProjectScopes::class.java.protectionDomain.codeSource.location.toString(),
        "EnglishObservationGraph" j EnglishObservationGraph::class.java.protectionDomain.codeSource.location.toString(),
        "ConstellationNodes" j ConstellationNodes::class.java.protectionDomain.codeSource.location.toString()]
    val frozenHead = File(snapshot, "source-head.txt").readText().trim()
    check(frozenHead == requireNotNull(java.lang.System.getenv("EXPECTED_SOURCE_HEAD")))
    val frozenJar = File(snapshot, "main.jar")
    check(ContentId.of(frozenJar.readBytes()).hex == requireNotNull(java.lang.System.getenv("EXPECTED_MAIN_SHA256")))
    check(codeSources.values.all { it == frozenJar.toURI().toURL().toString() })
    val frozenClasspath = File(snapshot, "classpath.txt").readText().trim().split(':').map { File(it).canonicalFile }
    check(frozenClasspath.size == 120 && frozenClasspath.first() == frozenJar.canonicalFile && frozenClasspath.all { it.isFile && it.extension == "jar" })
    val dependencies = (reifyStrict(File(snapshot, "sha256.json").readText()) as Map<*, *>)["dependencies"] as Map<*, *>
    check(dependencies.size == 119)
    for (jar in frozenClasspath.drop(1)) check(ContentId.of(jar.readBytes()).hex == dependencies[jar.path])
    val observer = File(ObserverMarker::class.java.protectionDomain.codeSource.location.toURI()).canonicalFile
    check(requireNotNull(java.lang.System.getProperty("java.class.path")).split(':').map { File(it).canonicalFile } == _l[observer] + frozenClasspath)
    val recorded = EnglishObservationGraph.read(cas, inspectionCid)
    check(recorded.source.originalCid == sourceCid && recorded.source.text == text)
    for (row in requireNotNull(recorded.sourceSnapshots)) check(corpus.document(row.project, row.id) == row)
    File(out, "source.txt").writeBytes(source)
    File(out, "startup-evidence.json").writeText(jsonOf(_m["writerPid" j ProcessHandle.current().pid().toString(), "frozenSourceHead" j frozenHead, "mainSha256" j ContentId.of(frozenJar.readBytes()).hex, "finalJar" j frozenJar.toURI().toURL().toString(),
        "classCodeSources" j codeSources, "inspectionCid" j inspectionCid.value, "sourceSnapshots" j recorded.sourceSnapshots?.map { it.toMap() },
        "guestModules" j _m["installed" j GuestModules.installed(), "mounted" j GuestModules.mounted()], "emptySubvmHome" j emptyHome.absolutePath]))
    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 8); server.executor = executor
    server.createContext("/") { ex ->
        try {
            val path = ex.requestURI.rawPath; val target = ex.requestURI.toASCIIString(); val method = ex.requestMethod
            val raw = ex.requestBody.readBytes(); val body = raw.decodeToString()
            val headers = buildString {
                append("$method $target HTTP/1.1\r\n")
                for ((name, values) in ex.requestHeaders) for (value in values) append("$name: $value\r\n")
                append("\r\n"); append(body)
            }
            var status = 200; var mime = "application/json; charset=utf-8"
            val response = when {
                path == "/_fixture/meta" -> jsonOf(_m["project" j project, "source" j _m["id" j id, "text" j text, "cid" j sourceCid.value],
                    "inspectionCid" j inspectionCid.value, "sourceRevision" j recorded.sourceSnapshots?.single()?.toMap(),
                    "guestModules" j _m["installed" j GuestModules.installed(), "mounted" j GuestModules.mounted()],
                    "parserScope" j "Stored actual CoreNLP4.6 metadata, not new execution or producer authentication", "reviewerToken" j token, "reviewerId" j reviewerId,
                    "credentialScope" j "Public deterministic fixture-only synthetic principal, not a real user credential or human legal approval", "classCodeSources" j codeSources]).encodeToByteArray()
                path == "/_fixture/counters" -> jsonOf(counters()).encodeToByteArray()
                path == "/_fixture/mutate" -> {
                    val before = runBlocking { requireNotNull(corpus.document(project, id)) }
                    val headFile = File(root, "project-couch/$project/HEAD")
                    val headBefore = headFile.readBytes(); val mirrorBefore = File(root, "files/$project/$id").readBytes()
                    scopes.uploadPut(project, id, (text + "\nSource amended after synthetic review.").encodeToByteArray(), null, manualIntake = true)
                    val after = runBlocking { requireNotNull(corpus.document(project, id)) }
                    check(before.cid != after.cid && before.rev != after.rev && before.seq != after.seq)
                    val rows = _m["before" j before.toMap(), "after" j after.toMap(),
                        "sourceHeadBeforeBase64" j java.util.Base64.getEncoder().encodeToString(headBefore),
                        "sourceHeadAfterBase64" j java.util.Base64.getEncoder().encodeToString(headFile.readBytes()),
                        "sourceMirrorBeforeBase64" j java.util.Base64.getEncoder().encodeToString(mirrorBefore),
                        "sourceMirrorAfterBase64" j java.util.Base64.getEncoder().encodeToString(File(root, "files/$project/$id").readBytes())]; mutation.set(rows); jsonOf(rows).encodeToByteArray()
                }
                path == "/_fixture/evidence" -> {
                    check(inspectPosts.get() == 0 && inspections.isEmpty())
                    val cid = inspectionCid; val observed = EnglishObservationGraph.read(cas, cid)
                    check(observed.source.text == text && observed.source.originalCid == sourceCid)
                    check(GuestModules.installed().isEmpty() && GuestModules.mounted().isEmpty())
                    val originalPrefix = File(out, "input-cas-prefix.bin").readBytes()
                    val livePack = File(root, "cas/pack").readBytes()
                    check(livePack.size >= originalPrefix.size && livePack.copyOfRange(0, originalPrefix.size).contentEquals(originalPrefix))
                    val export = File(out, "cas-readbacks").apply { mkdirs() }; val entries = mutableListOf<Map<String, Any?>>()
                    for (value in synchronized(retained) { retained.toList().sorted() }) {
                        val id = ContentId(value); val bytes = requireNotNull(cas.getBounded(id, 8 * 1024 * 1024)) { "Promised retained artifact absent: $value" }
                        check(ContentId.of(bytes) == id)
                        val looksCbor = bytes.firstOrNull()?.toInt()?.and(0xe0) == 0xa0
                        val extension = if (looksCbor) "cbor" else "txt"
                        if (looksCbor) CanonicalCbor.decodeMapBounded(bytes, 8 * 1024 * 1024, 32, 500_000)
                        File(export, id.hex + "." + extension).writeBytes(bytes)
                        entries.add(_m["cid" j value, "bytes" j bytes.size, "encoding" j if (looksCbor) "canonical-cbor" else "exact-utf8"])
                    }
                    val safety = counters(); check(safety["analysisReteFacts"] == 0 && safety["blackboardUnchangedFromReadinessBaseline"] == true)
                    check(automatic.get() == 0 && intake.get() == 0 && modelCalls.get() == 0 && ctx.beliefBag == null)
                    val result = _m["scope" j "Actual final Documents/default retained reader and synthetic authenticated review pilot; no fresh parser, human legal approval or world admission",
                        "safety" j safety, "classCodeSources" j codeSources, "sourceCid" j sourceCid.value, "inspectionCid" j cid.value,
                        "sourceSnapshots" j observed.sourceSnapshots?.map { it.toMap() }, "mutation" j mutation.get(),
                        "originalCasPrefixCid" j ContentId.of(originalPrefix).value, "originalCasPrefixBytes" j originalPrefix.size,
                        "retainedReadbacks" j entries, "requests" j synchronized(calls) { calls.toList() },
                        "networkBefore" j denyBefore, "networkAfter" j network(), "reviewer" j _m["id" j reviewerId, "synthetic" j true]]
                    File(out, "fixture-evidence.json").writeText(jsonOf(result)); jsonOf(result).encodeToByteArray()
                }
                path == "/_fixture/finish" -> { finish.countDown(); "{}".encodeToByteArray() }
                path == "/documents" -> { mime = "text/html; charset=utf-8"; File(snapshot, "web/documents.html").readBytes() }
                path == "/kotlin/documents/documents.js" -> { mime = "application/javascript"; File(snapshot, "documents.js").readBytes() }
                path.endsWith(".css") || path.startsWith("/vendor/") -> {
                    val file = File(snapshot, "web" + path); if (!file.isFile) { status = 404; byteArrayOf() }
                    else { mime = if (path.endsWith(".css")) "text/css" else "application/javascript"; file.readBytes() }
                }
                path.startsWith("/api/documents/") -> {
                    if (path == DocumentEnglishWire.PATH && method == "POST") inspectPosts.incrementAndGet()
                    val before = wal.length()
                    val routed = runBlocking { requireNotNull(ctx.routes.match(path)).route(method, target, headers, null) }!!
                    status = routed.status; mime = routed.contentType
                    val parsed = reifyStrict(routed.body) as Map<*, *>
                    val request = if (body.isBlank()) null else reifyStrict(body)
                    calls.add(_m["method" j method, "path" j path, "query" j ex.requestURI.rawQuery, "status" j status,
                        "authorizationHeaderPresent" j ex.requestHeaders.containsKey("Authorization"), "request" j request,
                        "response" j parsed, "walBytesBefore" j before, "walBytesAfter" j wal.length()])
                    if (path == DocumentEnglishWire.PATH && method == "POST" && status == 200) inspections.add(parsed)
                    if (status == 200) {
                        val keys = when (path) {
                            DocumentEnglishWire.PATH, DocumentEnglishWire.RETAINED_PATH -> _l["receiptCid"]
                            "/api/documents/review/english-taxonomy" -> _l["translationCid", "derivedKifCid", "receiptCid"]
                            "/api/documents/review", "/api/documents/review/snapshot", "/api/documents/review/decision" -> _l["snapshotCid", "decisionCid"]
                            "/api/documents/review/taxonomy-plan" -> _l["approvalCid"]
                            else -> emptyList<String>()
                        }
                        for (key in keys) (parsed[key] as? String)?.takeIf { it.startsWith("sha256:") }?.let { retained.add(it) }
                    }
                    routed.body.encodeToByteArray()
                }
                path.startsWith("/_project/") -> {
                    val routed = runBlocking { requireNotNull(uploads.route(method, target, "$method $target HTTP/1.1\r\n\r\n".encodeToByteArray() + raw, null)) }
                    status = routed.status; mime = routed.contentType; routed.body.encodeToByteArray()
                }
                path.startsWith("/api/projects") -> {
                    val routed = runBlocking { patch.route(method, target, headers, null) }
                    if (routed == null) { status = 404; "{}".encodeToByteArray() } else { status = routed.status; mime = routed.contentType; routed.body.encodeToByteArray() }
                }
                else -> { status = 404; "{}".encodeToByteArray() }
            }
            ex.responseHeaders.set("Content-Type", mime); ex.sendResponseHeaders(status, response.size.toLong()); ex.responseBody.use { it.write(response) }
        } catch (failure: Throwable) { failure.printStackTrace(); runCatching {
            val bytes = jsonOf(_m["error" j failure.message]).encodeToByteArray(); ex.sendResponseHeaders(500, bytes.size.toLong()); ex.responseBody.use { it.write(bytes) }
        } } finally { ex.close() }
    }
    try { server.start(); println("REVIEWED_PROOF_QUERY_UI_URL=http://127.0.0.1:${server.address.port}"); check(withContext(Dispatchers.IO) { finish.await(12, TimeUnit.MINUTES) }) }
    finally {
        server.stop(0); executor.shutdownNow(); reviewWire.drain(); reviewWire.close(); books.drain(); scopes.drain()
        owner.complete(); owner.join(); cas.close()
        check(executor.awaitTermination(10, TimeUnit.SECONDS))
        File(out, "cleanup.json").writeText(jsonOf(_m["reviewWireDrainedAndClosed" j true, "booksDrained" j true, "scopesDrained" j true,
            "writerPid" j ProcessHandle.current().pid().toString(), "allSupervisorsCompleted" j owner.isCompleted,
            "remainingChildren" j owner.children.count(), "executorTerminated" j executor.isTerminated, "casCloseReturned" j true,
            "reviewWalAfterClose" j reviewWal(), "listenerStopped" j true, "inspectionPosts" j inspectPosts.get(), "inspectionResponses" j inspections.size]))
    }
}
