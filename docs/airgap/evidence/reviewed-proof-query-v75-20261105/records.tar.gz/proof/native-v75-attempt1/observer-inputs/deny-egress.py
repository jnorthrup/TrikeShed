#!/usr/bin/env python3
"""Fixture-only seccomp filter. Inbound accept/read/write remain allowed; this is not a sandbox."""
import ctypes, ctypes.util, errno, hashlib, json, os, socket, sys
from pathlib import Path

lib = ctypes.CDLL(ctypes.util.find_library('seccomp') or 'libseccomp.so.2', use_errno=True)
lib.seccomp_init.argtypes = [ctypes.c_uint32]; lib.seccomp_init.restype = ctypes.c_void_p
lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]; lib.seccomp_rule_add.restype = ctypes.c_int
lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]; lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
lib.seccomp_load.argtypes = [ctypes.c_void_p]; lib.seccomp_load.restype = ctypes.c_int
lib.seccomp_release.argtypes = [ctypes.c_void_p]
libc = ctypes.CDLL(None, use_errno=True)
SCMP_ACT_ALLOW = 0x7fff0000
SCMP_ACT_ERRNO_EACCES = 0x00050000 | errno.EACCES
names = ['connect', 'sendto', 'sendmsg', 'sendmmsg']
ctx = lib.seccomp_init(SCMP_ACT_ALLOW)
if not ctx: raise RuntimeError('seccomp_init failed')
try:
    for name in names:
        number = lib.seccomp_syscall_resolve_name(name.encode('ascii'))
        if number < 0: raise RuntimeError('Unknown syscall '+name)
        result = lib.seccomp_rule_add(ctx, SCMP_ACT_ERRNO_EACCES, number, 0)
        if result: raise RuntimeError('seccomp_rule_add failed: '+str(result))
    if libc.prctl(38, 1, 0, 0, 0) != 0: raise OSError(ctypes.get_errno(), 'PR_SET_NO_NEW_PRIVS')
    result = lib.seccomp_load(ctx)
    if result: raise RuntimeError('seccomp_load failed: '+str(result))
finally:
    lib.seccomp_release(ctx)
probes = []
for name, operation in [
    ('tcp-connect', lambda stream: stream.connect(('127.0.0.1',9))),
    ('udp-sendto', lambda stream: stream.sendto(b'fixture-self-probe',('127.0.0.1',9))),
    ('udp-sendmsg', lambda stream: stream.sendmsg([b'fixture-self-probe'], [], 0, ('127.0.0.1',9))),
]:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM if name=='tcp-connect' else socket.SOCK_DGRAM) as stream:
        try: operation(stream)
        except OSError as failure:
            if failure.errno != errno.EACCES: raise
            probes.append({'operation':name,'errno':failure.errno,'result':'DENIED'})
        else: raise AssertionError('Outbound syscall was not denied: '+name)
profile = {'scope':'fixture process and descendants only; inbound listener and ordinary response writes allowed',
    'notClaimed':['full OS sandbox','production daemon air gap','filesystem isolation','kernel exploit containment'],
    'defaultAction':'ALLOW','deniedSyscalls':names,'errno':errno.EACCES,'selfProbes':probes,
    'noNewPrivileges':libc.prctl(39,0,0,0,0),'seccompMode':libc.prctl(21,0,0,0,0),
    'wrapperSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
assert profile['noNewPrivileges']==1 and profile['seccompMode']==2
receipt = Path(os.environ['OUTBOUND_DENY_RECEIPT']); receipt.write_text(json.dumps(profile,indent=2)+'\n')
args = sys.argv[1:]
if args and args[0]=='--': args=args[1:]
if not args: raise SystemExit('Expected command after --')
os.execvp(args[0],args)
