package proof.kifcomments

import borg.trikeshed.cursor.BudgetCoord
import borg.trikeshed.forge.server.BeliefWire
import borg.trikeshed.job.*
import borg.trikeshed.kif.*
import borg.trikeshed.lib.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.*
import java.io.File
import java.lang.System
import java.net.*
import java.net.http.*
import java.nio.file.Path
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Observer
fun bytes64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
fun write(file: File, value: Any?) { file.writeText(jsonOf(value) + "\n") }
fun exact(cas: PackCasStore, cid: ContentId, bytes: ByteArray): Map<String, Any?> {
    val retained = requireNotNull(cas.getBounded(cid, bytes.size))
    check(retained.contentEquals(bytes) && ContentId.of(retained) == cid)
    return _m["cid" j cid.value, "bytes" j retained.size, "sha256" j hash(retained)]
}
fun fileState(file: File): Map<String, Any?> = file.readBytes().let { _m["bytes" j it.size, "sha256" j hash(it)] }
fun identity(root: File, mode: String): Map<String, Any?> {
    val snapshot = File(requireNotNull(System.getenv("PROOF_SNAPSHOT")))
    val head = requireNotNull(System.getenv("EXPECTED_SOURCE_HEAD")); val mainSha = requireNotNull(System.getenv("EXPECTED_MAIN_SHA256"))
    check(snapshot.resolve("source-head.txt").readText().trim() == head)
    val main = snapshot.resolve("main.jar").canonicalFile
    check(hash(main.readBytes()) == mainSha)
    val jars = snapshot.resolve("classpath.txt").readText().trim().split(':').map { File(it).canonicalFile }
    check(jars.size == 120 && jars.first() == main && jars.all { it.isFile && it.extension == "jar" })
    val manifest = reifyStrict(snapshot.resolve("sha256.json").readText()) as Map<*, *>
    val dependencies = manifest["dependencies"] as Map<*, *>
    check(dependencies.size == 119)
    for (jar in jars.drop(1)) check(hash(jar.readBytes()) == dependencies[jar.path])
    val observer = File(Observer::class.java.protectionDomain.codeSource.location.toURI()).canonicalFile
    check(requireNotNull(System.getProperty("java.class.path")).split(':').map { File(it).canonicalFile } == _l[observer] + jars)
    val classes = s_[BeliefWire::class.java, BeliefBagElement::class.java, TurnReviewElement::class.java,
        KgNalBridge::class.java, KifExpr::class.java, KifSemantic::class.java, KgRetention::class.java,
        SemanticSignal::class.java, SignalCodec::class.java, PackCasStore::class.java, DocumentAppendLog::class.java,
        JvmFileOperations::class.java]
    val sources = classes.view.associate { cls ->
        val source = File(cls.protectionDomain.codeSource.location.toURI()).canonicalFile
        check(source == main) { "Production overlay: ${cls.name} from $source" }
        cls.name to source.path
    }
    return _m["mode" j mode, "pid" j ProcessHandle.current().pid().toString(), "sourceHead" j head,
        "mainSha256" j mainSha, "productionCodeSources" j sources, "frozenJars" j jars.size,
        "dependencyHashesVerified" j 119, "observerCodeSource" j observer.path, "overlays" j false, "friends" j false]
        .also { write(root.resolve("$mode-identity.json"), it) }
}

/** Loopback transport only: every handler delegates to the final-JAR production BeliefWire. */
class Transport(val wire: BeliefWire) {
    val records = mutableListOf<Map<String, Any?>>()
    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 8)
    val executor = Executors.newSingleThreadExecutor()
    val client = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build()
    init {
        server.executor = executor
        server.createContext("/api/beliefs") { exchange ->
            try {
                val raw = exchange.requestBody.readBytes()
                val body = raw.decodeToString(throwOnInvalidSequence = true)
                val method = exchange.requestMethod; val path = exchange.requestURI.toASCIIString()
                val response = runBlocking { requireNotNull(wire.route(method, path, "$method $path HTTP/1.1\r\n\r\n$body", null)) }
                val bytes = response.body.encodeToByteArray()
                exchange.responseHeaders.set("Content-Type", "application/json; charset=utf-8")
                exchange.sendResponseHeaders(response.status, bytes.size.toLong()); exchange.responseBody.use { it.write(bytes) }
            } catch (failure: Throwable) {
                val bytes = jsonOf(_m["observerFailure" j failure.toString()]).encodeToByteArray()
                exchange.sendResponseHeaders(500, bytes.size.toLong()); exchange.responseBody.use { it.write(bytes) }
            } finally { exchange.close() }
        }
        server.start()
    }
    fun post(path: String, bytes: ByteArray, expected: Int): Map<String, Any?> {
        val response = client.send(HttpRequest.newBuilder(URI("http://127.0.0.1:${server.address.port}$path"))
            .header("Content-Type", "text/plain; charset=utf-8").POST(HttpRequest.BodyPublishers.ofByteArray(bytes)).build(), HttpResponse.BodyHandlers.ofByteArray())
        @Suppress("UNCHECKED_CAST") val body = reifyStrict(response.body().decodeToString(throwOnInvalidSequence = true)) as Map<String, Any?>
        records.add(_m["method" j "POST", "path" j path, "requestBase64" j bytes64(bytes), "requestCid" j ContentId.of(bytes).value,
            "status" j response.statusCode(), "response" j body])
        check(response.statusCode() == expected) { "HTTP ${response.statusCode()} instead of $expected: $body" }
        return body
    }
    fun close() { server.stop(0); executor.shutdown(); check(executor.awaitTermination(10, TimeUnit.SECONDS)); client.close() }
}
fun bagRows(bag: BeliefBagElement): List<Map<String, Any?>> = bag.snapshot().entries.sortedBy { it.key.a }.map { (key, signal) ->
    _m["angular" j signal.angular.toString(), "propositionCid" j signal.propositionCid, "evidencePacked" j signal.evidence.packed.toString(),
        "positive" j signal.evidence.positive, "negative" j signal.evidence.negative, "budgetPacked" j key.b.toString(),
        "signalBase64" j bytes64(SignalCodec.encode(signal))]
}

suspend fun writer(root: File, red: Boolean) = coroutineScope {
    val runtime = root.resolve("runtime"); check(!runtime.exists()) { "Each attempt requires fresh storage" }; check(runtime.mkdir())
    val fixture = File(requireNotNull(System.getenv("PROOF_INPUTS")))
    val commented = fixture.resolve("commented.kif").readBytes(); val plain = fixture.resolve("plain.kif").readBytes()
    root.resolve("commented.kif").writeBytes(commented); root.resolve("plain.kif").writeBytes(plain)
    val files = JvmFileOperations(); val cas = PackCasStore(files, runtime.resolve("cas").path)
    val log = DocumentAppendLog.open(runtime.resolve("beliefs.wal").path, runtime.path)
    val bag = BeliefBagElement(cas = cas, wal = log, flushEvery = 1000, priorityFloor = 0f, decayFn = { it }, parentJob = currentCoroutineContext()[Job]); bag.open()
    val review = TurnReviewElement(bag); review.open(); val transport = Transport(BeliefWire(bag, review, null))
    val checks = mutableListOf<Map<String, Any?>>()
    var result: Map<String, Any?>? = null
    try {
        if (red) {
            val before = bagRows(bag)
            val refused = transport.post("/api/beliefs/kg", commented, 400); bag.awaitProcessed()
            check(refused["error"] == "invalid_kg_input" && bagRows(bag) == before && bag.size == 0)
            check(cas.getBounded(ContentId.of(commented), commented.size) == null)
            checks.add(_m["case" j "v72-leading-comment-RED", "status" j 400, "sourceNotRetained" j true, "bagUnchanged" j true])
        }
        val accepted = if (red) plain else commented
        val imported = transport.post("/api/beliefs/kg", accepted, 200); bag.awaitProcessed()
        check(imported["format"] == "KIF" && (imported["processedAssertions"] as Number).toInt() == 1 && bag.size == 1)
        val source = ContentId(imported["sourceCid"] as String); check(source == ContentId.of(accepted))
        val definitionCid = ContentId((imported["propositionCids"] as List<*>).single() as String)
        val definition = requireNotNull(cas.getBounded(definitionCid, 262144)); check(ContentId.of(definition) == definitionCid)
        val decoded = CanonicalCbor.decodeMapBounded(definition, 262144, 16, 4096)
        check(decoded["kind"] == "kg-source-proposition/1" && decoded["sourceContext"] == source.value &&
            decoded["subject"] == "Tenant" && decoded["predicate"] == "labels" && decoded["object"] == "\"notice; (exact) 📚\"")
        exact(cas, source, accepted); root.resolve("accepted-source.kif").writeBytes(accepted); root.resolve("definition.cbor").writeBytes(definition)
        val signal = bag.snapshot().values.single(); val original = SignalCodec.encode(signal)
        val attended = transport.post("/api/beliefs/attend", jsonOf(_m["angular" j signal.angular.toString(), "propositionCid" j definitionCid.value, "p" j .9]).encodeToByteArray(), 200)
        check((attended["attended"] as Map<*, *>)["sourceContext"] == source.value)
        val afterAttend = SignalCodec.encode(requireNotNull(bag.signalOf(signal.angular)))
        check(afterAttend.contentEquals(original))
        val baseline = bagRows(bag)
        if (!red) for (name in s_["comment-only", "unsupported-multiform", "malformed-multiform", "mixed-formats", "hash-is-not-kif-comment"].view) {
            val bytes = fixture.resolve("$name.kif").readBytes(); val pack = runtime.resolve("cas/pack").readBytes()
            val bagBefore = bagRows(bag); val casPackBefore = fileState(runtime.resolve("cas/pack"))
            val refused = transport.post("/api/beliefs/kg", bytes, 400); bag.awaitProcessed()
            val bagAfter = bagRows(bag); val casPackAfter = fileState(runtime.resolve("cas/pack"))
            check(refused["error"] == "invalid_kg_input" && bagAfter == bagBefore)
            check(runtime.resolve("cas/pack").readBytes().contentEquals(pack))
            check(cas.getBounded(ContentId.of(bytes), bytes.size) == null)
            val healthy = transport.post("/api/beliefs/kg", accepted, 200); bag.awaitProcessed()
            val bagAfterHealthy = bagRows(bag)
            check(healthy["sourceCid"] == source.value && healthy["propositionCids"] == imported["propositionCids"] &&
                bagAfterHealthy.map { it - "budgetPacked" } == bagBefore.map { it - "budgetPacked" })
            checks.add(_m["case" j name, "status" j 400, "healthyNextStatus" j 200, "bagEvidenceAndBudgetUnchanged" j true,
                "casPackUnchangedOnRefusal" j true, "refusedSourceNotRetained" j true, "sourceCid" j ContentId.of(bytes).value,
                "bagBefore" j bagBefore, "bagAfter" j bagAfter, "bagAfterHealthy" j bagAfterHealthy,
                "casPackBefore" j casPackBefore, "casPackAfter" j casPackAfter,
                "healthyEvidenceUnchanged" j true, "healthyBudgetScope" j "Explicit healthy KG replay renews attention; refused input changes no budget or evidence"] )
        }
        val sourceReadback = exact(cas, source, accepted); val definitionReadback = exact(cas, definitionCid, definition)
        result = _m["result" j "PASS", "scope" j if (red) "Expected current v72 detection bug reproduced over real HTTP, followed by healthy plain KIF; no fix claimed" else "Commented KIF detection and bounded ground-binary whole-input refusal, not parser completeness or source entailment",
            "mode" j if (red) "red" else "writer", "pid" j ProcessHandle.current().pid().toString(), "commentedSourceCid" j ContentId.of(commented).value,
            "sourceCid" j source.value, "definitionCid" j definitionCid.value, "angular" j signal.angular.toString(),
            "acceptedSourceBase64" j bytes64(accepted), "definitionBase64" j bytes64(definition), "bagRows" j bagRows(bag), "bagRowsAfterAttend" j baseline, "checks" j checks,
            "signalBeforeAttendBase64" j bytes64(original), "signalAfterAttendBase64" j bytes64(afterAttend),
            "sourceReadback" j sourceReadback, "definitionReadback" j definitionReadback]
    } finally {
        transport.close(); review.drain(); bag.drain(); check(bag.worker?.isCompleted == true && bag.supervisor.isCompleted)
        cas.sync(); log.flush(); log.close(); cas.close(); write(root.resolve("http-records.json"), transport.records)
        write(root.resolve("cleanup.json"), _m["listenerStopped" j true, "reviewDrained" j true, "bagWorkerCompleted" j true,
            "bagSupervisorCompleted" j true, "httpClientClosed" j true, "executorTerminated" j transport.executor.isTerminated,
            "packSynced" j true, "walFlushed" j true, "packAndWalClosed" j true])
    }
    write(root.resolve("writer-result.json"), requireNotNull(result) + _m["closedWal" j fileState(runtime.resolve("beliefs.wal")),
        "closedCasPack" j fileState(runtime.resolve("cas/pack"))]); println("KIF_HTTP_${if (red) "RED" else "GREEN"}_PASS")
}

suspend fun reopen(root: File) = coroutineScope {
    val report = reifyStrict(root.resolve("writer-result.json").readText()) as Map<*, *>
    check(report["result"] == "PASS" && report["pid"] != ProcessHandle.current().pid().toString())
    val cleanup = reifyStrict(root.resolve("cleanup.json").readText()) as Map<*, *>; check(cleanup.values.all { it == true })
    val runtime = root.resolve("runtime"); val walBeforeOpen = fileState(runtime.resolve("beliefs.wal"))
    val files = JvmFileOperations(); val cas = PackCasStore(files, runtime.resolve("cas").path)
    val log = DocumentAppendLog.open(runtime.resolve("beliefs.wal").path, runtime.path)
    val bag = BeliefBagElement(cas = cas, wal = log, priorityFloor = 0f, decayFn = { it }, parentJob = currentCoroutineContext()[Job]); bag.open()
    var observed: Map<String, Any?>? = null
    try {
        val rows = bagRows(bag); check(reifyStrict(jsonOf(rows)) == report["bagRows"])
        val sourceReadback = exact(cas, ContentId(report["sourceCid"] as String), root.resolve("accepted-source.kif").readBytes())
        val definitionReadback = exact(cas, ContentId(report["definitionCid"] as String), root.resolve("definition.cbor").readBytes())
        val signal = requireNotNull(bag.signalOf((report["angular"] as String).toLong()))
        val context = bag.sourceContexts()(signal); check(context["sourceContext"] == report["sourceCid"])
        observed = _m["bagRows" j rows, "sourceReadback" j sourceReadback, "definitionReadback" j definitionReadback, "sourceContext" j context]
    } finally { bag.drain(); check(bag.supervisor.isCompleted); cas.sync(); log.flush(); log.close(); cas.close() }
    write(root.resolve("reopen-result.json"), _m["result" j "PASS", "pid" j ProcessHandle.current().pid().toString(), "writerPid" j report["pid"],
        "sourceCid" j report["sourceCid"], "definitionCid" j report["definitionCid"], "sourceAndDefinitionBytesPreserved" j true,
        "bagEvidenceSignalAndBudgetReplayed" j true, "ownersDrained" j true, "walBeforeOpen" j walBeforeOpen,
        "walAfterClose" j fileState(runtime.resolve("beliefs.wal")), "casPackAfterClose" j fileState(runtime.resolve("cas/pack")),
        "scope" j "Clean separate-process close/reopen, not crash or power-loss recovery"] + requireNotNull(observed))
    println("KIF_REOPEN_PASS")
}
fun main(args: Array<String>) = runBlocking(JvmFileOperations()) {
    check(args.size == 2); val mode = args[0]; val root = File(args[1]).canonicalFile; root.mkdirs(); identity(root, mode)
    when (mode) { "red" -> writer(root, true); "writer" -> writer(root, false); "reopen" -> reopen(root); else -> error("red, writer or reopen required") }
}
