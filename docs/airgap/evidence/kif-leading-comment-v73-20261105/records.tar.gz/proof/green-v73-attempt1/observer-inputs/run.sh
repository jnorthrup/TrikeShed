#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
kif_proof=/workspace/library-files/kif-leading-comment-http-proof
export PROOF_SNAPSHOT=${1:?frozen snapshot required}
kif_classes=${2:?observer directory required}
kif_mode=${3:?red writer or reopen required}
kif_root=${4:?fresh attempt directory required}
: "${EXPECTED_SOURCE_HEAD:?pinned source required}"
: "${EXPECTED_MAIN_SHA256:?pinned final JAR hash required}"
export EXPECTED_SOURCE_HEAD EXPECTED_MAIN_SHA256
export PROOF_INPUTS="$kif_proof/inputs"
kif_cp=$(cat "$PROOF_SNAPSHOT/classpath.txt")
java --enable-native-access=ALL-UNNAMED -Xmx768m -cp "$kif_classes:$kif_cp" proof.kifcomments.ProofKt "$kif_mode" "$kif_root"
