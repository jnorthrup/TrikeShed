#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
kif_proof=/workspace/library-files/kif-leading-comment-http-proof
kif_snapshot=${1:?frozen snapshot required}
kif_output=${2:?fresh observer class directory required}
kif_cp=$(cat "$kif_snapshot/classpath.txt")
kif_compiler=$(rg --files --no-ignore /workspace/.trikeshed-cloud/gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.21 | rg '\.jar$' | head -n 1)
mkdir "$kif_output"
java -Xmx768m -cp "$kif_compiler:$kif_cp" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 25 -classpath "$kif_cp" -d "$kif_output" "$kif_proof/Proof.kt"
