'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const hash=b=>'sha256:'+crypto.createHash('sha256').update(b).digest('hex');
async function main(){
 const base=process.env.PROOF_URL,art=process.env.PROOF_ARTIFACTS;assert(base&&art);assert(fs.existsSync(path.join(art,'GO.json')),'Root frozen GO required');
 const observed={runs:[],sourceFocus:[],imports:[],states:[],contentReads:[]},requests=[],errors=[],external=[];let browser,context,page;
 const persist=()=>fs.writeFileSync(path.join(art,'browser-progress.json'),JSON.stringify({observed,requests,errors,external},null,2));
 const state=async label=>{const r=await fetch(base+'/__v78/state');assert.equal(r.status,200);const x=await r.json();observed.states.push({label,state:x});persist();return x;};
 const read=async cid=>{
  assert.match(cid,/^sha256:[a-f0-9]{64}$/);let response=await fetch(base+'/api/lcnc/content?cid='+encodeURIComponent(cid));const record={cid,lcncStatus:response.status,lcncUrl:response.url};
  let bytes=Buffer.from(await response.arrayBuffer());
  if(response.status===413){record.lcncRefusal=JSON.parse(bytes.toString('utf8'));response=await fetch(base+'/api/v0/block/get?arg='+encodeURIComponent(cid));record.rawBlockStatus=response.status;record.rawBlockUrl=response.url;bytes=Buffer.from(await response.arrayBuffer());}
  assert.equal(response.status,200,bytes.toString('utf8'));assert.equal(hash(bytes),cid);record.bytes=bytes.length;record.sha256=hash(bytes);observed.contentReads.push(record);
  fs.mkdirSync(path.join(art,'durable-readbacks'),{recursive:true});fs.writeFileSync(path.join(art,'durable-readbacks',cid.slice(7)+'.json'),bytes);return JSON.parse(bytes);
 };
 const exactPassages=(text,passages,cid)=>{
  const pattern=/"passages"\s*:\s*/g;let match;
  while((match=pattern.exec(text))){const start=pattern.lastIndex;if(text[start]!=='[')continue;let depth=0,string=false,escape=false;
   for(let i=start;i<text.length;i++){const c=text[i];if(string){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')string=false;continue;}if(c==='"'){string=true;continue;}if(c==='['||c==='{')depth++;else if(c===']'||c==='}')depth--;if(depth===0){const candidate=text.slice(start,i+1);if(hash(Buffer.from(candidate))===cid&&JSON.stringify(JSON.parse(candidate))===JSON.stringify(passages))return candidate;break;}}
  }throw Error('Actual serialized passages preimage was not found in full response bytes');
 };
 const meta=await(await fetch(base+'/__v78/meta')).json();observed.meta=meta;
 const s12=meta.cases.S12,guard=meta.cases.G03;const prior=JSON.parse(fs.readFileSync(path.join(__dirname,'inputs/S12/prior-v77-common-report.json')));
 const params=(id,key)=>page.locator('.node[data-id="'+id+'"] .params label').filter({hasText:new RegExp('^'+key+'$')}).locator('xpath=following-sibling::input[1]');
 const paint=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const posts=()=>requests.filter(x=>x.method==='POST'&&x.path==='/api/lcnc/run').length;
 const loadDocument=async(doc,label)=>{const n=posts();const f=path.join(art,label+'.json');fs.writeFileSync(f,JSON.stringify(doc));await page.locator('#fileIn').setInputFiles(f);await page.waitForFunction(n=>document.querySelectorAll('.node').length===n,doc.nodes.length);await page.locator('#fitBtn').click();await paint();assert.equal(posts(),n,'Import/Fit must remain inert');observed.imports.push({label,document:doc,automaticRuns:posts()-n,url:page.url()});};
 const run=async(label,expected)=>{
  await page.waitForFunction(()=>!document.getElementById('runBtn').disabled);const before=await state('before-'+label);
  const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/lcnc/run'&&r.request().method()==='POST',{timeout:180000});
  await page.locator('#runBtn').click();const rr=await response;const request=rr.request().postDataJSON(),replyText=await rr.text(),reply=JSON.parse(replyText);fs.writeFileSync(path.join(art,label+'-http-response.json'),replyText);if(expected==='REFUSED')assert(rr.status()>=400,JSON.stringify(reply));else assert.equal(rr.status(),200,JSON.stringify(reply));
  await page.waitForFunction(()=>!document.getElementById('runBtn').disabled,null,{timeout:180000});await paint();
  const durable=await read(reply.receiptCid),program=await read(reply.programCid),invocations=await read(reply.invocationsCid);
  let complete=reply;if(reply.outputCid){complete=await read(reply.outputCid);assert.equal(reply.outputPreview,true);}
  const row={label,request,httpStatus:rr.status(),reply,durable,program,invocations,complete,url:page.url(),before,after:await state('after-'+label),domText:await page.locator('body').innerText()};
  if(expected==='EVALUATED'){
   assert.equal(reply.ok,true);assert.equal(reply.status,'completed');const o=complete.outputs.evaluate;
   assert.equal(o.status,'EVALUATED');assert.deepEqual(o.report,prior);assert.equal(o.source.mode,'current');assert.equal(o.source.currentness,'checked-before-and-after-evaluation');assert.equal(o.source.admission,'not-performed');
   assert.equal(o.passages.length,5);assert.deepEqual(o.passages.map(p=>p.begin),[0,20,40,63,86]);assert.equal(new Set(o.passages.map(p=>p.occurrenceCid)).size,5);assert.equal(new Set(o.passages.map(p=>p.contributionCid)).size,4);
   for(const p of o.passages){assert.equal(p.quote,s12.text.slice(p.begin,p.end));assert.equal(p.inspectionCid,s12.inspectionCid);assert.equal(p.frameCid,o.frameCid);}
   assert.notEqual(o.frameCid,reply.outputCid);row.report=o.report;row.passages=o.passages;
   row.selectedConfix=complete.outputs.passage;
   const completeText=reply.outputCid?fs.readFileSync(path.join(art,'durable-readbacks',reply.outputCid.slice(7)+'.json'),'utf8'):replyText;
   row.geometryInputUtf8=exactPassages(completeText,o.passages,row.selectedConfix.sourceCid);row.geometryInputBase64=Buffer.from(row.geometryInputUtf8).toString('base64');
   row.geometryInputOrigin='Exact serialized passages array substring from actual full HTTP/retained-output JSON bytes; computed geometryCID is not claimed stored inCAS';
   fs.writeFileSync(path.join(art,'passages-geometry-'+label+'.json'),row.geometryInputUtf8);
  } else if(expected==='UNSUPPORTED'){
   assert.equal(reply.status,'completed');assert.equal(complete.outputs.evaluate.status,'UNSUPPORTED');assert.equal(complete.outputs.evaluate.report.derivations.length,0);row.report=complete.outputs.evaluate.report;
  } else {assert.notEqual(reply.status,'completed');assert.notEqual(reply.ok,true);assert(!complete.outputs?.evaluate?.report,'Fresh refusal must not reuse old report');}
  observed.runs.push(row);persist();return row;
 };
 try{
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox']});context=await browser.newContext({viewport:{width:1700,height:1050}});page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));
  context.on('request',r=>{const u=new URL(r.url());if(u.origin===base)requests.push({method:r.method(),path:u.pathname,url:r.url(),body:r.postData()});else if(!['data:','blob:','about:'].includes(u.protocol))external.push(r.url());});
  await page.goto(base+'/panels',{waitUntil:'domcontentloaded'});await page.locator('#runBtn').waitFor();
  const sentinel=JSON.stringify({kind:'v78-real-native-scratch-sentinel',nodes:[],wires:[]});await page.evaluate(v=>localStorage.setItem('trikeshed.panels.v3',v),sentinel);
  const scratchBefore=await page.evaluate(()=>localStorage.getItem('trikeshed.panels.v3'));const offerResponse=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/panels/presets');
  await page.goto(base+'/panels?load=preset-english-nal-report',{waitUntil:'domcontentloaded'});const offered=await(await offerResponse).json();assert(offered.presets.some(x=>x.name==='preset-english-nal-report'));
  await page.waitForFunction(()=>document.querySelectorAll('.node').length===11);assert.equal(posts(),0);assert.equal(await page.evaluate(()=>localStorage.getItem('trikeshed.panels.v3')),scratchBefore);
  observed.inert={url:page.url(),offered,scratchBefore,scratchAfter:await page.evaluate(()=>localStorage.getItem('trikeshed.panels.v3')),runPosts:posts()};
  await params('receipt','default').fill(s12.inspectionCid);await params('receipt','default').dispatchEvent('change');await params('mode','value').fill('current');await params('mode','value').dispatchEvent('change');assert.equal(posts(),0);await page.locator('#fitBtn').click();
  await page.screenshot({path:path.join(art,'native-inert-retained-nal-preset.png'),fullPage:true});
  let first;
  for(let i=0;i<5;i++){
   await params('passage','path').fill(String(i));await params('passage','path').dispatchEvent('change');const row=await run('S12-passage-'+i,'EVALUATED');if(i===0)first=row;
   const selected=row.complete.outputs.passage;assert.equal(selected.geometry,'kotlin');assert.deepEqual(selected.value,row.passages[i]);assert.notEqual(selected.sourceCid,s12.row.cid);
   const card=page.locator('.node[data-id="passage"] section[aria-label="Selected retained passage"]');await card.waitFor({timeout:30000});assert((await card.innerText()).includes('Selected passage · kotlin JSON geometry'));
   assert.equal(await card.locator('blockquote').innerText(),row.passages[i].quote);const beforeUrl=page.url();const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v0/block/get');
   await card.getByRole('button',{name:'Verify quotation against retained text',exact:true}).click();const raw=Buffer.from(await(await response).body());assert.equal(hash(raw),s12.row.cid);fs.writeFileSync(path.join(art,'actual-source-response-'+i+'.txt'),raw);
   await card.getByRole('status').filter({hasText:'SHA-256 verified · quotation matches exact UTF-16 range.'}).waitFor();assert.equal(page.url(),beforeUrl);
   observed.sourceFocus.push({index:i,beforeUrl,afterUrl:page.url(),passage:row.passages[i],geometry:selected.geometry,geometrySourceCid:selected.sourceCid,cardText:await card.innerText(),verifiedContext:await card.locator('[aria-label="Verified passage context"]').innerText()});
   if(i===0)await card.screenshot({path:path.join(art,'native-kotlin-geometry-verified-source-occurrence.png')});persist();
  }
  await params('receipt','default').fill(guard.inspectionCid);await params('receipt','default').dispatchEvent('change');await run('G03-whole-profile-guard','UNSUPPORTED');await page.screenshot({path:path.join(art,'native-genuine-guard-whole-profile-unsupported.png'),fullPage:true});
  const fanout=JSON.parse(JSON.stringify(first.request.document));for(let i=0;i<8;i++){fanout.nodes.push({id:'copy-'+i,type:'display',x:1900+i*80,y:500,params:{}});fanout.wires.push({from:['evaluate','report'],to:['copy-'+i,'x']});}
  await loadDocument(fanout,'authored-report-fanout');const large=await run('S12-real-large-output','EVALUATED');assert.equal(large.reply.outputPreview,true);assert.match(large.reply.outputCid,/^sha256:/);assert(large.reply.outputs.evaluate.previewOnly);assert(observed.contentReads.some(x=>x.cid===large.reply.outputCid&&x.lcncStatus===413&&x.rawBlockStatus===200),'Full large output must preserve narrow-content cap and actual raw block fetch');large.retainedEvaluate=await read(large.reply.outputs.evaluate.retainedCid);assert.deepEqual(large.retainedEvaluate,large.complete.outputs.evaluate);await page.screenshot({path:path.join(art,'native-real-retained-large-output-reference.png'),fullPage:true});
  await loadDocument(first.request.document,'restore-first-current-admitted-program');const amended=Buffer.from(s12.text+'\n');const mutation=await fetch(base+'/_project/'+encodeURIComponent(s12.row.project)+'/put?path='+encodeURIComponent(s12.row.id),{method:'POST',body:amended});assert.equal(mutation.status,200);observed.sourceAmendment={requestBytes:amended.length,requestCid:hash(amended),requestUtf8:amended.toString('utf8'),requestBase64:amended.toString('base64'),response:await mutation.json(),state:await state('after-actual-source-amendment')};
  const refused=await run('same-current-program-after-source-amendment','REFUSED');assert(refused.after.englishCurrentnessReads>refused.before.englishCurrentnessReads,'Actual currentness owner must read again');assert.equal(refused.reply.programCid,first.reply.programCid,'The same authored current program must perform a fresh check');observed.staleDom={sourceCardCount:await page.locator('.node[data-id="passage"] section[aria-label="Selected retained passage"]').count(),url:page.url(),text:await page.locator('body').innerText()};assert.equal(observed.staleDom.sourceCardCount,0);await page.screenshot({path:path.join(art,'native-same-current-program-fresh-refusal.png'),fullPage:true});
  assert(!requests.some(r=>r.method==='POST'&&r.path==='/api/documents/english'));assert.equal(external.length,0);assert.equal(errors.length,0);
  const final=await state('final-before-close');assert.equal(final.beliefBagPresent,false);assert.equal(final.kifBankPresent,false);assert.equal(final.narsRetePresent,false);assert.deepEqual(final.guestInstalled,[]);assert.deepEqual(final.guestMounted,[]);assert.equal(final.configuredModelCount,0);assert.equal(final.modelEndpointsPresent,false);
  fs.writeFileSync(path.join(art,'browser-result.json'),JSON.stringify({result:'PASS',scope:'Actual native retained NAL workflow; original parser execution not reauthenticated, no independent entailment or live admission; local loopback netns, not full R4 seal.',observed,requests,errors,external},null,2));
 }catch(e){persist();fs.writeFileSync(path.join(art,'browser-failure.json'),JSON.stringify({error:String(e),stack:e.stack,observed,requests,errors,external},null,2));throw e;}
 finally{if(browser)await browser.close();await fetch(base+'/__v78/finish',{method:'POST'}).catch(()=>{});}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
