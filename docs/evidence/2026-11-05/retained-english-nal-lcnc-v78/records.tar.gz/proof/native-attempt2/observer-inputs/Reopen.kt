package proof.nalvisual

import borg.trikeshed.couch.*
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.job.*
import borg.trikeshed.memory.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

/** Separate after-close reader: no evaluator, parser, HTTP listener, module or admission. */
fun main(args:Array<String>)=runBlocking {
 val out=File(args[0]).canonicalFile;val runtime=File(out,"runtime");val pack=File(runtime,"cas/pack")
 require(File(out,"GO.json").isFile && File(out,"cleanup.json").isFile)
 fun stamp(f:File):Map<String,Any?> {val b=f.readBytes();return mapOf("bytes" to b.size,"sha256" to ContentId.of(b).hex)}
 val before=stamp(pack)
 fun ownerFiles()=File(runtime,"host").walkTopDown().filter{it.isFile}.associate{it.relativeTo(runtime).path to stamp(it)}
 val ownerBefore=ownerFiles()
 val writer=reifyStrict(File(out,"cleanup.json").readText()) as Map<*,*>;check((writer["pid"] as Number).toLong()!=ProcessHandle.current().pid())
 val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").absolutePath)
 val exports=File(out,"durable-readbacks").listFiles().orEmpty();require(exports.isNotEmpty())
 val readbacks=exports.sortedBy{it.name}.map{f->val cid=ContentId("sha256:"+f.name.substringBefore('.'));val b=checkNotNull(cas.getBounded(cid,8*1024*1024));check(b.contentEquals(f.readBytes()) && ContentId.of(b)==cid);mapOf("cid" to cid.value,"bytes" to b.size,"sha256" to ContentId.of(b).hex,"encoding" to "actual-full-json")}
 val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas);val registry=ProjectDbRegistry("primary")
 val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,projectDbs=registry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"))
 check(scopes.remountLedger()==1);val corpus=JvmProjectCorpus(registry,scopes)
 val cases=reifyStrict(File(out,"cases.json").readText()) as Map<*,*>;val s12=(cases["S12"] as Map<*,*>)["row"] as Map<*,*>
 val export=File(out,"after-close-readbacks").apply{mkdirs()}
 val historical=mutableListOf<Map<String,Any?>>()
 for((key,value) in cases){val c=value as Map<*,*>;val row=c["row"] as Map<*,*>
  for(cid in listOf(ContentId(c["inspectionCid"] as String),ContentId(row["cid"] as String))){val b=checkNotNull(cas.getBounded(cid,4*1024*1024));check(ContentId.of(b)==cid);File(export,cid.hex+".bin").writeBytes(b);historical.add(mapOf("case" to key,"cid" to cid.value,"bytes" to b.size,"sha256" to ContentId.of(b).hex))}
  val snap=EnglishObservationGraph.read(cas,ContentId(c["inspectionCid"] as String));check(snap.source.text==c["text"])
 }
 val current=checkNotNull(corpus.document(s12["project"] as String,s12["id"] as String));check(current.cid!=s12["cid"] && current.rev!=s12["rev"] && current.seq!=(s12["seq"] as Number).toLong())
 val amendedMirror=File(runtime,"files/"+s12["project"]+"/"+s12["id"])
 val amendedBytes=amendedMirror.readBytes();check(ContentId.of(amendedBytes).value==current.cid);File(export,"actual-amended-S12-source.txt").writeBytes(amendedBytes)
 scopes.drain();cas.close();check(stamp(pack)==before);check(ownerFiles()==ownerBefore)
 File(out,"reopened.json").writeText(jsonOf(mapOf("result" to "PASS","readerPid" to ProcessHandle.current().pid(),"writerPid" to writer["pid"],"writerCleanup" to writer,
 "codeSources" to mapOf("PackCasStore" to PackCasStore::class.java.protectionDomain.codeSource.location.toString(),"EnglishObservationGraph" to EnglishObservationGraph::class.java.protectionDomain.codeSource.location.toString(),"JvmProjectCorpus" to JvmProjectCorpus::class.java.protectionDomain.codeSource.location.toString()),"ownerFilesBeforeOpen" to ownerBefore,"ownerFilesAfterClose" to ownerFiles(),"historicalReadbacks" to historical,"readbacks" to readbacks,"packBeforeOpen" to before,"packAfterClose" to stamp(pack),"currentAmendedRow" to current.toMap(),"sourceMirror" to stamp(File(runtime,"files/"+s12["project"]+"/"+s12["id"])),"scope" to "Separate production CAS/project reader; immutable old run output is historical, no evaluation or fresh current report","closed" to true)))
}
