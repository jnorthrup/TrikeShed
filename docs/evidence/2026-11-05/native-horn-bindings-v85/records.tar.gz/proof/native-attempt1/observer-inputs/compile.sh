#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
horn_root=/workspace/library-files/native-horn-bindings-v85-native-proof
horn_snapshot=${1:?frozen snapshot required}
horn_classes=${2:?fresh external output directory required}
[[ -f "$horn_root/ACTIVE_GO.json" ]] || { echo 'Root frozen GO required' >&2; exit 1; }
horn_cp=$(cat "$horn_snapshot/classpath.txt")
horn_compiler=$(rg --files --no-ignore /workspace/.trikeshed-cloud/gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.21 | rg '\.jar$' | head -n1)
mkdir "$horn_classes"
java -Xmx768m -cp "$horn_compiler:$horn_cp" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 25 -classpath "$horn_cp" -d "$horn_classes" "$horn_root/Observer.kt"
