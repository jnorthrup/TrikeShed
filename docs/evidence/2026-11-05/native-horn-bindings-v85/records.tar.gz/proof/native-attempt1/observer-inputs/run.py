"""Actual pinned native proof observer, not a solver/fixture endpoint. Root frozenGO required."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,time,socket,errno,re
root=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--inside' in sys.argv:
 out,snapshot,classes=map(Path,sys.argv[2:5]);subprocess.run(['ip','link','set','lo','up'],check=True);network={'pid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net'),'interfaces':json.loads(subprocess.check_output(['ip','-j','addr'],text=True)),'routes':json.loads(subprocess.check_output(['ip','-j','route'],text=True))};assert len(network['interfaces'])==1 and network['interfaces'][0]['ifname']=='lo' and network['routes']==[]
 try:socket.create_connection(('1.1.1.1',443),timeout=2);raise RuntimeError('Unexpected external route')
 except OSError as e:assert e.errno==errno.ENETUNREACH;network['externalTcp']={'errno':e.errno,'message':str(e)}
 (out/'network.json').write_text(json.dumps(network,indent=2)+'\n');(out/'empty-subvm').mkdir();(out/'tmp').mkdir();cp=str(classes)+':'+(snapshot/'classpath.txt').read_text().strip();cmd=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-Xmx768m','--enable-native-access=ALL-UNNAMED','-Dtrikeshed.airgap=true','-Djava.io.tmpdir='+str(out/'tmp'),'-cp',cp,'proof.nativehorn.ObserverKt',str(root),str(out),str(snapshot)];tracecmd=['strace','-f','-e','trace=process','-s','4096','-o',str(out/'process.trace'),'--']+cmd
 (out/'observer-command.json').write_text(json.dumps(cmd,indent=2)+'\n');(out/'trace-command.json').write_text(json.dumps(tracecmd,indent=2)+'\n')
 with (out/'observer.log').open('w') as log:r=subprocess.run(tracecmd,stdout=log,stderr=subprocess.STDOUT,timeout=480)
 (out/'observer.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
 profile=json.loads((root/'native-profile.json').read_text());trace=(out/'process.trace').read_text();executions=[]
 for line in trace.splitlines():
  m=re.match(r'\s*(\d+)\s+execve\(("(?:[^"\\]|\\.)*"), (\[.*\]), .*\)\s*=\s*0',line)
  if m and Path(json.loads(m.group(2))).resolve()==Path(profile['binary']).resolve():
   argv=json.loads(m.group(3));pid=int(m.group(1));exit_match=re.search(r'^\s*'+str(pid)+r'\s+\+\+\+ exited with (\d+) \+\+\+',trace,re.M);assert exit_match and exit_match.group(1)=='0';assert argv[1:10]==['instantiate','--eval','--strict','--json','--readonly-mode','--store','dummy://',profile['adapter'],'--argstr'];input_path=argv[argv.index('input')+1];assert not Path(input_path).exists();executions.append({'pid':pid,'argv':argv,'exit':0,'inputPath':input_path,'inputRemovedAfterObserver':True})
 assert len(executions)==8,'All8actual native child execve+exit records required';(out/'native-processes.json').write_text(json.dumps(executions,indent=2)+'\n');assert not list((out/'tmp').glob('trikeshed-horn-*'));sys.exit(0)
assert len(sys.argv)==3 and sys.argv[1]=='--root-frozen-go';go=json.loads(Path(sys.argv[2]).read_text());assert go['GO'] is True;snapshot=Path(go['snapshot']);assert (snapshot/'source-head.txt').read_text().strip()==go['source'];assert sha(snapshot/'main.jar')==go['mainSha256'];cp=(snapshot/'classpath.txt').read_text().strip().split(':');pins=json.loads((snapshot/'sha256.json').read_text());assert len(cp)==120 and len(pins['dependencies'])==119
for p in map(Path,cp):assert sha(p)==(go['mainSha256'] if p==snapshot/'main.jar' else pins['dependencies'][str(p)])
profile=json.loads((root/'native-profile.json').read_text());native_before={p:{'bytes':Path(p).stat().st_size,'sha256':sha(Path(p))} for p in [profile['binary'],profile['adapter'],str(Path(profile['datalogDirectory'])/'datalog.nix')]};assert native_before[profile['binary']]['sha256']==profile['binarySha256']
out=root/'native-attempt1';out.mkdir();(out/'GO.json').write_text(json.dumps(go,indent=2)+'\n');(root/'ACTIVE_GO.json').write_text(json.dumps(go,indent=2)+'\n');inputs=out/'observer-inputs';inputs.mkdir()
for name in ['Observer.kt','compile.sh','run.py','protocol.txt','cases.json','native-profile.json']:shutil.copy2(root/name,inputs/name)
shutil.copytree(root/'inputs',out/'inputs');metadata=out/'artifact-metadata';metadata.mkdir()
for name in ['source-head.txt','sha256.json','classpath.txt']:shutil.copy2(snapshot/name,metadata/name)
(out/'native-pins-before.json').write_text(json.dumps(native_before,indent=2)+'\n');classes=root/'observer-attempt1'
with (out/'compile.log').open('w') as log:c=subprocess.run(['bash',str(root/'compile.sh'),str(snapshot),str(classes)],stdout=log,stderr=subprocess.STDOUT)
(out/'compile.exit').write_text(str(c.returncode)+'\n');assert c.returncode==0
(out/'classpath.json').write_text(json.dumps({'productionJars':120,'actualClasspath':[{'path':p,'sha256':sha(Path(p))} for p in cp],'observerClasses':str(classes),'totalClasspathEntries':121,'overlays':False,'friendPaths':False},indent=2)+'\n');cmd=['unshare','--user','--map-root-user','--net','python3',str(root/'run.py'),'--inside',str(out),str(snapshot),str(classes)];(out/'namespace-command.json').write_text(json.dumps(cmd,indent=2)+'\n');(out/'controller-before-netns.json').write_text(json.dumps({'pid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net')},indent=2)+'\n')
with (out/'namespace.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=500)
(out/'namespace.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0;native_after={p:{'bytes':Path(p).stat().st_size,'sha256':sha(Path(p))} for p in native_before};assert native_before==native_after;(out/'native-pins-after.json').write_text(json.dumps(native_after,indent=2)+'\n')
