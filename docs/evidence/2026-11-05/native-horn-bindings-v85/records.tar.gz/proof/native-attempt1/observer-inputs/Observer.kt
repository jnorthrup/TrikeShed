package proof.nativehorn

import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kif.*
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.parse.*
import borg.trikeshed.userspace.nio.channels.spi.JvmProcessProtocolPipes
import borg.trikeshed.userspace.nio.process.ProcessCaptureChannel
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import kotlinx.coroutines.*
import java.io.File
import java.lang.reflect.InvocationTargetException
import kotlin.coroutines.Continuation
import kotlin.coroutines.intrinsics.*

class ObserverMarker

/** Trusted host manual fixture, not a public route/source-authorized approval workflow. */
fun main(args:Array<String>)=runBlocking(JvmFileOperations()) {
 val root=File(args[0]).canonicalFile;val out=File(args[1]).canonicalFile;val snapshot=File(args[2]).canonicalFile
 val go=reifyStrict(File(out,"GO.json").readText()) as Map<*,*>;check(ContentId.of(File(snapshot,"main.jar").readBytes()).hex==go["mainSha256"])
 java.lang.System.setProperty(GuestModules.HOME_PROPERTY,File(out,"empty-subvm").path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 val profile=NativeHornProfile.parse(File(root,"native-profile.json").readText());val executor=NativeHornQuery(profile)
 val theory=NativeHornQuery::class.java.declaredMethods.single{it.name.startsWith("manualTheory")&&it.parameterTypes.contentEquals(arrayOf(java.lang.Long.TYPE,KifSourceAssertion::class.java,String::class.java,Continuation::class.java))}.also{it.isAccessible=true}
 val companion=NativeHornQuery.Companion;val preparation=companion.javaClass.declaredMethods.single{it.name.startsWith("manualInput")&&it.parameterTypes.contentEquals(arrayOf(java.lang.Long.TYPE,KifSourceAssertion::class.java,String::class.java))}.also{it.isAccessible=true}
 @Suppress("UNCHECKED_CAST") suspend fun invoke(source:KifSourceAssertion,query:String):Map<String,Any?> = suspendCoroutineUninterceptedOrReturn{continuation->try{val value=theory.invoke(executor,1L,source,query,continuation);if(value===COROUTINE_SUSPENDED)COROUTINE_SUSPENDED else value as Map<String,Any?>}catch(t:InvocationTargetException){throw t.targetException}}
 fun prepare(source:KifSourceAssertion,query:String):Map<*,*> = try{preparation.invoke(companion,1L,source,query) as Map<*,*>}catch(t:InvocationTargetException){throw t.targetException}
 val methodMetadata=_m["manualTheory" j theory.toGenericString(),"manualInput" j preparation.toGenericString(),"declaringClass" j NativeHornQuery::class.java.name,"scope" j "Bounded reflection of two INTERNAL trusted host fixture methods only; no friends/private checker/endpoint/approval deserialization"]
 val classes=_m["NativeHornQuery" j NativeHornQuery::class.java,"NativeHornProfile" j NativeHornProfile::class.java,"SumoNixBridge" j SumoNixBridge::class.java,"KifSourceAssertion" j KifSourceAssertion::class.java,"KifSemantic" j KifSemantic::class.java,"JvmFileOperations" j JvmFileOperations::class.java,"JvmProcessProtocolPipes" j JvmProcessProtocolPipes::class.java,"ProcessCaptureChannel" j ProcessCaptureChannel::class.java]
 val origins=classes.mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also{check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))}}
 File(out,"startup.json").writeText(jsonOf(_m["go" j go,"pid" j ProcessHandle.current().pid(),"methods" j methodMetadata,"origins" j origins,"observerCodeSource" j ObserverMarker::class.java.protectionDomain.codeSource.location.toString(),"authority" j "declared-host-manual-assumptions-only; KifReview.APPROVED supplied by THIStrustedfixture; not reviewed/current/source-authenticated/worldlegal truth","sdkInstalled" j GuestModules.installed(),"sdkMounted" j GuestModules.mounted()]))
 val cases=reifyStrict(File(root,"cases.json").readText()) as List<*>;val results=mutableListOf<Map<String,Any?>>()
 for(raw in cases) {
  val case=raw as Map<*,*>;val name=case["name"] as String;val folder=File(out,name).apply{mkdirs()};val sourceBytes=File(root,case["file"] as String).readBytes();val sourceCid=ContentId.of(sourceBytes);check(sourceCid.value==case["sourceCid"]&&sourceBytes.size==(case["bytes"] as Number).toInt());val text=sourceBytes.decodeToString(throwOnInvalidSequence=true)
  val source=KifSourceAssertion("host-manual-fixture",sourceCid,"manual-fixture/1",KifReview.APPROVED,text);val query=case["query"] as String;val prepared=prepare(source,query);val input=(prepared["inputJson"] as String).encodeToByteArray(throwOnInvalidSequence=true);check(ContentId.of(input).value==prepared["inputCid"])
  
  @Suppress("UNCHECKED_CAST") val frameData=(reifyStrict(input.decodeToString()) as Map<String,Any?>).toMutableMap();frameData.remove("frameId");frameData["revision"]=1L;val frameBytes=CanonicalCbor.encodeMap(frameData);check(ContentId.of(frameBytes).value==prepared["frameId"]);File(folder,"frame.cbor").writeBytes(frameBytes)
  File(folder,"source.kif").writeBytes(sourceBytes);File(folder,"input.json").writeBytes(input);File(folder,"prepared.json").writeText(jsonOf(prepared));File(out,"active-case.json").writeText(jsonOf(_m["name" j name,"inputCid" j prepared["inputCid"],"frameId" j prepared["frameId"]]))
  val began=java.lang.System.nanoTime();val result=invoke(source,query);val elapsed=(java.lang.System.nanoTime()-began)/1_000_000
  File(folder,"result.json").writeText(jsonOf(result));File(folder,"native-proof-structure.json").writeText(jsonOf(result["proof"]));File(folder,"checked-proof.json").writeText(jsonOf(result["checkedProof"]))
  check(result["status"]==case["expectedStatus"]&&result["inputCid"]==prepared["inputCid"]&&result["frameId"]==prepared["frameId"]&&result["worldObligationApplicability"]=="UNKNOWN"&&result["currentness"]=="not-checked"&&result["reviewAuthority"]=="not-established")
  if(result["status"]=="UNKNOWN")check(result["proof"]==null&&result["checkedProof"]==null)else {
   val checked=result["checkedProof"] as Map<*,*>;check(checked["inputCid"]==result["inputCid"]&&checked["frameId"]==result["frameId"]);val steps=(checked["steps"] as List<*>).map{it as Map<*,*>};val application=steps.single{(it["path"] as List<*>).isEmpty()};check(application["rule"]=="mayRead#1");check((application["premises"] as List<*>).size==2)
   val premise0=steps.single{it["path"]==_l[0]};val premise1=steps.single{it["path"]==_l[1]};check(premise0["normalForm"]=="(assignedTo Lark Harbor)"&&premise1["normalForm"]=="(authorized Lark Access)");val bindings=(application["bindings"] as List<*>).map{it as Map<*,*>}.associateBy{it["variable"]};check(bindings.getValue("?operator")["term"]==_m["kind" j "constant","token" j "Lark"]&&bindings.getValue("?resource")["term"]==_m["kind" j "constant","token" j "Harbor"])
   check(checked["referenceMode"]=="normalized-export-atoms-and-rule-scoped-variables-not-source-spans");if(name=="duplicate-authorization")check((premise1["sourceNodeIds"] as List<*>).distinct().size==2&&premise1["witnessMode"]=="any-one-asserted-source")
  }
  val descendants=ProcessHandle.current().descendants().use{stream->stream.map{it.pid()}.toList()};check(descendants.isEmpty());results.add(_m["case" j case,"sourceCid" j sourceCid.value,"inputCid" j result["inputCid"],"frameId" j result["frameId"],"status" j result["status"],"elapsedMillis" j elapsed,"nativeChildrenAfter" j descendants,"resultFile" j "$name/result.json","rawProofFile" j "$name/native-proof-structure.json","checkedProofFile" j "$name/checked-proof.json"]);File(out,"progress.json").writeText(jsonOf(results))
 }
 GuestModules.closeAll();val children=coroutineContext[Job]!!.children.count();check(children==0)
 File(out,"summary.json").writeText(jsonOf(_m["result" j "PASS","pid" j ProcessHandle.current().pid(),"sourceHead" j go["source"],"mainSha256" j go["mainSha256"],"methods" j methodMetadata,"origins" j origins,"cases" j results,"remainingCoroutineChildren" j children,"remainingNativeChildren" j ProcessHandle.current().descendants().use{it.count()},"guestModulesClosed" j GuestModules.closed.isCompleted,"scope" j "8separate explicit manual theories via trustedinternalhostfixture; actualnativefirstproof +samechecker additivebindingprojection, not independentinference/English/legal/NARS/admission/publicworkflow; normalizedsourceformreferencesnotspans."]))
}
