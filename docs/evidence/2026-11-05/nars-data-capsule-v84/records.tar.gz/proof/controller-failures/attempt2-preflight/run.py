"""Root authorized one relocated closed-data reader; metadata/Java/dependencies stay external."""
from pathlib import Path
import os,json,hashlib,shutil,subprocess
root=Path(__file__).resolve().parent;old=Path('/workspace/library-files/nars-exact-role-v83-native-proof');attempt=old/'native-attempt4';snapshot=Path('/workspace/library-files/nars-typed-role-v83-proof/snapshot');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();stamp=lambda p:{'bytes':p.stat().st_size,'sha256':sha(p)}
assert json.loads((root/'authorization.json').read_text())['rootAuthorized'] is True
go=json.loads((attempt/'GO.json').read_text());assert go['sourceHead']=='87e7bb3e945546137c595ff5aaf53781f4168275' and sha(snapshot/'main.jar')==go['mainSha256'];cp=(snapshot/'classpath.txt').read_text().strip().split(':');pins=json.loads((snapshot/'sha256.json').read_text());assert len(cp)==120 and len(pins['dependencies'])==119
for p in map(Path,cp):assert p.is_file() and p.suffix=='.jar' and sha(p)==(go['mainSha256'] if p==snapshot/'main.jar' else pins['dependencies'][str(p)])
inventory=json.loads(Path('/workspace/library-files/nars-typed-role-v83-data-portability-assessment/inventory.json').read_text());assert inventory['recordKinds']=={'BLOB':166} and inventory['pack']==stamp(attempt/'runtime/cas/pack');reopen=json.loads((attempt/'reopened.json').read_text());startup=json.loads((attempt/'startup.json').read_text());index=json.loads((attempt/'readback-index.json').read_text());roles={}
for e in index:roles.setdefault(e['cid'],[]).append(e['role'])
selected=[{'cid':cid,'roles':labels} for cid,labels in sorted(roles.items())];assert len(selected)==113
cards=[]
for row in reopen['recoveredBoardCards']:
 saved=row['command']['lcncRun'];cards.append({**{k:row[k] for k in ['label','jobId','commandCid']},**{k:saved[k] for k in ['runId','programCid','status','ok']}})
pays=next(r for r in reopen['recoveredBoardCards'] if r['label']=='pays-primary-structured')['command']['lcncRun']['outputs']['recall']['selection']['matches'][0];owes=next(r for r in reopen['recoveredBoardCards'] if r['label']=='owes-documentary-mismatch')['command']['lcncRun']['outputs']['recall']['selection']['matches'][0]
manifest={'sourceHead':go['sourceHead'],'mainSha256':go['mainSha256'],'producerProofRoot':str(old),'producerClosedSnapshot':str(attempt),'C2':{'sourceCid':startup['sourceC2']['cid'],'text':startup['sourceC2']['text'],'bytes':46,'paysPid':pays['propositionCid'],'owesPid':owes['propositionCid'],'angular':pays['angular']},'negativeFixtures':startup['negativeFixtures'],'packRecords':inventory['records'],'selectedReadbacks':selected,'expectedCards':cards,'expectedBeliefFrameKinds':['R','B','A','A','D','E'],'metadataRole':'External verification expectations/provenance only; no old-path data is read by capsule reader; actual data comes only from three copied files'}
(root/'verification-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');capsule=root/'capsule';capsule.mkdir(exist_ok=True);copy_rows=[]
for name in ['cas/pack','beliefs.wal','host/.kanban/board.wal']:
 source=attempt/'runtime'/name;target=capsule/name;target.parent.mkdir(parents=True,exist_ok=True);assert source.is_file() and not source.is_symlink();b=source.read_bytes();
 if not target.exists():target.write_bytes(b)
 assert stamp(source)==stamp(target);assert source.stat().st_ino!=target.stat().st_ino and target.stat().st_nlink==1;copy_rows.append({'file':name,'source':str(source),'clone':str(target),**stamp(target),'sourceInode':source.stat().st_ino,'cloneInode':target.stat().st_ino,'cloneLinks':target.stat().st_nlink})
assert sum(x['bytes'] for x in copy_rows)==372953 and len([p for p in capsule.rglob('*') if p.is_file()])==3
(root/'data-copy-manifest.json').write_text(json.dumps(copy_rows,indent=2)+'\n');metadata=root/'artifact-metadata';metadata.mkdir()
for name in ['source-head.txt','sha256.json','classpath.txt']:shutil.copy2(snapshot/name,metadata/name)
out=root/'attempt2';out.mkdir();inputs=out/'observer-inputs';inputs.mkdir()
for name in ['CapsuleReader.kt','compile.sh','inside.py','run.py','authorization.json','protocol.txt']:shutil.copy2(root/name,inputs/name)
classes=root/'observer-attempt1'
assert (root/'attempt1/compile.exit').read_text().strip()=='0' and (root/'attempt1/observer-inputs/CapsuleReader.kt').read_bytes()==(root/'CapsuleReader.kt').read_bytes()
(out/'compile-reuse.json').write_text(json.dumps({'compiledClasses':str(classes),'compiledSourceSha256':sha(root/'CapsuleReader.kt'),'originalCompileExit':0,'originalCompileLog':str(root/'attempt1/compile.log'),'reason':'OS controller CAP_NET_ADMIN correction only; exact same successfully compiled observer source/classes'},indent=2)+'\n')
(root/'classpath.json').write_text(json.dumps({'productionJars':120,'externalProductionClasspath':[{'path':p,'sha256':sha(Path(p))} for p in cp],'observerClasses':str(classes),'totalClasspathEntries':121,'assetJars':0},indent=2)+'\n')
(out/'controller-before.json').write_text(json.dumps({'pid':os.getpid(),'mountNamespace':os.readlink('/proc/self/ns/mnt'),'networkNamespace':os.readlink('/proc/self/ns/net'),'originalFilesBefore':{r['file']:stamp(Path(r['source'])) for r in copy_rows}},indent=2)+'\n')
cmd=['bwrap','--die-with-parent','--unshare-user','--uid','0','--gid','0','--unshare-net','--cap-add','CAP_NET_ADMIN','--ro-bind','/','/','--tmpfs',str(old),'--bind',str(capsule),str(capsule),'--bind',str(out),str(out),'--proc','/proc','--','python3',str(root/'inside.py'),str(out),str(capsule),str(root),str(snapshot),str(classes),str(old)]
(out/'namespace-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'namespace.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(out/'namespace.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
original_after={r['file']:stamp(Path(r['source'])) for r in copy_rows};assert original_after==json.loads((out/'controller-before.json').read_text())['originalFilesBefore'];assert all(stamp(capsule/r['file'])=={'bytes':r['bytes'],'sha256':r['sha256']} for r in copy_rows)
(out/'controller-after.json').write_text(json.dumps({'pid':os.getpid(),'originalFilesAfter':original_after,'capsuleDataFiles':{r['file']:stamp(capsule/r['file']) for r in copy_rows},'newSidecar':stamp(capsule/'host/.kanban/board.wal.lock'),'claim':'Original closed producer data unchanged; three cloned semantic input files unchanged; a new zero-byte lease sidecar created by production constructor'},indent=2)+'\n')
