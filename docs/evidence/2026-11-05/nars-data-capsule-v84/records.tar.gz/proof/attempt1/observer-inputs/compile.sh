#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
capsule_root=/workspace/library-files/nars-data-capsule-v84-proof
capsule_snapshot=${1:?frozen snapshot required}
capsule_output=${2:?fresh external class directory required}
[[ -f "$capsule_root/authorization.json" ]] || { echo 'Root v84 authorization required' >&2; exit 1; }
capsule_cp=$(cat "$capsule_snapshot/classpath.txt")
capsule_compiler=$(rg --files --no-ignore /workspace/.trikeshed-cloud/gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.21 | rg '\.jar$' | head -n1)
mkdir "$capsule_output"
java -Xmx768m -cp "$capsule_compiler:$capsule_cp" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 25 -classpath "$capsule_cp" -d "$capsule_output" "$capsule_root/CapsuleReader.kt"
