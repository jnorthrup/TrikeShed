package proof.narscapsule

import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.*
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import kotlinx.coroutines.*
import java.io.File

class ObserverMarker

/** One relocated-data replay/read/query. No server, intake/admission, attention or model. */
fun main(args:Array<String>)=runBlocking {
 val capsule=File(args[0]).canonicalFile;val manifestFile=File(args[1]).canonicalFile;val out=File(args[2]).canonicalFile;val snapshot=File(args[3]).canonicalFile;val oldRoot=File(args[4]).canonicalFile
 val manifest=reifyStrict(manifestFile.readText()) as Map<*,*>;check(ContentId.of(File(snapshot,"main.jar").readBytes()).hex==manifest["mainSha256"])
 val hiddenProbes=_l["native-attempt4/runtime/cas/pack","native-attempt4/runtime/beliefs.wal","native-attempt4/runtime/host/.kanban/board.wal","native-attempt4/cas-readbacks","inputs/C2.kif","observer-attempt4"]
 fun oldVisibility()=hiddenProbes.associateWith{File(oldRoot,it).exists()}.also{check(it.values.none{v->v})}
 val oldBefore=oldVisibility();check(oldRoot.listFiles().orEmpty().isEmpty())
 java.lang.System.setProperty(GuestModules.HOME_PROPERTY,File(out,"empty-subvm").path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 fun stamp(file:File):Map<String,Any?> {val b=file.readBytes();return _m["bytes" j b.size,"sha256" j ContentId.of(b).hex]}
 fun dataState()=_m["cas/pack" j stamp(File(capsule,"cas/pack")),"beliefs.wal" j stamp(File(capsule,"beliefs.wal")),"host/.kanban/board.wal" j stamp(File(capsule,"host/.kanban/board.wal"))]
 val before=dataState();val leaseFile=File(capsule,"host/.kanban/board.wal.lock");check(!leaseFile.exists())
 val files=JvmFileOperations();val cas=PackCasStore(files,File(capsule,"cas").path);val owner=SupervisorJob(coroutineContext[Job]);val beliefWal=DocumentAppendLog.open(File(capsule,"beliefs.wal").path,capsule.path);val beliefFrames=mutableListOf<Map<String,Any?>>()
 beliefWal.replay{seq,bytes->beliefFrames.add(_m["sequence" j seq,"payloadUtf8" j bytes.decodeToString(throwOnInvalidSequence=true),"sha256" j ContentId.of(bytes).hex])}
 check(beliefFrames.size==6);check(beliefFrames.map{(it["payloadUtf8"] as String).substringBefore(':')}==_l["R","B","A","A","D","E"])
 val bag=BeliefBagElement(cas=cas,wal=beliefWal,flushEvery=1000,priorityFloor=.5f,parentJob=owner);bag.open();bag.awaitProcessed();check(bag.size==0)
 val boardWal=BoardFileWal(files,File(capsule,"host/.kanban").path);val boardFrames=mutableListOf<Map<String,Any?>>()
 fun leaseMetadata():Map<String,Any?> {val a=java.nio.file.Files.readAttributes(leaseFile.toPath(),java.nio.file.attribute.BasicFileAttributes::class.java);return _m["path" j leaseFile.path,"fileKey" j a.fileKey().toString(),"bytes" j a.size(),"mtimeMillis" j a.lastModifiedTime().toMillis()]}
 val leaseWhileHeld=leaseMetadata() // STAT ONLY while this JVM holds the POSIX sidecar lock.
 boardWal.replay{seq,bytes->boardFrames.add(_m["sequence" j seq,"payloadUtf8" j bytes.decodeToString(throwOnInvalidSequence=true),"sha256" j ContentId.of(bytes).hex])};check(boardFrames.size==42)
 val board=BoardStoreElement(wal=boardWal,cas=cas,parentJob=owner);board.open()
 val cards=(manifest["expectedCards"] as List<*>).map{raw->val e=raw as Map<*,*>;val job=e["jobId"] as String;val row=checkNotNull(board.card(job));check(checkNotNull(row.commandCid).value==e["commandCid"]);val command=checkNotNull(board.command(job));val saved=command["lcncRun"] as Map<*,*>;check(saved["runId"]==e["runId"]&&saved["programCid"]==e["programCid"]&&saved["status"]==e["status"]&&saved["ok"]==e["ok"]);_m["label" j e["label"],"jobId" j job,"commandCid" j checkNotNull(row.commandCid).value,"column" j row.col.toString(),"revision" j row.revision,"sequence" j row.lastSequence,"runId" j saved["runId"],"programCid" j saved["programCid"],"status" j saved["status"],"ok" j saved["ok"]]};check(cards.size==14&&board.cards().size==14)
 val readDirectory=File(out,"readbacks").apply{mkdirs()};val selected=(manifest["selectedReadbacks"] as List<*>).associate{raw->val e=raw as Map<*,*>;((e["cid"] as String) j e).pair}
 val reads=(manifest["packRecords"] as List<*>).map{raw->val e=raw as Map<*,*>;check(e["kind"]=="BLOB");val cid=ContentId(e["cid"] as String);val bytes=checkNotNull(cas.getBounded(cid,4*1024*1024));check(ContentId.of(bytes)==cid&&bytes.size==(e["payloadBytes"] as Number).toInt());val target=if(cid.value in selected)File(readDirectory,cid.hex+".bin").also{it.writeBytes(bytes)}else null;_m["cid" j cid.value,"bytes" j bytes.size,"sha256" j ContentId.of(bytes).hex,"selected" j (target!=null),"file" j target?.relativeTo(out)?.path,"roles" j selected[cid.value]?.get("roles")]};check(reads.size==166&&reads.count{it["selected"]==true}==113)
 val source=manifest["C2"] as Map<*,*>;val sourceCid=ContentId(source["sourceCid"] as String);val sourceBytes=checkNotNull(cas.getBounded(sourceCid,4096));check(sourceBytes.decodeToString(throwOnInvalidSequence=true)==source["text"]&&sourceBytes.size==46)
 val request=_m["sourceContext" j sourceCid.value,"predicate" j "pays","subject" j "Tenant"]
 val queryBefore=dataState();val output=NalNodes.recallRunner(bag).run(LcncNode("relocated-readonly-role-query","nal.recall",_m["mode" j "exact-role"]),_m["request" j request]);val selection=output["selection"] as Map<*,*>;check(selection["status"]=="MATCHES_IN_COMPLETE_SOURCE"&&selection["complete"]==true);val matches=selection["matches"] as List<*>;check(matches.size==1);val match=matches.single() as Map<*,*>;check(match["object"]=="Landlord"&&match["propositionCid"]==source["paysPid"]&&match["residentStatus"]=="MATCH_NOT_RESIDENT");check((output["beliefs"] as List<*>).isEmpty()&&output.containsKey("angular")&&output["angular"]==null&&output.containsKey("propositionCid")&&output["propositionCid"]==null);check(bag.size==0);val queryAfter=dataState();check(queryBefore==queryAfter)
 val mounts=File("/proc/self/mountinfo").readLines().filter{line->val a=line.split(' ');a.size>6&&a[4] in _s["/",capsule.path,out.path,oldRoot.path]}.map{line->val halves=line.split(" - ",limit=2);val a=halves[0].split(' ');val fs=halves[1].split(' ');_m["mountPoint" j a[4],"mountOptions" j a[5],"fsType" j fs[0],"source" j fs[1]]}
 check(mounts.any{it["mountPoint"]=="/"&&"ro" in (it["mountOptions"] as String).split(',')});check(mounts.any{it["mountPoint"]==oldRoot.path&&it["fsType"]=="tmpfs"})
 board.drain();board.close();bag.drain();beliefWal.close();owner.complete();owner.join();cas.close();GuestModules.closeAll()
 val after=dataState();check(before==after);val oldAfter=oldVisibility();val leaseAfter=leaseMetadata();check(leaseWhileHeld==leaseAfter)
 val classes=_m["PackCasStore" j PackCasStore::class.java,"DocumentAppendLog" j DocumentAppendLog::class.java,"BeliefBagElement" j BeliefBagElement::class.java,"BoardFileWal" j BoardFileWal::class.java,"BoardStoreElement" j BoardStoreElement::class.java,"NalNodes" j NalNodes::class.java,"KgRetention" j KgRetention::class.java,"SignalCodec" j SignalCodec::class.java,"SparqlSurface" j SparqlSurface::class.java,"QuadStore" j QuadStore::class.java]
 val origins=classes.mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also{check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))}}
 val namespaces=_l["mnt","net","user","pid"].associateWith{java.nio.file.Files.readSymbolicLink(java.nio.file.Path.of("/proc/self/ns/$it")).toString()}
 File(out,"result.json").writeText(jsonOf(_m["result" j "PASS","pid" j ProcessHandle.current().pid(),"parentPid" j ProcessHandle.current().parent().map{it.pid()}.orElse(-1L),"sourceHead" j manifest["sourceHead"],"mainSha256" j manifest["mainSha256"],"manifestSha256" j ContentId.of(manifestFile.readBytes()).hex,"capsule" j capsule.path,"oldProducerRoot" j oldRoot.path,"oldBefore" j oldBefore,"oldAfter" j oldAfter,"namespaces" j namespaces,"mounts" j mounts,"beforeOpen" j before,"afterClose" j after,"leaseAbsentBeforeOpen" j true,"newLeaseWhileHeld" j leaseWhileHeld,"newLeaseAfterClose" j leaseAfter,"beliefFrames" j beliefFrames,"boardFrames" j boardFrames,"recoveredCards" j cards,"actualPayloadReadbacks" j reads,"query" j _m["request" j request,"nodeOutputs" j output,"before" j queryBefore,"after" j queryAfter],"finalReplayedBagRows" j emptyList<Any?>(),"origins" j origins,"observerCodeSource" j ObserverMarker::class.java.protectionDomain.codeSource.location.toString(),"closed" j _m["board" j board.supervisor.isCompleted,"bag" j bag.supervisor.isCompleted,"bagWorker" j (bag.worker?.isCompleted==true),"owner" j owner.isCompleted,"remainingChildren" j owner.children.count(),"cas" j true,"guestModules" j GuestModules.closed.isCompleted],"scope" j "Three-file closed-data relocation and one request-local typed role query, with old proof root hidden. External Java/main+119JARs/observer remain required. No admission, attention, revival, server, browser, parser/model, executable portability, fullseal or network federation."]))
}
