"""OS observations and one production-reader subprocess; executes only inside bwrap."""
from pathlib import Path
import os,sys,json,subprocess,socket,errno
out=Path(sys.argv[1]);capsule=Path(sys.argv[2]);root=Path(sys.argv[3]);snapshot=Path(sys.argv[4]);classes=Path(sys.argv[5]);old=Path(sys.argv[6]);assert not(old/'native-attempt4/runtime/cas/pack').exists()
subprocess.run(['ip','link','set','lo','up'],check=True)
network={'controllerPid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net'),'mountNamespace':os.readlink('/proc/self/ns/mnt'),'interfaces':json.loads(subprocess.check_output(['ip','-j','addr'],text=True)),'routes':json.loads(subprocess.check_output(['ip','-j','route'],text=True))}
assert len(network['interfaces'])==1 and network['interfaces'][0]['ifname']=='lo' and network['routes']==[]
try:socket.create_connection(('1.1.1.1',443),timeout=2);raise RuntimeError('Unexpected external route')
except OSError as e:assert e.errno==errno.ENETUNREACH;network['externalTcp']={'errno':e.errno,'message':str(e)}
(out/'network.json').write_text(json.dumps(network,indent=2)+'\n');(out/'empty-subvm').mkdir();(out/'tmp').mkdir();(out/'home').mkdir()
cp=str(classes)+':'+(snapshot/'classpath.txt').read_text().strip();cmd=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-Xmx768m','--enable-native-access=ALL-UNNAMED','-Dtrikeshed.airgap=true','-Djava.io.tmpdir='+str(out/'tmp'),'-Duser.home='+str(out/'home'),'-cp',cp,'proof.narscapsule.CapsuleReaderKt',str(capsule),str(root/'verification-manifest.json'),str(out),str(snapshot),str(old)]
(out/'reader-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'reader.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
(out/'reader.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
result=json.loads((out/'result.json').read_text());assert result['namespaces']['net']==network['networkNamespace'];assert result['oldBefore']==result['oldAfter'] and not any(result['oldBefore'].values())
