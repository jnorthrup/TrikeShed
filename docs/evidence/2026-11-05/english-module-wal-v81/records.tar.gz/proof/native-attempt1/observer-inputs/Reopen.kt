package proof.englishwal

import borg.trikeshed.couch.*
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.*
import borg.trikeshed.memory.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

/** Fresh JVM acquires the released real board WAL and rebuilds its committed projection; no new command/run. */
fun main(args:Array<String>)=runBlocking {
 val out=File(args[0]).canonicalFile;val runtime=File(out,"runtime");val writer=reifyStrict(File(out,"cleanup.json").readText()) as Map<*,*>
 require(File(out,"GO.json").isFile);check((writer["pid"] as Number).toLong()!=ProcessHandle.current().pid())
 java.lang.System.setProperty(GuestModules.HOME_PROPERTY,File(out,"empty-subvm").path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 fun stamp(f:File):Map<String,Any?> {val b=f.readBytes();return mapOf("bytes" to b.size,"sha256" to ContentId.of(b).hex)}
 val directory=File(runtime,"host/.kanban").canonicalFile;val walFile=File(directory,"board.wal");val lockFile=File(directory,"board.wal.lock");val pack=File(runtime,"cas/pack")
 // This fresh process owns no lease yet, so hashing the stable sidecar is safe here.
 val before=mapOf("wal" to stamp(walFile),"lease" to stamp(lockFile),"pack" to stamp(pack))
 val holder=reifyStrict(File(out,"holder-after-contend.json").readText()) as Map<*,*>;val holderJournal=holder["journal"] as Map<*,*>;check(stamp(walFile)["sha256"]==(holderJournal["wal"] as Map<*,*>)["sha256"]&&stamp(pack)["sha256"]==(holder["pack"] as Map<*,*>)["sha256"])
 fun sourceFiles():Map<String,Any?> {
  val cases=reifyStrict(File(out,"cases.json").readText()) as Map<*,*>
  val projects=cases.values.map{((it as Map<*,*>)["row"] as Map<*,*>)["project"] as String}.distinct()
  return mapOf("ledger" to stamp(File(runtime,"projects.tsv")),"projects" to projects.associateWith{project->mapOf("head" to stamp(File(runtime,"project-couch/$project/HEAD")),"manifest" to stamp(File(runtime,"project-manifests/$project.tsv")))})
 }
 fun lockMetadata():Map<String,Any?> {val a=java.nio.file.Files.readAttributes(lockFile.toPath(),java.nio.file.attribute.BasicFileAttributes::class.java);return mapOf("path" to lockFile.canonicalPath,"fileKey" to a.fileKey().toString(),"bytes" to a.size(),"mtimeMillis" to a.lastModifiedTime().toMillis())}
 val sourcesBefore=sourceFiles();val lockBefore=lockMetadata()
 val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").path);val owner=SupervisorJob(coroutineContext[Job])
 val wal=BoardFileWal(files,directory.path);val lockWhileHeld=lockMetadata();val frames=mutableListOf<Map<String,Any?>>()
 wal.replay{sequence,bytes->frames.add(mapOf("sequence" to sequence,"payloadUtf8" to bytes.decodeToString(throwOnInvalidSequence=true),"payloadSha256" to ContentId.of(bytes).hex))}
 val board=BoardStoreElement(wal=wal,cas=cas,parentJob=owner);board.open()
 val browser=reifyStrict(File(out,"browser-result.json").readText()) as Map<*,*>;val observed=browser["observed"] as Map<*,*>;val run=(observed["nalRun"] as Map<*,*>)["reply"] as Map<*,*>
 val jobId=run["jobId"] as String;val card=checkNotNull(board.card(jobId));check(checkNotNull(card.commandCid).value==run["receiptCid"])
 val command=checkNotNull(board.command(jobId));val saved=command["lcncRun"] as Map<*,*>;check(saved["runId"]==run["runId"]&&saved["programCid"]==run["programCid"]&&saved["status"]=="completed"&&saved["ok"]==true)
 val durable=checkNotNull(cas.getBounded(ContentId(run["receiptCid"] as String),4*1024*1024));check(ContentId.of(durable).value==run["receiptCid"])
 val expected=reifyStrict(durable.decodeToString()) as Map<*,*>;check(command==expected)
 val index=reifyStrict(File(out,"readback-index.json").readText()) as List<*>;val readbacks=index.map{raw->val e=raw as Map<*,*>;val cid=ContentId(e["cid"] as String);val bytes=checkNotNull(cas.getBounded(cid,4*1024*1024));check(ContentId.of(bytes)==cid&&bytes.contentEquals(File(out,e["file"] as String).readBytes()));mapOf("cid" to cid.value,"bytes" to bytes.size,"sha256" to ContentId.of(bytes).hex,"role" to e["role"])}
 val cases=reifyStrict(File(out,"cases.json").readText()) as Map<*,*>;val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas);val registry=ProjectDbRegistry("primary")
 val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,projectDbs=registry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"));check(scopes.remountLedger()==1);val corpus=JvmProjectCorpus(registry,scopes)
 val rows=cases.mapValues{(_,raw)->val c=raw as Map<*,*>;val old=c["row"] as Map<*,*>;val row=checkNotNull(corpus.document(old["project"] as String,old["id"] as String));check(row.cid==old["cid"]&&row.rev==old["rev"]&&row.seq==(old["seq"] as Number).toLong());val s=EnglishObservationGraph.read(cas,ContentId(c["inspectionCid"] as String));check(s.source.text==c["text"]);row.toMap()}
 val recovered=mapOf("lastSequence" to board.lastSequence,"cardCount" to board.cards().size,"card" to mapOf("jobId" to card.jobId,"col" to card.col.toString(),"revision" to card.revision,"lastSequence" to card.lastSequence,"commandCid" to checkNotNull(card.commandCid).value),"command" to command)
 board.drain();board.close();scopes.drain();owner.complete();owner.join();cas.close();GuestModules.closeAll()
 // No held sidecar lease remains in this process after board drain/close.
 val after=mapOf("wal" to stamp(walFile),"lease" to stamp(lockFile),"pack" to stamp(pack));check(before==after);val sourcesAfter=sourceFiles();check(sourcesBefore==sourcesAfter);val lockAfter=lockMetadata();check(lockBefore==lockWhileHeld&&lockBefore==lockAfter)
 File(out,"reopened.json").writeText(jsonOf(mapOf("result" to "PASS","readerPid" to ProcessHandle.current().pid(),"writerPid" to writer["pid"],"writerCleanup" to writer,"directory" to directory.path,"beforeOpen" to before,"afterClose" to after,"sourceFilesBeforeOpen" to sourcesBefore,"sourceFilesAfterClose" to sourcesAfter,"lockMetadataBeforeOpen" to lockBefore,"lockMetadataWhileHeld" to lockWhileHeld,"lockMetadataAfterClose" to lockAfter,"frames" to frames,"recovered" to recovered,"readbacks" to readbacks,"currentUnchangedRows" to rows,"boardOwnerCompleted" to board.supervisor.isCompleted,"parentOwnerCompleted" to owner.isCompleted,"remainingChildren" to owner.children.count(),"casClosed" to true,"guestModulesClosed" to GuestModules.closed.isCompleted,"codeSources" to mapOf("BoardFileWal" to BoardFileWal::class.java.protectionDomain.codeSource.location.toString(),"BoardStoreElement" to BoardStoreElement::class.java.protectionDomain.codeSource.location.toString(),"PackCasStore" to PackCasStore::class.java.protectionDomain.codeSource.location.toString()),"scope" to "Fresh exclusive board lease acquisition and recovery after graceful production-module close; exact committed run/CAS/program/outputs and source heads retained, no new run/append, tail injection, model/parser or hardware/crash-durability claim")))
}
