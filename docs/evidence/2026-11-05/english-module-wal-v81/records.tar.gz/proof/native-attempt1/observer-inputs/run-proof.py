"""Prepared only; invoke after explicit root GREEN/frozen GO with matching metadata."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,zipfile,time,urllib.request,socket,errno
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if '--inside' in sys.argv:
 attempt=Path(sys.argv[2]);snapshot=Path(sys.argv[3]);classes=Path(sys.argv[4]);asset=Path(sys.argv[5]);port=18778
 assert os.readlink('/proc/self/ns/net')!=json.loads((attempt/'controller-before-netns.json').read_text())['networkNamespace']
 subprocess.run(['ip','link','set','lo','up'],check=True)
 network={'networkNamespace':os.readlink('/proc/self/ns/net'),'interfaces':subprocess.check_output(['ip','-j','addr'],text=True),'routes':subprocess.check_output(['ip','-j','route'],text=True)}
 try:socket.create_connection(('1.1.1.1',443),timeout=2);raise RuntimeError('Unexpected external route')
 except OSError as e:assert e.errno==errno.ENETUNREACH;network['externalTcp']={'errno':e.errno,'message':str(e)}
 (attempt/'network.json').write_text(json.dumps(network,indent=2)+'\n')
 cp=(snapshot/'classpath.txt').read_text().strip();runtimecp=str(classes)+':'+cp+':'+str(asset)
 cmd=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-Xmx768m','--enable-native-access=ALL-UNNAMED','-Dtrikeshed.airgap=true','-cp',runtimecp,'proof.englishwal.FixtureKt',str(attempt),str(snapshot),str(port)]
 (attempt/'writer-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (attempt/'writer.log').open('w') as log:
  writer=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
  try:
   http=urllib.request.build_opener(urllib.request.ProxyHandler({}));started=time.monotonic()
   while True:
    if writer.poll() is not None:raise RuntimeError('Writer exited before ready')
    try:
     with http.open('http://127.0.0.1:'+str(port)+'/__v81/meta',timeout=2) as response:assert response.status==200
     break
    except OSError:
     if time.monotonic()-started>90:raise
     time.sleep(.2)
   env=os.environ.copy();env.update(PROOF_URL='http://127.0.0.1:'+str(port),PROOF_ARTIFACTS=str(attempt))
   with (attempt/'browser.log').open('w') as browserlog:browser=subprocess.run(['node',str(root/'driver.cjs')],env=env,stdout=browserlog,stderr=subprocess.STDOUT,timeout=900)
   (attempt/'browser.exit').write_text(str(browser.returncode)+'\n');assert browser.returncode==0,'Actual browser failure preserved'
   # External controller has no lease: sidecar hashing here cannot close a descriptor in holder JVM.
   def json_state():
    with http.open('http://127.0.0.1:'+str(port)+'/__v81/state',timeout=10) as response:return json.load(response)
   before=json_state();directory=Path(before['journal']['directory']);wal=directory/'board.wal';sidecar=directory/'board.wal.lock'
   def disk_state():return {p.name:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'inode':p.stat().st_ino,'mtimeNs':p.stat().st_mtime_ns} for p in [wal,sidecar]}
   disk_before=disk_state();(attempt/'holder-before-contend.json').write_text(json.dumps(before,indent=2)+'\n')
   probe_cmd=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-Xmx256m','--enable-native-access=ALL-UNNAMED','-cp',runtimecp,'proof.englishwal.LeaseProbeKt',str(directory),str(attempt/'contender.json'),str(snapshot)]
   (attempt/'contender-command.json').write_text(json.dumps(probe_cmd,indent=2)+'\n')
   with (attempt/'contender.log').open('w') as probe_log:probe=subprocess.run(probe_cmd,stdout=probe_log,stderr=subprocess.STDOUT,timeout=30)
   (attempt/'contender.exit').write_text(str(probe.returncode)+'\n');assert probe.returncode==42,'Actual live-owner refusal required'
   after=json_state();disk_after=disk_state();assert disk_before==disk_after
   assert before['blackboard']==after['blackboard'] and before['rows']==after['rows'] and before['pack']==after['pack'] and before['journal']==after['journal']
   (attempt/'holder-after-contend.json').write_text(json.dumps(after,indent=2)+'\n');(attempt/'contender-controller-state.json').write_text(json.dumps({'controllerPid':os.getpid(),'before':disk_before,'after':disk_after,'writerAliveBeforeAndAfter':writer.poll() is None,'method':'Sidecar bytes hashed only in non-owning controller/probe PIDs, never in lease-holder JVM'},indent=2)+'\n')

  finally:
   try:http.open(urllib.request.Request('http://127.0.0.1:'+str(port)+'/__v81/finish',data=b'',method='POST'),timeout=5).read()
   except OSError:pass
   try:writer.wait(timeout=90)
   except subprocess.TimeoutExpired:writer.terminate();writer.wait(timeout=15);raise
   (attempt/'writer.exit').write_text(str(writer.returncode)+'\n')
 assert writer.returncode==0
 closed_readbacks=attempt/'after-close-readbacks';closed_readbacks.mkdir()
 shutil.copy2(attempt/'runtime/host/.kanban/board.wal',closed_readbacks/'board.wal')
 readercmd=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-Xmx768m','--enable-native-access=ALL-UNNAMED','-cp',runtimecp,'proof.englishwal.ReopenKt',str(attempt)]
 (attempt/'reader-command.json').write_text(json.dumps(readercmd,indent=2)+'\n')
 with (attempt/'reader.log').open('w') as log:reader=subprocess.run(readercmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 (attempt/'reader.exit').write_text(str(reader.returncode)+'\n');assert reader.returncode==0
 sys.exit(0)
assert len(sys.argv)==3 and sys.argv[1]=='--root-frozen-go','Root GREEN/frozen GO required; preparation must not execute'
go=json.loads(Path(sys.argv[2]).read_text());assert go['rootGreen'] is True
snapshot=Path(go['snapshot']);assert (snapshot/'source-head.txt').read_text().strip()==go['sourceHead']
for name,key in [('main.jar','mainSha256'),('spacegraph.js','spacegraphSha256'),('documents.js','documentsSha256')]:assert sha(snapshot/name)==go[key]
cp=(snapshot/'classpath.txt').read_text().strip().split(':');pins=json.loads((snapshot/'sha256.json').read_text());assert len(cp)==120 and len(pins['dependencies'])==119
for p in map(Path,cp):assert p.is_file() and p.suffix=='.jar' and sha(p)==(go['mainSha256'] if p==snapshot/'main.jar' else pins['dependencies'][str(p)])
attempt=root/'native-attempt1';shutil.copytree(root/'native-prepared',attempt);metadata=attempt/'artifact-metadata';metadata.mkdir();
for name in ['source-head.txt','sha256.json','classpath.txt']:shutil.copy2(snapshot/name,metadata/name)
(attempt/'GO.json').write_text(json.dumps(go,indent=2)+'\n');(root/'ACTIVE_GO.json').write_text(json.dumps(go,indent=2)+'\n')
observerInputs=attempt/'observer-inputs';observerInputs.mkdir()
for name in ['Fixture.kt','Reopen.kt','LeaseProbe.kt','driver.cjs','run-proof.py','compile.sh','protocol.txt','preparation.json']:shutil.copy2(root/name,observerInputs/name)
classes=root/'observer-attempt1'
with (root/'compile-attempt1.log').open('w') as log:compile_result=subprocess.run(['bash',str(root/'compile.sh'),str(snapshot),str(classes)],stdout=log,stderr=subprocess.STDOUT)
(root/'compile-attempt1.exit').write_text(str(compile_result.returncode)+'\n');assert compile_result.returncode==0
asset=root/'frozen-browser-assets.jar';entries={}
with zipfile.ZipFile(asset,'w',compression=zipfile.ZIP_STORED) as z:
 for app,file in [('spacegraph','spacegraph.js'),('documents','documents.js')]:
  data=(snapshot/file).read_bytes();name='web/kotlin/'+app+'/'+file;info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));z.writestr(info,data);entries[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(asset) as z:assert set(z.namelist())==set(entries) and not any(n.endswith('.class') for n in z.namelist())
(attempt/'classpath.json').write_text(json.dumps({'productionDependencyJars':120,'productionClasspath':[{'path':p,'sha256':sha(Path(p))} for p in cp],'assetJar':{'path':str(asset),'bytes':asset.stat().st_size,'sha256':sha(asset),'entries':entries},'observerClasses':str(classes),'totalJarCount':121,'totalClasspathEntries':122},indent=2)+'\n')
(attempt/'controller-before-netns.json').write_text(json.dumps({'pid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net')},indent=2)+'\n')
cmd=['unshare','--user','--map-root-user','--net','python3',str(root/'run-proof.py'),'--inside',str(attempt),str(snapshot),str(classes),str(asset)]
(attempt/'namespace-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
result=subprocess.run(cmd);(attempt/'namespace.exit').write_text(str(result.returncode)+'\n');assert result.returncode==0
