package proof.englishwal

import borg.trikeshed.kanban.BoardFileWal
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.job.ContentId
import borg.trikeshed.parse.jsonOf
import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import kotlin.system.exitProcess

/** Separate real JVM contender. No CAS, parser, board module or replacement WAL. */
fun main(args:Array<String>) {
 val directory=File(args[0]).canonicalFile;val output=File(args[1]);val snapshot=File(args[2]).canonicalFile
 fun fileState(file:File):Map<String,Any?> {val b=file.readBytes();val a=Files.readAttributes(file.toPath(),BasicFileAttributes::class.java);return mapOf("path" to file.canonicalPath,"bytes" to b.size,"sha256" to ContentId.of(b).hex,"fileKey" to a.fileKey().toString(),"mtimeMillis" to a.lastModifiedTime().toMillis())}
 val wal=File(directory,"board.wal");val sidecar=File(directory,"board.wal.lock");require(wal.isFile&&sidecar.isFile)
 val before=mapOf("wal" to fileState(wal),"lease" to fileState(sidecar))
 val mainOrigin=BoardFileWal::class.java.protectionDomain.codeSource.location.toString();check(File(java.net.URI(mainOrigin)).canonicalFile==File(snapshot,"main.jar"))
 val refusal=try {BoardFileWal(JvmFileOperations(),directory.path).close();null}catch(t:Throwable){t}
 val after=mapOf("wal" to fileState(wal),"lease" to fileState(sidecar));check(after==before){"Contender changed active WAL or lease sidecar"}
 check(refusal!=null && refusal.message.orEmpty().contains("lease",ignoreCase=true)){"Actual active module lease was not refused: $refusal"}
 output.writeText(jsonOf(mapOf("result" to "EXPECTED_LIVE_OWNER_LEASE_REFUSAL","pid" to ProcessHandle.current().pid(),"parentPid" to ProcessHandle.current().parent().map{it.pid()}.orElse(-1L),"directory" to directory.path,"before" to before,"after" to after,"refusal" to mapOf("type" to refusal.javaClass.name,"message" to refusal.message,"stack" to refusal.stackTrace.take(8).map{it.toString()}),"codeSources" to mapOf("BoardFileWal" to mainOrigin,"JvmFileOperations" to JvmFileOperations::class.java.protectionDomain.codeSource.location.toString()),"scope" to "Real public filesystem constructor refused before opening/recovering WAL; no append/replay/truncation attempted by observer")))
 exitProcess(42)
}
