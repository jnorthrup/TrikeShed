import pathlib,json,hashlib,shutil,subprocess,xml.etree.ElementTree as ET,datetime
root=pathlib.Path('/workspace/TrikeShed')
source='92510e6a1bff13a71b0ad9a76ba261498932e9ba'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
work=pathlib.Path('/workspace/library-files/curation-next')
assert (work/'build-v88.exit').read_text().strip()=='0'
log=(work/'build-v88.log').read_text(); assert 'BUILD SUCCESSFUL' in log
suites=[]
for f in sorted((root/'build/test-results/jvmTest').glob('TEST-*.xml')):
 t=ET.parse(f).getroot(); suites.append(dict(file=f.name,**{k:t.attrib.get(k) for k in ('name','timestamp','tests','failures','errors','skipped')}))
totals={k:sum(int(s[k] or 0) for s in suites) for k in ('tests','failures','errors','skipped')}
assert totals==dict(tests=540,failures=0,errors=0,skipped=0),totals
snapshot=pathlib.Path('/workspace/library-files/native-horn-docs-v88-proof/snapshot'); snapshot.mkdir(parents=True,exist_ok=False)
old=pathlib.Path('/workspace/library-files/english-query-handoff-v72-proof/snapshot')
oldmanifest=json.loads((old/'sha256.json').read_text()); deps=oldmanifest['dependencies']
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
cp=(old/'classpath.txt').read_text().strip().split(':'); assert len(cp)==120 and len(deps)==119 and cp[1:]==list(deps)
for f,h in deps.items():assert pathlib.Path(f).is_file() and f.endswith('.jar') and sha(pathlib.Path(f))==h,f
assert not subprocess.check_output(['git','diff','c8b7f5e8a5d0dad8e6352d2fc1c733df7d69e563',source,'--','src/commonMain/resources'],cwd=root,text=True)
shutil.copy2(root/'build/libs/TrikeShed-jvm-0.1.0-SNAPSHOT.jar',snapshot/'main.jar')
for app in ('documents','spacegraph','pages'):shutil.copy2(root/f'build/kotlin-webpack/js/{app}DevelopmentExecutable/{app}.js',snapshot/f'{app}.js')
for rel,h in oldmanifest.items():
 if rel.startswith('web/'):
  assert sha(old/rel)==h
  dst=snapshot/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(old/rel,dst)
(snapshot/'source-head.txt').write_text(source+'\n')
(snapshot/'classpath.txt').write_text(':'.join([str(snapshot/'main.jar'),*cp[1:]])+'\n')
shutil.copy2(work/'build-v88.log',snapshot/'passing-build.log')
manifest={str(p.relative_to(snapshot)):sha(p) for p in snapshot.rglob('*') if p.is_file()}; manifest['dependencies']=deps
(snapshot/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
vpath=work/'verification-v88.json'; v=json.loads(vpath.read_text());v.update(result='PASS',totals=totals,suites=suites,allJvmTestSourcesCompiled=True,allThreeBrowserBuilds='PASS',frozenSnapshot=str(snapshot),artifacts={n:manifest[n] for n in ('main.jar','documents.js','spacegraph.js','pages.js')},dependencyJars=119,totalClasspathJars=120,buildLogSha256=manifest['passing-build.log'],buildFinished=datetime.datetime.now(datetime.timezone.utc).isoformat(),actualFrozenNativeProof='PENDING new final-JAR proof')
vpath.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ('source','result','totals','frozenSnapshot','artifacts','totalClasspathJars')},indent=2))
