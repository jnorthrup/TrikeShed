#!/usr/bin/env bash
set -euo pipefail
source /workspace/.trikeshed-cloud/activate.sh
nal_root=/workspace/library-files/native-horn-docs-v88-native-proof
nal_snapshot=${1:?frozen snapshot required}
nal_output=${2:?fresh external class output required}
[[ -f "$nal_root/ACTIVE_GO.json" ]] || { echo 'Root frozen GO required' >&2; exit 1; }
nal_cp=$(cat "$nal_snapshot/classpath.txt")
nal_compiler=$(rg --files --no-ignore /workspace/.trikeshed-cloud/gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.21 | rg '\.jar$' | head -n1)
mkdir "$nal_output"
java -Xmx768m -cp "$nal_compiler:$nal_cp" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 25 -classpath "$nal_cp" -d "$nal_output" "$nal_root/Host.kt" "$nal_root/Reopen.kt"
