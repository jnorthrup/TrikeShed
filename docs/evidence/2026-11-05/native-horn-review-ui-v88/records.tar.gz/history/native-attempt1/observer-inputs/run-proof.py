"""No production source/build input. Execute only with matching root GREEN/frozen GO."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,zipfile,time,urllib.request,socket,errno,threading,re
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--inside' in sys.argv:
 attempt,snapshot,classes,asset=map(Path,sys.argv[2:6]);port=18788
 assert os.readlink('/proc/self/ns/net')!=json.loads((attempt/'controller-before-netns.json').read_text())['networkNamespace']
 subprocess.run(['ip','link','set','lo','up'],check=True)
 network={'networkNamespace':os.readlink('/proc/self/ns/net'),'interfaces':subprocess.check_output(['ip','-j','addr'],text=True),'routes':subprocess.check_output(['ip','-j','route'],text=True)}
 try:socket.create_connection(('1.1.1.1',443),timeout=2);raise RuntimeError('Unexpected external route')
 except OSError as e:assert e.errno==errno.ENETUNREACH;network['externalTcp']={'errno':e.errno,'message':str(e)}
 (attempt/'network.json').write_text(json.dumps(network,indent=2)+'\n')
 cp=str(classes)+':'+(snapshot/'classpath.txt').read_text().strip()+':'+str(asset);java=str(Path(os.environ['JAVA_HOME'])/'bin/java');tmp=attempt/'tmp';tmp.mkdir();cmd=[java,'-Xmx768m','--enable-native-access=ALL-UNNAMED','-Dtrikeshed.airgap=true','-Djava.io.tmpdir='+str(tmp),'-cp',cp,'proof.horndocs.HostKt',str(attempt),str(snapshot),str(port)]
 (attempt/'writer-command.json').write_text(json.dumps(cmd,indent=2)+'\n');trace=attempt/'process.trace';traced=['strace','-f','-s','4096','-e','trace=process','-o',str(trace),*cmd];(attempt/'writer-trace-command.json').write_text(json.dumps(traced,indent=2)+'\n')
 stop=threading.Event();captures={};failures=[];nativeInputs=attempt/'native-inputs';nativeInputs.mkdir()
 def observe_inputs():
  # Bounded exact bytes from the real public owner's ephemeral process input files.
  # They are subsequently bound to actual execve argv in process.trace, never fabricated.
  while not stop.is_set():
   for p in tmp.glob('trikeshed-horn-*/input.json'):
    try:
     if p.stat().st_size>4*1024*1024:raise ValueError('Native input >4MiB')
     data=p.read_bytes();json.loads(data);digest=hashlib.sha256(data).hexdigest();dest=nativeInputs/(digest+'.json');dest.write_bytes(data);captures[str(p)]={'inputCid':'sha256:'+digest,'bytes':len(data),'file':str(dest.relative_to(attempt))}
    except FileNotFoundError:pass
    except (json.JSONDecodeError,UnicodeDecodeError):pass # file may still be being written
    except Exception as e:failures.append(str(e));stop.set()
   stop.wait(.005)
 watcher=threading.Thread(target=observe_inputs);watcher.start()
 with (attempt/'writer.log').open('w') as log:
  writer=subprocess.Popen(traced,stdout=log,stderr=subprocess.STDOUT);http=urllib.request.build_opener(urllib.request.ProxyHandler({}));started=time.monotonic()
  try:
   while True:
    if writer.poll() is not None:raise RuntimeError('Writer exited before ready')
    try:
     with http.open('http://127.0.0.1:'+str(port)+'/__v88/meta',timeout=2) as r:assert r.status==200
     break
    except OSError:
     if time.monotonic()-started>90:raise
     time.sleep(.2)
   env=os.environ.copy();env.update(PROOF_URL='http://127.0.0.1:'+str(port),PROOF_ARTIFACTS=str(attempt))
   with (attempt/'browser.log').open('w') as browser_log:browser=subprocess.run(['node',str(root/'driver.cjs')],env=env,stdout=browser_log,stderr=subprocess.STDOUT,timeout=300)
   (attempt/'browser.exit').write_text(str(browser.returncode)+'\n');assert browser.returncode==0,'Actual browser failure preserved'
   reads=json.loads((attempt/'browser-readback-index.json').read_text());(attempt/'readback-index.json').write_text(json.dumps(reads,indent=2)+'\n')
  finally:
   try:http.open(urllib.request.Request('http://127.0.0.1:'+str(port)+'/__v88/finish',data=b'',method='POST'),timeout=5).read()
   except OSError:pass
   try:writer.wait(timeout=90)
   except subprocess.TimeoutExpired:writer.terminate();writer.wait(timeout=15);raise
   finally:
    (attempt/'writer.exit').write_text(str(writer.returncode)+'\n');stop.set();watcher.join();(attempt/'native-input-capture.json').write_text(json.dumps({'captures':captures,'errors':failures,'scope':'Exact ephemeral input files captured from actual owner process IO; raw trace binds argv. Not native stdout or CAS retention.'},indent=2)+'\n')
 assert writer.returncode==0 and not failures
 rawtrace=trace.read_text();browserresult=json.loads((attempt/'browser-result.json').read_text());inputCid=browserresult['observed']['primaryPlain']['response']['inputCid'];assert inputCid in [e['inputCid'] for e in captures.values()];assert all('"'+p+'"' in rawtrace for p in captures)
 after=attempt/'after-close-readbacks';after.mkdir()
 for source,name in [(attempt/'runtime/host/.kanban/board.wal','board.wal'),(attempt/'runtime/host/documents/review.wal','review.wal')]:shutil.copy2(source,after/name)
 readercmd=[java,'-Xmx768m','--enable-native-access=ALL-UNNAMED','-cp',cp,'proof.horndocs.ReopenKt',str(attempt)];(attempt/'reader-command.json').write_text(json.dumps(readercmd,indent=2)+'\n')
 with (attempt/'reader.log').open('w') as log:reader=subprocess.run(readercmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 (attempt/'reader.exit').write_text(str(reader.returncode)+'\n');assert reader.returncode==0;sys.exit(0)
assert len(sys.argv)==3 and sys.argv[1]=='--root-frozen-go','Explicit root GREEN/frozen GO required'
rootGoBytes=Path(sys.argv[2]).read_bytes();go=json.loads(rootGoBytes);assert go.get('rootGreen',go.get('GO')) is True or (go.get('actualNativeUI','').startswith('GO:') and go.get('authorizedBy')=='Root explicit runtimeGO message after verified540 build/freeze');go.setdefault('GO',True);go.setdefault('mainSha256',go['artifacts']['main.jar']);go['metadataNormalization']='ExternalcanonicalGO/mainSha256 aliases only; original-root-GO.json retains exactrootauthorization';snapshot=Path(go['snapshot']);assert (snapshot/'source-head.txt').read_text().strip()==go.get('sourceHead',go.get('source'))
for name,key in [('main.jar','mainSha256'),('spacegraph.js','spacegraphSha256'),('documents.js','documentsSha256')]:assert sha(snapshot/name)==go.get(key,go.get('artifacts',{}).get(name))
cp=(snapshot/'classpath.txt').read_text().strip().split(':');pins=json.loads((snapshot/'sha256.json').read_text());assert len(cp)==120 and len(pins['dependencies'])==119
for p in map(Path,cp):assert p.is_file() and p.suffix=='.jar' and sha(p)==(go['mainSha256'] if p==snapshot/'main.jar' else pins['dependencies'][str(p)])
number=os.environ.get('PROOF_ATTEMPT','1');assert number.isdigit();attempt=root/('native-attempt'+number);shutil.copytree(root/'native-prepared',attempt);shutil.copy2(root/'input-allowlist.json',attempt/'input-allowlist.json');metadata=attempt/'artifact-metadata';metadata.mkdir();(metadata/'original-root-GO.json').write_bytes(rootGoBytes)
for name in ['source-head.txt','sha256.json','classpath.txt']:shutil.copy2(snapshot/name,metadata/name)
(attempt/'GO.json').write_text(json.dumps(go,indent=2)+'\n');(root/'ACTIVE_GO.json').write_text(json.dumps(go,indent=2)+'\n');observer=attempt/'observer-inputs';observer.mkdir()
for name in ['Host.kt','Reopen.kt','driver.cjs','run-proof.py','compile.sh','protocol.txt','preparation.json','corpus-inputs.json','fixture-config.json','manual-native-proof.kif','native-profile.json']:shutil.copy2(root/name,observer/name)
shutil.copytree(root/'native',observer/'native');(observer/'manifest.json').write_text(json.dumps({str(p.relative_to(observer)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in observer.rglob('*') if p.is_file()},indent=2)+'\n')
classes=root/('observer-attempt'+number)
with (root/('compile-attempt'+number+'.log')).open('w') as log:compiled=subprocess.run(['bash',str(root/'compile.sh'),str(snapshot),str(classes)],stdout=log,stderr=subprocess.STDOUT)
(root/('compile-attempt'+number+'.exit')).write_text(str(compiled.returncode)+'\n');assert compiled.returncode==0
asset=root/'frozen-browser-assets.jar';entries={}
with zipfile.ZipFile(asset,'w',compression=zipfile.ZIP_STORED) as z:
 for app,file in [('spacegraph','spacegraph.js'),('documents','documents.js')]:
  data=(snapshot/file).read_bytes();name='web/kotlin/'+app+'/'+file;z.writestr(zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0)),data);entries[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(asset) as z:assert set(z.namelist())==set(entries) and not any(n.endswith('.class') for n in z.namelist())
(attempt/'classpath.json').write_text(json.dumps({'productionDependencyJars':120,'productionClasspath':[{'path':p,'sha256':sha(Path(p))} for p in cp],'assetJar':{'path':str(asset),'bytes':asset.stat().st_size,'sha256':sha(asset),'entries':entries},'observerClasses':str(classes),'totalJarCount':121,'totalClasspathEntries':122},indent=2)+'\n');(attempt/'controller-before-netns.json').write_text(json.dumps({'pid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net')},indent=2)+'\n')
cmd=['unshare','--user','--map-root-user','--net','python3',str(root/'run-proof.py'),'--inside',str(attempt),str(snapshot),str(classes),str(asset)];(attempt/'namespace-command.json').write_text(json.dumps(cmd,indent=2)+'\n');result=subprocess.run(cmd);(attempt/'namespace.exit').write_text(str(result.returncode)+'\n');assert result.returncode==0
