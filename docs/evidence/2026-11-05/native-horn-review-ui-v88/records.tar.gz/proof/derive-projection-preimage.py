"""Recorded supplied-data identity derivation only; not a query/proof evaluator or CAS export."""
from pathlib import Path
import json,hashlib,math
p=Path(__file__).resolve().parent/'native-attempt4';record=json.loads((p/'browser-result.json').read_text());report=record['observed']['primaryPlain']['response']
def header(major,n):
 if n<24:return bytes([major*32+n])
 for width,ai in [(1,24),(2,25),(4,26),(8,27)]:
  if n<1<<(width*8):return bytes([major*32+ai])+n.to_bytes(width,'big')
 raise ValueError('CBOR range')
def normalize(v):
 if isinstance(v,bool) or v is None or isinstance(v,str):return v
 if isinstance(v,(float,int)):assert math.isfinite(v) and 0<=v<=9007199254740991 and v%1==0;return int(v)
 if isinstance(v,list):return list(map(normalize,v))
 if isinstance(v,dict):return {k:normalize(x) for k,x in v.items()}
 raise ValueError(type(v))
def encode(v):
 if v is None:return b'\xf6'
 if isinstance(v,bool):return b'\xf5' if v else b'\xf4'
 if isinstance(v,int):return header(0,v)
 if isinstance(v,str):b=v.encode();return header(3,len(b))+b
 if isinstance(v,list):return header(4,len(v))+b''.join(map(encode,v))
 if isinstance(v,dict):return header(5,len(v))+b''.join(encode(k)+encode(v[k]) for k in sorted(v,key=encode))
 raise ValueError(type(v))
fields=['inputCid','frameId','snapshotCid','revision','readCid','approvalCid','decisionCid','reviewer','synthetic','policy','scope','coverage','selectionCount','selectionLimit','status','semantics','firstProofOnly','query','proof','checkedProof','sourceEvidence','hostRules','execution','solverStepBudget','nativeBinarySha256','nativeAdapterSha256','sumoNixRevision'];context={f:report.get(f) for f in fields};context['mlirNixRevision']='1547e4a37ea1393a7cd3e3cfe7a89aff38a36dba';domain=normalize({'kind':'native-horn-proof-quads/1','context':context});data=encode(domain);digest='sha256:'+hashlib.sha256(data).hexdigest();assert digest==record['observed']['substitutions']['http']['response']['quadQuery']['provenance']['projectionCid'];(p/'derived-projection-domain-preimage.cbor').write_bytes(data);(p/'derived-projection-domain-preimage.json').write_text(json.dumps(domain,indent=2)+'\n');(p/'derived-projection-identity.json').write_text(json.dumps({'projectionCid':digest,'bytes':len(data),'cborFile':'derived-projection-domain-preimage.cbor','domainFile':'derived-projection-domain-preimage.json','basis':'Exact fields from actual authenticated plain report, recursively integral-normalized, plus public fixed MLIR revision; actual public finalJAR projector CID equality checked.','scope':'Derived canonical domain preimage from recorded data; NOT retained CAS, raw native stdout, independent proof-search or review authority.'},indent=2)+'\n');print(digest,len(data))
