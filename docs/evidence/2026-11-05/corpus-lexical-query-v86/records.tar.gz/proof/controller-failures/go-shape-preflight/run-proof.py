"""HOLD until explicit matching root GREEN/frozen GO. No source/Gradle/live output input."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,zipfile,time,urllib.request,socket,errno
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--inside' in sys.argv:
 attempt,snapshot,classes,asset=map(Path,sys.argv[2:6]);port=18786
 assert os.readlink('/proc/self/ns/net')!=json.loads((attempt/'controller-before-netns.json').read_text())['networkNamespace']
 subprocess.run(['ip','link','set','lo','up'],check=True)
 network={'networkNamespace':os.readlink('/proc/self/ns/net'),'interfaces':subprocess.check_output(['ip','-j','addr'],text=True),'routes':subprocess.check_output(['ip','-j','route'],text=True)}
 try:socket.create_connection(('1.1.1.1',443),timeout=2);raise RuntimeError('Unexpected external route')
 except OSError as e:assert e.errno==errno.ENETUNREACH;network['externalTcp']={'errno':e.errno,'message':str(e)}
 (attempt/'network.json').write_text(json.dumps(network,indent=2)+'\n')
 cp=str(classes)+':'+(snapshot/'classpath.txt').read_text().strip()+':'+str(asset);java=str(Path(os.environ['JAVA_HOME'])/'bin/java');cmd=[java,'-Xmx768m','--enable-native-access=ALL-UNNAMED','-Dtrikeshed.airgap=true','-cp',cp,'proof.corpusquery.FixtureKt',str(attempt),str(snapshot),str(port)]
 (attempt/'writer-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (attempt/'writer.log').open('w') as log:
  writer=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);http=urllib.request.build_opener(urllib.request.ProxyHandler({}));started=time.monotonic()
  try:
   while True:
    if writer.poll() is not None:raise RuntimeError('Writer exited before ready')
    try:
     with http.open('http://127.0.0.1:'+str(port)+'/__v86/meta',timeout=2) as r:assert r.status==200
     break
    except OSError:
     if time.monotonic()-started>90:raise
     time.sleep(.2)
   env=os.environ.copy();env.update(PROOF_URL='http://127.0.0.1:'+str(port),PROOF_ARTIFACTS=str(attempt))
   with (attempt/'browser.log').open('w') as browser_log:browser=subprocess.run(['node',str(root/'driver.cjs')],env=env,stdout=browser_log,stderr=subprocess.STDOUT,timeout=600)
   (attempt/'browser.exit').write_text(str(browser.returncode)+'\n');assert browser.returncode==0,'Actual browser failure preserved'

  finally:
   try:http.open(urllib.request.Request('http://127.0.0.1:'+str(port)+'/__v86/finish',data=b'',method='POST'),timeout=5).read()
   except OSError:pass
   try:writer.wait(timeout=90)
   except subprocess.TimeoutExpired:writer.terminate();writer.wait(timeout=15);raise
   (attempt/'writer.exit').write_text(str(writer.returncode)+'\n')
 assert writer.returncode==0
 after=attempt/'after-close-readbacks';after.mkdir()
 for source,name in [(attempt/'runtime/host/.kanban/board.wal','board.wal')]:shutil.copy2(source,after/name)
 readercmd=[java,'-Xmx768m','--enable-native-access=ALL-UNNAMED','-cp',cp,'proof.corpusquery.ReopenKt',str(attempt)];(attempt/'reader-command.json').write_text(json.dumps(readercmd,indent=2)+'\n')
 with (attempt/'reader.log').open('w') as log:reader=subprocess.run(readercmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 (attempt/'reader.exit').write_text(str(reader.returncode)+'\n');assert reader.returncode==0;sys.exit(0)
assert len(sys.argv)==3 and sys.argv[1]=='--root-frozen-go','Explicit root GREEN/frozen GO required'
go=json.loads(Path(sys.argv[2]).read_text());assert go.get('rootGreen',go.get('GO')) is True;snapshot=Path(go['snapshot']);assert (snapshot/'source-head.txt').read_text().strip()==go.get('sourceHead',go.get('source'))
for name,key in [('main.jar','mainSha256'),('spacegraph.js','spacegraphSha256'),('documents.js','documentsSha256')]:assert sha(snapshot/name)==go[key]
cp=(snapshot/'classpath.txt').read_text().strip().split(':');pins=json.loads((snapshot/'sha256.json').read_text());assert len(cp)==120 and len(pins['dependencies'])==119
for p in map(Path,cp):assert p.is_file() and p.suffix=='.jar' and sha(p)==(go['mainSha256'] if p==snapshot/'main.jar' else pins['dependencies'][str(p)])
attempt=root/'native-attempt1';shutil.copytree(root/'native-prepared',attempt);shutil.copytree(root/'inputs/legacy-corpus',attempt/'legacy-corpus');shutil.copy2(root/'input-allowlist.json',attempt/'input-allowlist.json');metadata=attempt/'artifact-metadata';metadata.mkdir()
for name in ['source-head.txt','sha256.json','classpath.txt']:shutil.copy2(snapshot/name,metadata/name)
(attempt/'GO.json').write_text(json.dumps(go,indent=2)+'\n');(root/'ACTIVE_GO.json').write_text(json.dumps(go,indent=2)+'\n');observer=attempt/'observer-inputs';observer.mkdir()
for name in ['Fixture.kt','Reopen.kt','driver.cjs','run-proof.py','compile.sh','protocol.txt','preparation.json','corpus-inputs.json']:shutil.copy2(root/name,observer/name)
classes=root/'observer-attempt1'
with (root/'compile-attempt1.log').open('w') as log:compiled=subprocess.run(['bash',str(root/'compile.sh'),str(snapshot),str(classes)],stdout=log,stderr=subprocess.STDOUT)
(root/'compile-attempt1.exit').write_text(str(compiled.returncode)+'\n');assert compiled.returncode==0
asset=root/'frozen-browser-assets.jar';entries={}
with zipfile.ZipFile(asset,'w',compression=zipfile.ZIP_STORED) as z:
 for app,file in [('spacegraph','spacegraph.js'),('documents','documents.js')]:
  data=(snapshot/file).read_bytes();name='web/kotlin/'+app+'/'+file;z.writestr(zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0)),data);entries[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(asset) as z:assert set(z.namelist())==set(entries) and not any(n.endswith('.class') for n in z.namelist())
(attempt/'classpath.json').write_text(json.dumps({'productionDependencyJars':120,'productionClasspath':[{'path':p,'sha256':sha(Path(p))} for p in cp],'assetJar':{'path':str(asset),'bytes':asset.stat().st_size,'sha256':sha(asset),'entries':entries},'observerClasses':str(classes),'totalJarCount':121,'totalClasspathEntries':122},indent=2)+'\n');(attempt/'controller-before-netns.json').write_text(json.dumps({'pid':os.getpid(),'networkNamespace':os.readlink('/proc/self/ns/net')},indent=2)+'\n')
cmd=['unshare','--user','--map-root-user','--net','python3',str(root/'run-proof.py'),'--inside',str(attempt),str(snapshot),str(classes),str(asset)];(attempt/'namespace-command.json').write_text(json.dumps(cmd,indent=2)+'\n');result=subprocess.run(cmd);(attempt/'namespace.exit').write_text(str(result.returncode)+'\n');assert result.returncode==0
