package proof.corpusquery

import borg.trikeshed.couch.*
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.*
import borg.trikeshed.lib.*
import borg.trikeshed.memory.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.forge.server.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

/** Bounded production readback/replay after real source amendment; no parser/query/Run/admission. */
fun main(args:Array<String>)=runBlocking {
 val out=File(args[0]).canonicalFile;val go=reifyStrict(File(out,"GO.json").readText()) as Map<*,*>;val snapshot=File(go["snapshot"] as String).canonicalFile;val runtime=File(out,"runtime");val writer=reifyStrict(File(out,"cleanup.json").readText()) as Map<*,*>;check((writer["pid"] as Number).toLong()!=ProcessHandle.current().pid());java.lang.System.setProperty(GuestModules.HOME_PROPERTY,File(out,"empty-subvm").path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 fun stamp(f:File):Map<String,Any?> {val b=f.readBytes();return _m["bytes" j b.size,"sha256" j ContentId.of(b).hex]}
 val pack=File(runtime,"cas/pack");val walFile=File(runtime,"host/.kanban/board.wal");val before=_m["pack" j stamp(pack),"wal" j stamp(walFile)]
 val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").path);val owner=SupervisorJob(coroutineContext[Job]);val boardWal=BoardFileWal(files,File(runtime,"host/.kanban").path);val frames=mutableListOf<Map<String,Any?>>()
 boardWal.replay{seq,bytes->frames.add(_m["sequence" j seq,"payloadUtf8" j bytes.decodeToString(throwOnInvalidSequence=true),"sha256" j ContentId.of(bytes).hex])};val board=BoardStoreElement(wal=boardWal,cas=cas,parentJob=owner);board.open()
 val browser=reifyStrict(File(out,"browser-result.json").readText()) as Map<*,*>;val runs=browser["presetRuns"] as List<*>;val cards=runs.map{raw->val run=raw as Map<*,*>;val reply=(run["http"] as Map<*,*>)["response"] as Map<*,*>;val job=reply["jobId"] as String;val card=checkNotNull(board.card(job));check(checkNotNull(card.commandCid).value==reply["receiptCid"]);val command=checkNotNull(board.command(job));val saved=command["lcncRun"] as Map<*,*>;check(saved["runId"]==reply["runId"]&&saved["programCid"]==reply["programCid"]);_m["jobId" j job,"commandCid" j checkNotNull(card.commandCid).value,"column" j card.col.toString(),"sequence" j card.lastSequence,"command" j command]}
 val dir=File(out,"after-close-readbacks").apply{mkdirs()};val index=reifyStrict(File(out,"readback-index.json").readText()) as List<*>;val reads=index.map{raw->val e=raw as Map<*,*>;val cid=ContentId(e["cid"] as String);val bytes=checkNotNull(cas.getBounded(cid,4*1024*1024));check(ContentId.of(bytes)==cid&&bytes.contentEquals(File(out,e["file"] as String).readBytes()));val file=File(dir,cid.hex+".bin");file.writeBytes(bytes);_m["cid" j cid.value,"bytes" j bytes.size,"sha256" j ContentId.of(bytes).hex,"role" j e["role"],"file" j file.relativeTo(out).path]}
 val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas);val registry=ProjectDbRegistry("primary");val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,projectDbs=registry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"));check(scopes.remountLedger()==1);val corpus=JvmProjectCorpus(registry,scopes)
 val c=((reifyStrict(File(out,"cases.json").readText()) as Map<*,*>)["S12"] as Map<*,*>);val old=c["row"] as Map<*,*>;val row=checkNotNull(corpus.document(old["project"] as String,old["id"] as String));val writerFinal=(reifyStrict(File(out,"writer-final-state.json").readText()) as Map<*,*>);val expected=(writerFinal["rows"] as Map<*,*>)["S12"] as Map<*,*>;check(row.cid==expected["cid"]&&row.rev==expected["rev"]&&row.seq==(expected["seq"] as Number).toLong());check(row.cid!=old["cid"])
 val mirror=File(runtime,"files/${row.project}/${row.id}");val mirrorBytes=mirror.readBytes();check(ContentId.of(mirrorBytes).value==row.cid);File(dir,"actual-amended-S12-source.txt").writeBytes(mirrorBytes)
 val inputs=reifyStrict(File(out,"corpus-inputs.json").readText()) as Map<*,*>;val oldSources=(inputs["ranges"] as List<*>).map{raw->val e=raw as Map<*,*>;val snap=EnglishObservationGraph.read(cas,ContentId(e["receiptCid"] as String));check(snap.source.text==c["text"]);_m["inspectionCid" j e["receiptCid"],"sourceCid" j snap.source.originalCid.value,"sourceTextSha256" j ContentId.of(snap.source.text.encodeToByteArray()).hex,"range" j snap.inventory["range"]]}
 val sourceFiles=_m["ledger" j stamp(File(runtime,"projects.tsv")),"head" j stamp(File(runtime,"project-couch/${row.project}/HEAD")),"manifest" j stamp(File(runtime,"project-manifests/${row.project}.tsv")),"mirror" j stamp(mirror)]
 board.drain();board.close();scopes.drain();owner.complete();owner.join();cas.close();GuestModules.closeAll();val after=_m["pack" j stamp(pack),"wal" j stamp(walFile)];check(before==after)
 val origins=_m["PackCasStore" j PackCasStore::class.java,"EnglishObservationGraph" j EnglishObservationGraph::class.java,"BoardFileWal" j BoardFileWal::class.java,"BoardStoreElement" j BoardStoreElement::class.java,"JvmProjectCorpus" j JvmProjectCorpus::class.java].mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also{check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))}}
 File(out,"reopened.json").writeText(jsonOf(_m["result" j "PASS","readerPid" j ProcessHandle.current().pid(),"writerPid" j writer["pid"],"beforeOpen" j before,"afterClose" j after,"frames" j frames,"cards" j cards,"readbacks" j reads,"currentAmendedRow" j row.toMap(),"sourceFiles" j sourceFiles,"oldRetainedSources" j oldSources,"boardOwnerCompleted" j board.supervisor.isCompleted,"ownerCompleted" j owner.isCompleted,"remainingChildren" j owner.children.count(),"casClosed" j true,"guestModulesClosed" j GuestModules.closed.isCompleted,"origins" j origins,"scope" j "Actual derived corpus/search/run byte readback + old retained source after current source amendment, not new parsing/evaluation; anyREF paths remain actual externaldependencies."]))
}
