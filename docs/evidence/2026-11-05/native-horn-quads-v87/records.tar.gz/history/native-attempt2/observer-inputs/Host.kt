package proof.hornquads

import borg.trikeshed.agent.modelmux.Airgap
import borg.trikeshed.couch.*
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.graal.ConfixBlackboard
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.module.KanbanModule
import borg.trikeshed.kanban.*
import borg.trikeshed.rdf.*
import borg.trikeshed.nlp.*
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.litebike.*
import borg.trikeshed.memory.*
import borg.trikeshed.modelmux.*
import borg.trikeshed.module.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

class ObserverMarker

/** External composition observer only. All execution, source, report and listener owners are production. */
fun main(args: Array<String>) = runBlocking(Airgap()) {
    val out=File(args[0]).canonicalFile;val snapshot=File(args[1]).canonicalFile;val port=args[2].toInt()
    require(port in 1024..65535)
    require(File(out,"GO.json").isFile) { "Root frozen artifact GO required" }
    val go=reifyStrict(File(out,"GO.json").readText()) as Map<*, *>
    require(ContentId.of(File(snapshot,"main.jar").readBytes()).hex==go["mainSha256"])
    val runtime=File(out,"runtime");require(runtime.isDirectory)
    val cases=reifyStrict(File(out,"cases.json").readText()) as Map<*, *>
    val corpusInputs=reifyStrict(File(out,"corpus-inputs.json").readText()) as Map<*,*>
    val empty=File(out,"empty-subvm");check(empty.isDirectory && empty.listFiles().orEmpty().isEmpty())
    java.lang.System.setProperty(GuestModules.HOME_PROPERTY,empty.absolutePath)
    check(GuestModules.installed().isEmpty() && GuestModules.mounted().isEmpty())
    val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").absolutePath)
    val pack=File(runtime,"cas/pack");val inputPrefix=File(out,"input-cas-prefix.bin").readBytes()
    check(pack.readBytes().contentEquals(inputPrefix))
    fun stamp(file:File):Map<String,Any?> { val bytes=file.readBytes();return _m["bytes" j bytes.size,"sha256" j ContentId.of(bytes).hex] }
    // Exact copied source mirrors only; no receipt/regression fixture synthesis or original revision upload.
    val promoted=mutableListOf<Map<String,Any?>>()
    for(file in File(runtime,"files").walkTopDown().filter { it.isFile }) {
        check(!java.nio.file.Files.isSymbolicLink(file.toPath()))
        val bytes=file.readBytes();check(bytes.size<=4*1024*1024);val cid=ContentId.of(bytes)
        check(cas.holds(cid));check(cas.put(bytes)==cid);cas.sync()
        check(cas.getBounded(cid,bytes.size)?.contentEquals(bytes)==true)
        promoted.add(_m["relativeMirror" j file.relativeTo(runtime).path,"cid" j cid.value,"bytes" j bytes.size])
    }
    val materialized=File(out,"materialized-inputs").listFiles().orEmpty().map{artifact->val bytes=artifact.readBytes();val cid=ContentId.of(bytes);check(artifact.name==cid.hex+".bin");check(cas.put(bytes)==cid);cas.sync();check(cas.getBounded(cid,4*1024*1024)?.contentEquals(bytes)==true);_m["cid" j cid.value,"bytes" j bytes.size,"policy" j "retainedgenuinev80byte-for-byte materialization; notfreshparser or metadata rewrite"]}
    val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas)
    val registry=ProjectDbRegistry("primary")
    val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,
        projectDbs=registry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"))
    check(scopes.remountLedger()==1)
    val realCorpus=JvmProjectCorpus(registry,scopes)
    val currentnessReads=java.util.concurrent.atomic.AtomicInteger()
    val nativeCurrentnessReads=java.util.concurrent.atomic.AtomicInteger()
    val corpus=object:ProjectCorpus by realCorpus {
        override suspend fun document(project:String,id:String):ProjectDoc? {
            if(Throwable().stackTrace.any{it.className.contains("EnglishObservationCurrent")})currentnessReads.incrementAndGet()
            if(id=="native-proof-v87.kif"&&Throwable().stackTrace.any{it.className.contains("DocumentCurationLegos")})nativeCurrentnessReads.incrementAndGet()
            return realCorpus.document(project,id)
        }
    }
    val owner=SupervisorJob(coroutineContext[Job]);val scope=CoroutineScope(coroutineContext+Dispatchers.IO+owner+files)
    val ctx=ModuleContext(Couch("corpus-query-native",store,cas),ReteNetwork(),ReteProductionRegistry(),null,null,
        ConfixBlackboard.empty(),cas,gateway,ModuleRouteRegistry(),scope,{java.lang.System.currentTimeMillis()},File(runtime,"host").apply{mkdirs()})
    ctx.lcncRunners.putAll(PureNodes.registry(ctx.clock))
    ctx.lcncRunners.putAll(TribunalNodes.registry(TribunalDialog { _,_,_->error("No provider configured") }).filterKeys{it=="display"})
    val brain=BrainClient(endpointSpecs=emptyList());check(!brain.hasEndpoints() && brain.modelMux().listModels().isEmpty())
    val patch=PatchWire(brain,scopes,attachments=gateway,corpus=corpus)
    val uploads=ProjectDbWire(registry,scopes)
    val fixture=reifyStrict(File(out.parentFile,"fixture-config.json").readText()) as Map<*,*>
    val nativeText=File(out.parentFile,"manual-native-proof.kif").readText();val nativeBytes=nativeText.encodeToByteArray();check(ContentId.of(nativeBytes).value==fixture["sourceCid"])
    val nativePath="/_project/"+fixture["project"]+"/put?path="+java.net.URLEncoder.encode(fixture["id"] as String,"UTF-8")
    val bootstrapUpload=checkNotNull(uploads.route("POST",nativePath,nativeBytes,null));check(bootstrapUpload.status==200)
    val nativeRow=checkNotNull(corpus.document(fixture["project"] as String,fixture["id"] as String));val nativeSource=DocumentCurationLegos.projectSource(cas,corpus,nativeRow)
    val nativeRecord=DocumentCurationRecord(nativeSource,null,null,"manual-kif-host-fixture-no-model",emptySeriesOf(),emptySeriesOf());val codecClass=Class.forName("borg.trikeshed.narsese.DocumentCuratorCodec");val encodeCarrier=codecClass.getDeclaredMethod("encode",DocumentCurationRecord::class.java).also{it.isAccessible=true};val codec=codecClass.getDeclaredField("INSTANCE").get(null);val carrierBytes=encodeCarrier.invoke(codec,nativeRecord) as ByteArray
    val nativeCarrier=cas.put(carrierBytes);cas.sync();val carrierConstruction=_m["method" j encodeCarrier.toGenericString(),"origin" j codecClass.protectionDomain.codeSource.location.toString(),"scope" j "Bounded INTERNAL codec serialization of synthetic source-only hostfixture; no model/feed/checker/review override. Actual approval is authenticatedHTTP."];check(File(java.net.URI(carrierConstruction["origin"] as String)).canonicalFile==File(snapshot,"main.jar"))
    val documents=File(ctx.stateDir,"documents").apply{mkdirs()};val token=fixture["publicSyntheticToken"] as String
    File(documents,"review-principals.json").writeText(jsonOf(_m["principals" j _l[_m["tokenSha256" j ContentId.of(token.encodeToByteArray()).hex,"id" j fixture["reviewerId"],"synthetic" j true]]]))
    val books=ConstellationNodes(ctx.stateDir,ctx.blackboard,scope=scope,cas=cas)
    val nativeProfile=NativeHornProfile.parse(File(out.parentFile,"native-profile.json").readText())
    val reviewWire=DocumentReviewWire.open(ctx,corpus,books,nativeHorn=NativeHornQuery(nativeProfile))
    val module=KanbanModule().open(ctx)
    val couchWire=CouchWire(CouchWireRouter(ctx.couch,attachmentPrefix=""),null,scope)
    val finish=CompletableDeferred<Unit>()
    val names=_m["PackCasStore" j PackCasStore::class.java,"EnglishObservationGraph" j EnglishObservationGraph::class.java,
        "EnglishObservationWire" j EnglishObservationWire::class.java,"DocumentReviewWire" j DocumentReviewWire::class.java,"CurationReview" j CurationReview::class.java,"NativeHornQuery" j NativeHornQuery::class.java,"NativeHornProfile" j NativeHornProfile::class.java,"NativeHornProofGraph" j NativeHornProofGraph::class.java,"NativeHornQueryView" j NativeHornQueryView::class.java,"SumoNixBridge" j borg.trikeshed.kif.SumoNixBridge::class.java,"EnglishCorpusWire" j EnglishCorpusWire::class.java,"EnglishCorpus" j EnglishCorpus::class.java,"EnglishCorpusPreset" j EnglishCorpusPreset::class.java,"EnglishLdaConfig" j EnglishLdaConfig::class.java,"DocumentEnglishWire" j DocumentEnglishWire::class.java,
        "JvmKanbanServer" j JvmKanbanServer::class.java,"KanbanModule" j KanbanModule::class.java,
        "CouchWire" j CouchWire::class.java,"CouchWireRouter" j CouchWireRouter::class.java,
        "BoardFileWal" j BoardFileWal::class.java,"JvmBoardWal" j JvmBoardWal::class.java,"BoardStoreElement" j BoardStoreElement::class.java,"JvmFileOperations" j JvmFileOperations::class.java,
        "EnglishLegalQueryWire" j EnglishLegalQueryWire::class.java,"SparqlWire" j SparqlWire::class.java,"SparqlSurface" j SparqlSurface::class.java,"QuadStore" j QuadStore::class.java,"EnglishGuardQueryView" j EnglishGuardQueryView::class.java,
        "EnglishNalPreset" j EnglishNalPreset::class.java,"LcncOutputReceipt" j LcncOutputReceipt::class.java,
        "SyntheticNalExperiment" j SyntheticNalExperiment::class.java,"Nal" j Nal::class.java,"DerivationReceipt" j DerivationReceipt::class.java]
    val origins=names.mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also {
        check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))
    }}.toMutableMap()
    origins["LcncRunService"]=Class.forName("borg.trikeshed.kanban.module.LcncRunService",false,KanbanModule::class.java.classLoader).protectionDomain.codeSource.location.toString()
    val journal=File(ctx.stateDir,".kanban").canonicalFile
    fun journalFile(file:File):Map<String,Any?> {
        val attr=java.nio.file.Files.readAttributes(file.toPath(),java.nio.file.attribute.BasicFileAttributes::class.java)
        val metadata=_m["path" j file.canonicalPath,"fileKey" j attr.fileKey().toString(),"mtimeMillis" j attr.lastModifiedTime().toMillis(),"bytes" j attr.size()]
        // Never open/close another sidecar descriptor in the JVM holding its POSIX lock.
        return metadata+if(file.name=="board.wal.lock")_m["hashScope" j "Measured only by separate non-owning controller/contender processes"]else stamp(file)
    }
    fun journalState()=_m["directory" j journal.path,"wal" j journalFile(File(journal,"board.wal")),"lease" j journalFile(File(journal,"board.wal.lock"))]
    fun sourceFiles():Map<String,Any?> {
        val projects=cases.values.map{((it as Map<*,*>)["row"] as Map<*,*>)["project"] as String}.distinct()
        return _m["ledger" j stamp(File(runtime,"projects.tsv")),"projects" j projects.associateWith{project->_m[
            "head" j stamp(File(runtime,"project-couch/$project/HEAD")),"manifest" j stamp(File(runtime,"project-manifests/$project.tsv"))]}]
    }
    suspend fun state():Map<String,Any?> {
        val rows=cases.mapValues{(_,v)->val row=(v as Map<*,*>)["row"] as Map<*,*>;corpus.document(row["project"] as String,row["id"] as String)?.toMap()}
        val facts=ctx.rete.snapshot().view.map{f->_m["partition" j f.factId.a,"id" j f.factId.b,"fields" j f.fields,"versionCid" j f.versionCid.value]}
        return _m["pid" j ProcessHandle.current().pid(),"rows" j rows,"pack" j stamp(pack),
            "nativeRow" j corpus.document(fixture["project"] as String,fixture["id"] as String)?.toMap(),"nativeMirror" j stamp(File(runtime,"files/"+fixture["project"]+"/"+fixture["id"])),"reviewWal" j stamp(File(documents,"review.wal")),"sourceFiles" j sourceFiles(),"journal" j journalState(),"blackboard" j ctx.blackboard.snapshot().values,"reteFacts" j facts,"beliefBagPresent" j (ctx.beliefBag!=null),
            "kifBankPresent" j (ctx.kifBank!=null),"narsRetePresent" j (ctx.narsRete!=null),
            "guestInstalled" j GuestModules.installed(),"guestMounted" j GuestModules.mounted(),
            "configuredModelCount" j brain.modelMux().listModels().size,"modelEndpointsPresent" j brain.hasEndpoints(),
            "intakeHooks" j _m["document" j (scopes.onDocument!=null),"explicitDocument" j (scopes.onExplicitDocument!=null),"textForReview" j (scopes.onTextForReview!=null)],"nativeCurrentnessReads" j nativeCurrentnessReads.get(),"englishCurrentnessReads" j currentnessReads.get(),"networkNamespace" j java.nio.file.Files.readSymbolicLink(java.nio.file.Path.of("/proc/self/ns/net")).toString()]
    }
    for((_,v) in cases) {
        val c=v as Map<*,*>;val row=c["row"] as Map<*,*>;val real=checkNotNull(corpus.document(row["project"] as String,row["id"] as String))
        check(real.cid==row["cid"] && real.rev==row["rev"] && real.seq==(row["seq"] as Number).toLong())
        val snap=EnglishObservationGraph.read(cas,ContentId(c["inspectionCid"] as String));check(snap.source.text==c["text"])
    }
    val baseline=state()
    File(out,"startup.json").writeText(jsonOf(_m["go" j go,"origins" j origins,"observerCodeSource" j ObserverMarker::class.java.protectionDomain.codeSource.location.toString(),
        "cases" j cases,"sourceRetentionChecks" j promoted,"retainedInspectionMaterializations" j materialized,"packAfterSourceRetention" j stamp(pack),"inputPrefix" j _m["bytes" j inputPrefix.size,"sha256" j ContentId.of(inputPrefix).hex],"baseline" j baseline]))
    val control:ExtraRoute={method,path,_,_->when {
        method=="GET" && path=="/__v87/meta"->JvmKanbanServer.HttpResponse(200,jsonOf(_m["go" j go,"cases" j cases,"fixture" j fixture,"nativeCarrierCid" j nativeCarrier.value,"carrierConstruction" j carrierConstruction,"nativeRow" j nativeRow.toMap(),"bootstrapUpload" j _m["status" j bootstrapUpload.status,"body" j bootstrapUpload.body,"scope" j "hostfixture callsactualProjectDbWire beforelistener; not publicapproval"],"corpusInputs" j corpusInputs,"baseline" j baseline,"origins" j origins]))
        method=="GET" && path=="/__v87/state"->JvmKanbanServer.HttpResponse(200,jsonOf(state()))
        method=="POST" && path=="/__v87/finish"->{File(out,"writer-final-state.json").writeText(jsonOf(state()));finish.complete(Unit);JvmKanbanServer.HttpResponse(200,"{}")}
        method=="GET" && (path.startsWith("/api/panels") || path.startsWith("/api/projects"))->patch.route(method,path,"GET $path HTTP/1.1\r\n\r\n",null)
        else->null
    }}
    val selected=fixture
    val upload:RawRoute={method,path,payload,respond->
        val allowed="/_project/"+selected["project"]+"/put?path="+java.net.URLEncoder.encode(selected["id"] as String,"UTF-8")
        if(method=="POST" && path==allowed) uploads.route(method,path,payload,respond) else null
    }
    val rawBlocks:RawRoute={method,path,payload,respond->
        if(method=="GET" && path.substringBefore('?')=="/api/v0/block/get")couchWire.route(method,path,payload,respond) else null
    }
    val server=JvmKanbanServer(extraRoutes=_l[control],rawRoutes=_l[rawBlocks,upload],stateDir=ctx.stateDir,moduleRoutes=ctx.routes)
    val listener=launch(Dispatchers.IO){server.run(port,null)}
    try { finish.await() }
    finally { withContext(NonCancellable) {
        listener.cancelAndJoin();ctx.routes.release("kanban");module.drain();module.close();reviewWire.drain();reviewWire.close();books.drain();scopes.drain()
        owner.complete();owner.join();cas.sync();cas.close();GuestModules.closeAll()
        File(out,"cleanup.json").writeText(jsonOf(_m["pid" j ProcessHandle.current().pid(),"listenerJoined" j listener.isCompleted,
            "moduleDrained" j true,"reviewWireDrained" j true,"booksDrained" j true,"scopesDrained" j true,"ownerCompleted" j owner.isCompleted,
            "remainingChildren" j owner.children.count(),"casClosed" j true,"guestModulesClosed" j GuestModules.closed.isCompleted,"closedJournal" j journalState(),"closedPack" j stamp(pack),"closedSourceFiles" j sourceFiles()]))
    }}
}
