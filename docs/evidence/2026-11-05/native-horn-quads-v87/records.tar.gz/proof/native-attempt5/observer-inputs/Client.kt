package proof.hornquads

import borg.trikeshed.job.*
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.parse.*
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.Proxy
import java.net.URL

/** Real authenticated HTTP client; helper programs/projectors are final-JAR public pure clients. */
fun main(args:Array<String>)=runBlocking {
 java.lang.System.setProperty("sun.net.http.retryPost","false");val out=File(args[0]).canonicalFile;val base=args[1];val requests=mutableListOf<Map<String,Any?>>()
 fun call(label:String,path:String,body:Any?=null,token:String?=null,method:String=if(body==null)"GET"else"POST"):Map<String,Any?> {
  val u=URL(base);val bytes=body?.let{if(it is String)it.encodeToByteArray()else jsonOf(it).encodeToByteArray()}
  val header=buildString{append("$method $path HTTP/1.1\r\nHost: ${u.host}:${u.port}\r\nConnection: close\r\n");if(token!=null)append("Authorization: Bearer $token\r\n");if(bytes!=null)append("Content-Type: "+(if(body is String)"text/plain; charset=utf-8"else"application/json")+"\r\nContent-Length: ${bytes.size}\r\n");append("\r\n")}
  val request=header.encodeToByteArray()+(bytes?:ByteArray(0));File(out,"$label-http-request.bin").writeBytes(request);if(bytes!=null)File(out,"$label-request.bin").writeBytes(bytes)
  val socket=java.net.Socket();socket.connect(java.net.InetSocketAddress(u.host,u.port),10000);socket.soTimeout=120000
  val pair=socket.use{it.outputStream.write(request);it.outputStream.flush();val input=it.inputStream.buffered();val head=java.io.ByteArrayOutputStream();var tail=0
   while(tail!=0x0d0a0d0a){val next=input.read();check(next>=0&&head.size()<65536){"Truncated/oversized response header $label"};head.write(next);tail=(tail shl 8) or next}
   val headerText=head.toString("UTF-8");val lines=headerText.split("\r\n");val code=lines[0].split(" ")[1].toInt();val fields=lines.drop(1).filter{it.contains(':')}.associate{it.substringBefore(':').lowercase() to it.substringAfter(':').trim()}
   check(fields["transfer-encoding"]==null){"Unexpected chunked HTTP observer response"};val n=fields["content-length"]?.toInt()?:error("Response length required $label");check(n in 0..4194304);val data=input.readNBytes(n);check(data.size==n);File(out,"$label-http-response.bin").writeBytes(head.toByteArray()+data);code to data
  };val status=pair.first;val raw=pair.second;File(out,"$label-response.bin").writeBytes(raw)
  val response=runCatching{reifyStrict(raw.decodeToString())}.getOrNull();val record=_m["label" j label,"path" j path,"method" j method,"authenticated" j (token!=null),"status" j status,"request" j body,"response" j response,"responseSha256" j ContentId.of(raw).hex,"responseBytes" j raw.size];requests.add(record);File(out,"client-progress.json").writeText(jsonOf(requests));return record
 }
 fun response(record:Map<String,Any?>,expected:Int=200):Map<*,*> {check(record["status"]==expected){jsonOf(record)};return record["response"] as Map<*,*>}
 fun state(label:String)=response(call("$label-state","/__v87/state"))
 val meta=response(call("meta","/__v87/meta"));val fixture=meta["fixture"] as Map<*,*>;val token=fixture["publicSyntheticToken"] as String;val carrier=meta["nativeCarrierCid"] as String
 val candidates=response(call("taxonomy-candidates","/api/documents/review/taxonomy-candidates",_m["receiptCid" j carrier,"offset" j 0,"limit" j 64],token));val selections=candidates["selections"] as List<*>;check(selections.size==3);val ids=selections.map{(it as Map<*,*>)["id"] as String}
 val snapshot=response(call("snapshot","/api/documents/review/snapshot",_m["kind" j "taxonomy","receiptCid" j carrier,"selection" j ids],token));val approved=response(call("approve","/api/documents/review/decision",_m["snapshotCid" j snapshot["snapshotCid"],"expectedRevision" j snapshot["revision"],"action" j "approve"],token))
 val body=_m["snapshotCid" j snapshot["snapshotCid"],"expectedRevision" j approved["revision"],"goal" j fixture["goal"]];val beforeQueries=state("approved-before-queries")
 val unauthorized=call("unauthorized-native-query","/api/documents/review/taxonomy-query",body);response(unauthorized,401)
 val plain=response(call("plain-native-query","/api/documents/review/taxonomy-query",body,token));check(plain["kind"]=="reviewed-kif-native-result/1"&&plain["status"]=="SUPPORTED"&&!plain.containsKey("quadQuery"));check((plain["sourceEvidence"] as Map<*,*>).size==3)
 val again=response(call("repeat-no-program","/api/documents/review/taxonomy-query",body,token));check(!again.containsKey("quadQuery"));val projection=NativeHornProofGraph.project(plain);val roundTrip=reifyStrict(jsonOf(plain)) as Map<*,*>;check(NativeHornProofGraph.project(roundTrip).projectionCid==projection.projectionCid&&NativeHornProofGraph.project(again).projectionCid==projection.projectionCid)
 val bindingStarter=NativeHornQueryView.starter(plain,bindings=true);val premiseStarter=NativeHornQueryView.starter(plain,bindings=false)
 fun program(starter:NativeHornQueryView.Starter):Map<*,*> = reifyStrict(LcncProgramConfix.toJson(starter.program)) as Map<*,*>
 File(out,"bindings-program.json").writeText(LcncProgramConfix.toJson(bindingStarter.program));File(out,"premises-program.json").writeText(LcncProgramConfix.toJson(premiseStarter.program))
 val bindingResponse=response(call("bindings-query","/api/documents/review/taxonomy-query",body+_m["program" j program(bindingStarter)],token));val bindingAnswer=NativeHornQueryView.answer(plain,bindingResponse,bindingStarter);check(bindingAnswer.rows.size==3);check(bindingAnswer.rows.map{(it["variable"] as Map<*,*>)["value"]}==_l["?x","?y","?z"]);check(bindingAnswer.rows.map{(it["value"] as Map<*,*>)["value"]}==_l["Tenant","Person","Agent"])
 val premiseResponse=response(call("premises-query","/api/documents/review/taxonomy-query",body+_m["program" j program(premiseStarter)],token));val premiseAnswer=NativeHornQueryView.answer(plain,premiseResponse,premiseStarter);check(premiseAnswer.rows.size==2);check(premiseAnswer.rows.map{(it["ordinal"] as Map<*,*>)["value"]}==_l["0","1"])
 val nullProgram=call("null-program","/api/documents/review/taxonomy-query",body+_m["program" j null],token);response(nullProgram,400);check(!(nullProgram["response"] as Map<*,*>).containsKey("quadQuery"))
 val wrong=bindingStarter.program.copy(nodes=bindingStarter.program.nodes α{n->if(n.type==SparqlGraph.PATTERN)n.copy(params=n.params+_m["graph" j "<urn:wrong:old-frame>"])else n});val badGraph=call("wrong-graph","/api/documents/review/taxonomy-query",body+_m["program" j (reifyStrict(LcncProgramConfix.toJson(wrong)) as Map<*,*>)],token);val badResponse=response(badGraph,409);check(badResponse["code"]=="native_horn_projection_changed"&&!badResponse.containsKey("quadQuery"))
 val afterQueries=state("after-query-controls");for(key in _l["pack","reviewWal","sourceFiles","nativeRow","nativeMirror"])check(beforeQueries[key]==afterQueries[key]){"Query changed $key"}
 val missingProjection=call("computed-projection-not-cas","/api/v0/block/get?arg="+java.net.URLEncoder.encode(projection.projectionCid.value,"UTF-8"));check(missingProjection["status"]==404)
 val source=File(out.parentFile,"manual-native-proof.kif").readText();val amendment=source+(fixture["sourceAmendmentSuffix"] as String);File(out,"actual-kif-amendment.txt").writeText(amendment);val uploadPath="/_project/"+fixture["project"]+"/put?path="+java.net.URLEncoder.encode(fixture["id"] as String,"UTF-8");val amended=response(call("source-amendment",uploadPath,amendment));val afterAmend=state("after-source-amendment");check((afterAmend["nativeRow"] as Map<*,*>)["cid"]==ContentId.of(amendment.encodeToByteArray()).value);check(afterAmend["reviewWal"]==afterQueries["reviewWal"])
 val stale=call("stale-source-query","/api/documents/review/taxonomy-query",body+_m["program" j program(premiseStarter)],token);val staleResponse=response(stale,409);check(!staleResponse.containsKey("quadQuery"));val finalState=state("after-stale-query");check(finalState["reviewWal"]==afterAmend["reviewWal"]&&finalState["pack"]==afterAmend["pack"])
 val readbacks=mutableListOf<Map<String,Any?>>()
 for((id,role) in _l[carrier j "manual-kif-curation-carrier",(meta["nativeRow"] as Map<*,*>)["cid"] as String j "original-manual-kif-source",(afterAmend["nativeRow"] as Map<*,*>)["cid"] as String j "actual-amended-kif-source",snapshot["snapshotCid"] as String j "review-snapshot",approved["decisionCid"] as String j "review-decision",snapshot["decisionCid"] as String j "review-snapshot-event"]) {
  val record=call("cas-${readbacks.size}","/api/v0/block/get?arg="+java.net.URLEncoder.encode(id,"UTF-8"));check(record["status"]==200){jsonOf(record)};if(record["status"]==200){val raw=File(out,"cas-${readbacks.size}-response.bin").readBytes();check(ContentId.of(raw).value==id);val dir=File(out,"cas-readbacks").apply{mkdirs()};val file=File(dir,ContentId(id).hex+".bin");file.writeBytes(raw);readbacks.add(_m["cid" j id,"role" j role,"bytes" j raw.size,"sha256" j ContentId.of(raw).hex,"file" j file.relativeTo(out).path])}
 }
 File(out,"client-readback-index.json").writeText(jsonOf(readbacks));File(out,"client-result.json").writeText(jsonOf(_m["result" j "PASS","transport" j "One-request bounded standardHTTP1.1 Socket; Connection:close/Content-Length, no retries; rawHTTPrequest/response retained","pid" j ProcessHandle.current().pid(),"meta" j meta,"requests" j requests,"snapshot" j snapshot,"approved" j approved,"beforeQueries" j beforeQueries,"afterQueries" j afterQueries,"plain" j plain,"repeatPlain" j again,"projection" j _m["cid" j projection.projectionCid.value,"graph" j projection.graph,"descriptor" j projection.descriptor,"quads" j projection.store.size,"presentInCasHttpStatus" j missingProjection["status"]],"bindings" j _m["program" j program(bindingStarter),"query" j bindingStarter.query,"response" j bindingResponse,"answerRows" j bindingAnswer.rows],"premises" j _m["program" j program(premiseStarter),"query" j premiseStarter.query,"response" j premiseResponse,"answerRows" j premiseAnswer.rows],"sourceAmendment" j _m["upload" j amended,"after" j afterAmend,"requestText" j amendment],"stale" j stale,"final" j finalState,"readbacks" j readbacks,"scope" j "Actual authenticatedreviewednativeproof+requestlocaltypedqueries, publichelperprograms only; no newHornDocs/LCNCrunner/nativeTheory endpoint, no JSONapproval."]))
}
