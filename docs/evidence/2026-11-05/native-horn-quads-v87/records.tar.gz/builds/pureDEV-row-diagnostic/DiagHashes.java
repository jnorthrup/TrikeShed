import java.util.*;
import borg.trikeshed.lcnc.*; import borg.trikeshed.rdf.*; import borg.trikeshed.cursor.query.*; import borg.trikeshed.parse.ReifyKt;
public class DiagHashes {
 static Object copied(Object v) { if(v instanceof Map<?,?> m) { Map<Object,Object> x=new LinkedHashMap<>(); for(var e:m.entrySet())x.put(e.getKey(),copied(e.getValue()));return x; } if(v instanceof List<?> l)return l.stream().map(DiagHashes::copied).toList();return v; }
 public static void main(String[] args) {
  var report=NativeHornQueryViewTestKt.nativeHornGraphFixture("Tenant",false); var p=NativeHornProofGraph.INSTANCE.project(report);
  var starter=NativeHornQueryView.INSTANCE.starter(report,List.of(),true); var r=new SparqlSurface(p.getStore(),ClosureExprCompiler.INSTANCE).handle("POST","/sparql?source=quad-store",Map.of("content-type","application/sparql-query"),starter.getQuery(),null);
  Map<?,?> parsed=(Map<?,?>)ReifyKt.reifyStrict(r.getBody()); List<?> rows=(List<?>)((Map<?,?>)parsed.get("results")).get("bindings");
  Map<?,?> row=(Map<?,?>)rows.get(0); Map<?,?> copy=(Map<?,?>)copied(row);
  System.out.println("rowClass="+row.getClass().getName()+" termClass="+row.get("variable").getClass().getName());
  System.out.println("rowEqualsCopy="+row.equals(copy)+" copyEqualsRow="+copy.equals(row));
  System.out.println("rowHashes="+row.hashCode()+","+row.hashCode()+","+row.hashCode()+" copyHashes="+copy.hashCode()+","+copy.hashCode());
  System.out.println("setFromRowContainsCopy="+new HashSet<>(List.of(row)).contains(copy)+" setFromCopyContainsRow="+new HashSet<>(List.of(copy)).contains(row));
  System.out.println("copySetFindsCopy="+new HashSet<>(List.of(copy)).contains(copied(row)));
 }
}