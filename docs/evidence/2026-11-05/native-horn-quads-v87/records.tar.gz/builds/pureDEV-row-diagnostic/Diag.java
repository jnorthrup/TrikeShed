import java.util.*;
import borg.trikeshed.lcnc.*;
import borg.trikeshed.rdf.*;
import borg.trikeshed.cursor.query.*;
public class Diag {
 public static void main(String[] args) {
  Map<String,Object> report=NativeHornQueryViewTestKt.nativeHornGraphFixture("Tenant",false);
  NativeHornProofGraph.Projection p=NativeHornProofGraph.INSTANCE.project(report);
  for(boolean bindings:new boolean[]{true,false}) {
   NativeHornQueryView.Starter s=NativeHornQueryView.INSTANCE.starter(report,List.of(),bindings);
   SparqlSurface surface=new SparqlSurface(p.getStore(),ClosureExprCompiler.INSTANCE);
   var r=surface.handle("POST","/sparql?source=quad-store",Map.of("content-type","application/sparql-query"),s.getQuery(),null);
   System.out.println("BINDINGS="+bindings+" STATUS="+r.getStatus());
   System.out.println(s.getQuery());
   System.out.println(r.getBody());
  }
 }
}
