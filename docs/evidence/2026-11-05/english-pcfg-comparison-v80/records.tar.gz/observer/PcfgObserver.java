import edu.stanford.nlp.pipeline.*;
import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.io.*;

/** External comparison only. Does not load application main.jar or produce inspection receipts. */
public final class PcfgObserver {
  static final String GRAMMAR="edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz";
  static final String GRAMMAR_SHA="034735fc9fcf3478b4ea3dd0bbc65106d595ece384375be37ffe48dbce4a0c33";
  static Map<String,Object> m(Object... kv) { Map<String,Object> r=new LinkedHashMap<>(); for(int i=0;i<kv.length;i+=2)r.put((String)kv[i],kv[i+1]); return r; }
  static String hash(byte[] b)throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b)); }
  static String dec(String s){return new String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8);}
  static void require(boolean b,String why){if(!b)throw new IllegalStateException(why);}
  static String json(Object o){
    if(o==null)return "null"; if(o instanceof Boolean || o instanceof Number)return o.toString();
    if(o instanceof Map<?,?> a){List<String> s=new ArrayList<>();for(var e:a.entrySet())s.add(json(e.getKey().toString())+":"+json(e.getValue()));return "{"+String.join(",",s)+"}";}
    if(o instanceof Iterable<?> a){List<String>s=new ArrayList<>();for(Object x:a)s.add(json(x));return "["+String.join(",",s)+"]";}
    StringBuilder s=new StringBuilder("\"");for(char c:o.toString().toCharArray()){switch(c){case '\\':s.append("\\\\");break;case '"':s.append("\\\"");break;case '\n':s.append("\\n");break;case '\r':s.append("\\r");break;case '\t':s.append("\\t");break;default:if(c<32)s.append(String.format("\\u%04x",(int)c));else s.append(c);}}return s.append('"').toString();
  }
  static void write(Path f,Object value)throws Exception{Files.writeString(f,json(value)+"\n",StandardCharsets.UTF_8);}
  static Map<String,Object> origin(Class<?> c)throws Exception{
    var loc=c.getProtectionDomain().getCodeSource().getLocation();Path p=Path.of(loc.toURI());
    return m("class",c.getName(),"codeSource",loc.toString(),"sha256",Files.isRegularFile(p)?hash(Files.readAllBytes(p)):null,"packageVersion",c.getPackage().getImplementationVersion());
  }
  static int constituents(Tree tree,int start,List<CoreLabel> ts,String source,List<Object> rows){
    if(tree.isLeaf())return start+1; int end=start;
    for(Tree c:tree.children())end=constituents(c,end,ts,source,rows);
    int begin=ts.get(start).beginPosition(),finish=ts.get(end-1).endPosition();
    rows.add(m("label",tree.value(),"firstTokenIndex",start+1,"endTokenIndexExclusive",end+1,"begin",begin,"end",finish,"quote",source.substring(begin,finish),"meaning","grammar-constituent-observation"));
    return end;
  }
  public static void main(String[] args)throws Exception{
    require(args.length==3,"args: INPUT_ROOT CASE OUTPUT_DIR");
    Path root=Path.of(args[0]),out=Path.of(args[2]);String id=args[1];
    require(id.equals("G07")||id.equals("G13"),"only pinned G07/G13");Files.createDirectories(out);
    Map<String,Object> report=m("schema","external-pcfg-source-comparison/1","recipe","english-pcfg-untagged-source-comparator/1","case",id,"status","STARTED","meaning","syntax-observation-not-legal-truth","applicationMainJarLoaded",false,"newInspectionReceipt",false);
    long total=System.nanoTime();Throwable failure=null;
    try{
      report.put("stage","inputs");Path in=root.resolve(id);byte[] bytes=Files.readAllBytes(in.resolve("source.txt"));String source=new String(bytes,StandardCharsets.UTF_8);
      require(Arrays.equals(bytes,source.getBytes(StandardCharsets.UTF_8)),"UTF8 roundtrip");
      Properties meta=new Properties();try(Reader r=Files.newBufferedReader(in.resolve("identity.properties"))){meta.load(r);}
      require(("sha256:"+hash(bytes)).equals(meta.getProperty("sourceCid")),"source digest mismatch");
      report.put("source",m("originalCid",meta.getProperty("sourceCid"),"extractedTextCid",meta.getProperty("sourceCid"),"baselineInspectionCid",meta.getProperty("receiptCid"),"sourceUtf8Bytes",bytes.length,"sourceUtf16Units",source.length(),"text",source,"baselineReceiptMeaning","existing-production-receipt-unmodified"));
      report.put("jvm",m("version",System.getProperty("java.version"),"vendor",System.getProperty("java.vendor"),"vm",System.getProperty("java.vm.name"),"maxMemory",Runtime.getRuntime().maxMemory(),"processors",Runtime.getRuntime().availableProcessors(),"airgap",System.getenv("TRIKESHED_AIRGAP")));
      report.put("classOrigins",List.of(origin(StanfordCoreNLP.class),origin(LexicalizedParser.class),origin(CoreLabel.class),origin(PcfgObserver.class)));
      var resource=PcfgObserver.class.getClassLoader().getResource(GRAMMAR);require(resource!=null,"grammar missing");byte[] grammar;try(InputStream s=resource.openStream()){grammar=s.readAllBytes();}
      require(hash(grammar).equals(GRAMMAR_SHA),"grammar resource hash mismatch");report.put("grammar",m("resource",GRAMMAR,"url",resource.toString(),"sha256",hash(grammar),"bytes",grammar.length));
      List<String[]> baseline=new ArrayList<>();for(String line:Files.readAllLines(in.resolve("tokens.tsv"))){if(!line.isEmpty())baseline.add(line.split("\t",-1));}
      Properties props=new Properties();props.setProperty("annotators","tokenize,ssplit");props.setProperty("tokenize.language","en");props.setProperty("threads","1");
      report.put("tokenizerConfiguration",new TreeMap<>(props));report.put("parserConfiguration",m("publicApi","LexicalizedParser.loadModel(resource, empty String[]).parseTree(untaggedCoreLabels)","extraFlags",List.of(),"inputPos","absent","observerRepairOrRetry",false));
      report.put("stage","tokenize");long tok=System.nanoTime();StanfordCoreNLP tokenizer=new StanfordCoreNLP(props);Annotation doc=new Annotation(source);tokenizer.annotate(doc);report.put("tokenizeMillis",(System.nanoTime()-tok)/1_000_000.0);
      List<CoreMap> sentences=doc.get(CoreAnnotations.SentencesAnnotation.class);require(sentences.size()==1,"sentence count differs from pinned one-sentence baseline");
      CoreMap sentence=sentences.get(0);List<CoreLabel> tokens=sentence.get(CoreAnnotations.TokensAnnotation.class);List<Object> tokenRows=new ArrayList<>();report.put("tokens",tokenRows);
      require(tokens.size()==baseline.size(),"token count alignment");require(sentence.get(CoreAnnotations.CharacterOffsetBeginAnnotation.class)==0 && sentence.get(CoreAnnotations.CharacterOffsetEndAnnotation.class)==source.length(),"sentence span alignment");
      List<CoreLabel> untagged=new ArrayList<>();
      for(int i=0;i<tokens.size();i++){
        CoreLabel t=tokens.get(i);String[] b=baseline.get(i);int index=Integer.parseInt(b[0]),begin=Integer.parseInt(b[3]),end=Integer.parseInt(b[4]);String word=dec(b[5]);
        require(index==i+1 && t.index()==index,"token index alignment");require(t.beginPosition()==begin && t.endPosition()==end,"token span alignment");require(t.originalText().equals(word) && source.substring(begin,end).equals(word),"token source alignment");
        CoreLabel u=new CoreLabel(t);u.remove(CoreAnnotations.PartOfSpeechAnnotation.class);u.remove(CoreAnnotations.LemmaAnnotation.class);u.remove(CoreAnnotations.NamedEntityTagAnnotation.class);require(u.tag()==null,"input must be untagged");untagged.add(u);
        tokenRows.add(m("index",index,"baselineNodeId",b[1],"baselineCopy",Integer.parseInt(b[2]),"begin",begin,"end",end,"sourceWord",word,"tokenizerWord",t.word(),"tokenizerOriginalText",t.originalText(),"inputPos",u.tag(),"baselinePos",dec(b[6]),"baselineLemma",dec(b[7]),"baselineNer",dec(b[8])));
      }
      report.put("alignment","EXACT_SOURCE_TOKEN_SENTENCE_SPANS");write(out.resolve("aligned-before-grammar.json"),report);
      report.put("stage","load-grammar");long load=System.nanoTime();LexicalizedParser parser=LexicalizedParser.loadModel(GRAMMAR,new String[0]);report.put("grammarLoadMillis",(System.nanoTime()-load)/1_000_000.0);
      report.put("stage","parse");long parse=System.nanoTime();Tree tree=parser.parseTree(untagged);report.put("parseMillis",(System.nanoTime()-parse)/1_000_000.0);
      require(tree!=null,"null tree");String penn=tree.toString();Files.writeString(out.resolve("tree.penn.txt"),penn+"\n");report.put("tree",penn);
      List<Tree> leaves=tree.getLeaves();var tagged=tree.taggedYield();require(leaves.size()==tokens.size()&&tagged.size()==tokens.size(),"tree leaf count");require(!"X".equals(tree.value()),"X fallback tree");
      List<Object> posRows=new ArrayList<>();report.put("pos",posRows);
      for(int i=0;i<tokens.size();i++){
        require(leaves.get(i).value().equals(tokens.get(i).word()),"tree leaf alignment");require(tagged.get(i).word().equals(tokens.get(i).word()),"tagged yield alignment");require(tagged.get(i).tag()!=null&&!tagged.get(i).tag().isBlank()&&!tagged.get(i).tag().equals("X"),"missing/recovery POS");
        String[] b=baseline.get(i);posRows.add(m("index",i+1,"baselineNodeId",b[1],"begin",tokens.get(i).beginPosition(),"end",tokens.get(i).endPosition(),"sourceWord",tokens.get(i).originalText(),"parserWord",tagged.get(i).word(),"pcfgPos",tagged.get(i).tag(),"baselinePos",dec(b[6]),"posChanged",!tagged.get(i).tag().equals(dec(b[6]))));
      }
      List<Object> constituentRows=new ArrayList<>();constituents(tree,0,tokens,source,constituentRows);report.put("constituents",constituentRows);report.put("treeLeafAlignment","EXACT_TOKENIZER_WORDS");report.put("status","OBSERVED");report.put("stage","complete");
    }catch(Throwable t){failure=t;report.put("status","FAILED");report.put("failure",m("class",t.getClass().getName(),"message",String.valueOf(t.getMessage())));t.printStackTrace(System.err);}
    finally{report.put("totalMillis",(System.nanoTime()-total)/1_000_000.0);write(out.resolve("observation.json"),report);}
    if(failure!=null)System.exit(1);
  }
}
