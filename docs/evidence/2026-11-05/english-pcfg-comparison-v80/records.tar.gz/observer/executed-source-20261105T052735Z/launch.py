"""Prepared launcher. Compiler/JVM actions require root's separate runtime GO first."""
import argparse,hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
JAVA=pathlib.Path('/workspace/.trikeshed-cloud/toolchains/graalvm-25/bin/java')
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def recorded(argv,out,limit):
 out.mkdir(parents=True,exist_ok=True);write(out/'argv.json',argv);started=time.time()
 with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
  try:r=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=limit);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 write(out/'process.json',{'exit':code,'elapsedSeconds':time.time()-started,'stdoutSha256':sha(out/'stdout.txt'),'stderrSha256':sha(out/'stderr.txt')});return code
p=argparse.ArgumentParser();p.add_argument('phase',choices=['compile','run','inside']);p.add_argument('--attempt',required=True);p.add_argument('--case',choices=['G07','G13']);p.add_argument('--root-go',action='store_true');p.add_argument('--parent-netns');a=p.parse_args()
assert a.root_go,'HOLD: separate explicit root GO is required before compilation/runtime'
assert os.environ.get('TRIKESHED_AIRGAP')=='1','preserve actual AIRGAP1; launcher does not override it'
attempt=pathlib.Path(a.attempt).resolve();assert attempt.is_relative_to(ROOT/'attempts')
frozen=json.loads((ROOT/'frozen-inputs.json').read_text())
for pin in [frozen['sdkManifest'],*frozen['sdkClasspath'],*frozen['tools'],*frozen['snapshotContextOnlyNotRuntimeClasspath'],*frozen['snapshotMetadata']]:assert sha(pin['path'])==pin['sha256'],('immutable pin changed',pin['path'])
for row in frozen['records']:
 for pin in row.values():assert sha(pin['path'])==pin['sha256'],('original/materialized record changed',pin['path'])
for pin in json.loads((ROOT/'protocol-manifest.json').read_text())['files']:assert sha(ROOT/pin['file'])==pin['sha256'],('protocol changed',pin['file'])
sdk=':'.join(row['path'] for row in frozen['sdkClasspath']);classes=attempt/'classes'
if a.phase=='inside':
 assert a.parent_netns and os.readlink('/proc/self/ns/net')!=a.parent_netns,'not a fresh network namespace'
 result=attempt/('compile' if a.case is None else a.case);result.mkdir(parents=True,exist_ok=True)
 assert recorded(['/usr/sbin/ip','link','set','lo','up'],result/'loopback-up',10)==0
 def network():
  addr=json.loads(subprocess.check_output(['/usr/sbin/ip','-j','address','show']));routes=json.loads(subprocess.check_output(['/usr/sbin/ip','-j','route','show','table','all']))
  assert len(addr)==1 and addr[0]['ifname']=='lo' and 'UP' in addr[0]['flags'],addr
  assert all(x.get('dev')=='lo' for x in routes),routes
  assert all(v['local'] in ['127.0.0.1','::1'] for n in addr for v in n.get('addr_info',[])),addr
  return {'namespace':os.readlink('/proc/self/ns/net'),'addresses':addr,'routes':routes,'claim':'this process network namespace contains loopback only; no whole-host/OS-seal claim'}
 write(result/'network-before.json',network());cpus=sorted(os.sched_getaffinity(0))[:2];assert cpus
 prefix=['/usr/bin/taskset','-c',','.join(map(str,cpus))]
 if a.case is None:
  classes.mkdir(exist_ok=False)
  argv=prefix+[str(JAVA.with_name('javac')),'-J-Xmx768m','-J-XX:ActiveProcessorCount=2','-proc:none','-encoding','UTF-8','-cp',sdk,'-d',str(classes),str(ROOT/'PcfgObserver.java')]
 else:
  assert classes.is_dir();argv=prefix+[str(JAVA),'-Xmx1536m','-XX:ActiveProcessorCount=2','-Djava.awt.headless=true','-cp',str(classes)+':'+sdk,'PcfgObserver',str(ROOT/'inputs'),a.case,str(result)]
 code=recorded(argv,result/'actual-process',180);write(result/'network-after.json',network());sys.exit(code)
if a.phase=='compile':attempt.mkdir(parents=True,exist_ok=False)
else:
 assert a.case and classes.is_dir();assert not (attempt/a.case).exists(),'preserve earlier case attempt; use a fresh compile/attempt for retry'
 assert json.loads((attempt/'compile'/'actual-process'/'process.json').read_text())['exit']==0
 if a.case=='G13':
  assert json.loads((attempt/'G07'/'observation.json').read_text())['status']=='OBSERVED','stop and inspect first genuine G07 failure before broader execution'
casearg=['--case',a.case] if a.phase=='run' else []
cmd=['/usr/bin/unshare','--user','--map-root-user','--net','--fork','--kill-child=SIGKILL',sys.executable,str(ROOT/'launch.py'),'inside','--root-go','--attempt',str(attempt),'--parent-netns',os.readlink('/proc/self/ns/net'),*casearg]
exitcode=recorded(cmd,attempt/('compile-netns' if a.phase=='compile' else a.case+'-netns'),210)
if classes.exists():write(attempt/'compiled-classes.json',[{'path':str(x.relative_to(attempt)),'sha256':sha(x)} for x in sorted(classes.rglob('*.class'))])
print(json.dumps({'phase':a.phase,'case':a.case,'attempt':str(attempt),'exit':exitcode}));sys.exit(exitcode)
