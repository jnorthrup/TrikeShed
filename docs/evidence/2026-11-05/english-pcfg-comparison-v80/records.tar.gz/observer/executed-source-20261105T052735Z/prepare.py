"""Static pin/materialization step only; no compiler, JVM or parser invocation."""
import base64,hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parent
SDK=pathlib.Path('/workspace/TrikeShed/utils/subvm/corenlp')
SNAP=pathlib.Path('/workspace/library-files/english-guard-corpus-v79-proof/snapshot')
BASE=pathlib.Path('/workspace/library-files/english-guard-attachment-v76-baseline/attempt-remaining/cases')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def copy(p,d):
 d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists():assert d.read_bytes()==p.read_bytes(),('would overwrite',d)
 else:shutil.copyfile(p,d)
 return pin(d)
assert (SNAP/'source-head.txt').read_text().strip()=='c9298dc6846281de16475878c92ff8ca3b56b5c8'
assert digest(SNAP/'main.jar')=='e2352d79aa5b8a6180ed7152897a80bd98d86a48cd3282e4656268ec1ee7bf0d'
rows=(SDK/'MANIFEST.tsv').read_text().splitlines();jars=[]
for line in rows:
 a=line.split('\t')
 if len(a)!=3 or not a[0].endswith('.jar'):continue
 p=SDK/'lib'/a[0];r=pin(p);assert r['bytes']==int(a[1]) and r['sha256']==a[2];jars.append(r)
assert len(jars)==28
context=[pin(pathlib.Path(x)) for x in (SNAP/'classpath.txt').read_text().strip().split(':')]
assert len(context)==120
records=[]
for case in ['G07','G13']:
 src=BASE/case;dst=ROOT/'inputs'/case;r=json.loads((src/'response.json').read_text());assert len(r['sentences'])==1
 for p in sorted(src.rglob('*')):
  if p.is_file():records.append({'original':pin(p),'materialized':copy(p,dst/p.relative_to(src))})
 source=(dst/'source.txt').read_bytes();assert 'sha256:'+hashlib.sha256(source).hexdigest()==r['extractedTextCid']==r['originalCid']
 assert len(source.decode().encode('utf-16-le'))//2==r['range']['end']-r['range']['begin']
 lines=[]
 for t in r['sentences'][0]['tokens']:
  nodes=[n for n in r['sentences'][0]['nodes'] if n['index']==t['index'] and n['copy']==0];assert len(nodes)==1;n=nodes[0]
  line=[str(t['index']),n['id'],str(n['copy']),str(t['begin']),str(t['end'])]+[base64.b64encode(str(t[k]).encode()).decode() for k in ['word','pos','lemma','ner']]
  lines.append('\t'.join(line))
 (dst/'tokens.tsv').write_text('\n'.join(lines)+'\n')
 (dst/'identity.properties').write_text('sourceCid='+r['extractedTextCid']+'\nreceiptCid='+r['receiptCid']+'\n')
java=pathlib.Path('/workspace/.trikeshed-cloud/toolchains/graalvm-25/bin/java');javac=java.with_name('javac')
frozen={'status':'PREPARED_NOT_COMPILED_NOT_PARSED','sourceHead':(SNAP/'source-head.txt').read_text().strip(),'snapshotContextOnlyNotRuntimeClasspath':context,'snapshotMetadata':[pin(SNAP/x) for x in ['source-head.txt','sha256.json','passing-build.log','classpath.txt']],'sdkManifest':pin(SDK/'MANIFEST.tsv'),'sdkClasspath':jars,'runtimeClasspathRule':'observer compiled directory + these28SDKjars; NO application main.jar','tools':[pin(java),pin(javac)],'records':records,'originalReceiptProducerSource':'0219223a3846887fe283b93598942de332214cd2','originalReceiptProducerMainSha256':'d0a8133b10e4b18e1bd4076c1440688ad94a2eeb2bbcdefe743f4759ace75636'}
(ROOT/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
print('PREPARED static materialized inputs,28SDK/120contextJAR hashes; NO compiler/JVM/parser invocation')
