"""Read completed external observations; no compiler/JVM/parser invocation."""
import argparse,json,pathlib,hashlib
p=argparse.ArgumentParser();p.add_argument('attempt');a=p.parse_args();attempt=pathlib.Path(a.attempt);root=pathlib.Path(__file__).resolve().parent;rows=[]
for case in ['G07','G13']:
 f=attempt/case/'observation.json'
 if not f.exists():rows.append({'case':case,'status':'NOT_RUN_OR_NO_OBSERVATION','noSyntacticResultInferred':True});continue
 r=json.loads(f.read_text());baseline=json.loads((root/'inputs'/case/'response.json').read_text());source=(root/'inputs'/case/'source.txt').read_text()
 assert r['source']['baselineInspectionCid']==baseline['receiptCid'] and r['source']['text']==source
 if r['status']=='OBSERVED':
  assert r['alignment']=='EXACT_SOURCE_TOKEN_SENTENCE_SPANS' and r['treeLeafAlignment']=='EXACT_TOKENIZER_WORDS'
  assert len(r['pos'])==len(baseline['sentences'][0]['tokens'])
  for t in r['pos']:assert source[t['begin']:t['end']]==t['sourceWord']
 rows.append({'case':case,'status':r['status'],'stage':r['stage'],'sourceCid':r['source']['extractedTextCid'],'baselineInspectionCid':baseline['receiptCid'],'observationSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'grammar':r.get('grammar'),'posDifferences':[x for x in r.get('pos',[]) if x['posChanged']],'treeFile':str(attempt/case/'tree.penn.txt'),'failure':r.get('failure'),'baselineDependenciesUnchanged':baseline['sentences'][0]['dependencies'],'meaning':'observed syntactic differences only; no legal truth or accuracy denominator'})
report={'schema':'external-pcfg-comparison-summary/1','cases':rows,'sourceAndBaselineReceiptsUnmodified':True,'newProductionInspectionReceipts':0,'accuracyRate':None,'interpretation':'PCFG is a statistical grammar, not an LLM or document generator. Model disagreement does not establish either parse as true.'}
(attempt/'comparison-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'statuses':[{k:r[k] for k in ['case','status']} for r in rows]}))
