package proof.guardcorpus

import borg.trikeshed.couch.*
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.memory.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.EnglishObservationGraph
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

/** Separate closed-state CAS/project reader; no parser, model, query, module or listener. */
fun main(args:Array<String>)=runBlocking {
 val out=File(args[0]).canonicalFile;val runtime=File(out,"runtime");val pack=File(runtime,"cas/pack")
 require(File(out,"GO.json").isFile && File(out,"cleanup.json").isFile)
 java.lang.System.setProperty(GuestModules.HOME_PROPERTY,"/workspace/library-files/corpus-concordance-v79-preparation/isolated-subvm")
 check(GuestModules.installed()==listOf("corenlp") && GuestModules.mounted().isEmpty())
 fun stamp(f:File):Map<String,Any?> {val b=f.readBytes();return mapOf("bytes" to b.size,"sha256" to ContentId.of(b).hex)}
 fun owners()=File(runtime,"host").walkTopDown().filter{it.isFile}.associate{it.relativeTo(runtime).path to stamp(it)}
 val packBefore=stamp(pack);val ownerBefore=owners();val writer=reifyStrict(File(out,"cleanup.json").readText()) as Map<*,*>
 check((writer["pid"] as Number).toLong()!=ProcessHandle.current().pid())
 val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").absolutePath)
 val index=reifyStrict(File(out,"readback-index.json").readText()) as List<*>;require(index.isNotEmpty())
 val readbacks=index.map{entry->val e=entry as Map<*,*>;val cid=ContentId(e["cid"] as String);val bytes=checkNotNull(cas.getBounded(cid,8*1024*1024));check(ContentId.of(bytes)==cid && bytes.contentEquals(File(out,e["file"] as String).readBytes()));mapOf("cid" to cid.value,"role" to e["role"],"bytes" to bytes.size,"sha256" to ContentId.of(bytes).hex)}
 val cases=reifyStrict(File(out,"cases.json").readText()) as Map<*,*>
 for((_,raw)in cases){val c=raw as Map<*,*>;val s=EnglishObservationGraph.read(cas,ContentId(c["inspectionCid"] as String));check(s.source.text==c["text"])}
 val browser=reifyStrict(File(out,"browser-result.json").readText()) as Map<*,*>;val observed=browser["observed"] as Map<*,*>
 val fresh=observed["freshInspections"] as List<*>;check(fresh.size==2)
 val newInspections=fresh.map{raw->val response=(raw as Map<*,*>)["response"] as Map<*,*>;val cid=ContentId(response["receiptCid"] as String);val s=EnglishObservationGraph.read(cas,cid);mapOf("receiptCid" to cid.value,"selection" to s.selection.toMap(),"sourceTextSha256" to ContentId.of(s.source.text.encodeToByteArray()).hex,"inventory" to s.inventory)}
 val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas);val registry=ProjectDbRegistry("primary")
 val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,projectDbs=registry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"))
 check(scopes.remountLedger()==1);val corpus=JvmProjectCorpus(registry,scopes);val export=File(out,"after-close-readbacks").apply{mkdirs()}
 val rows=cases.mapValues{(id,raw)->val c=raw as Map<*,*>;val old=c["row"] as Map<*,*>;val row=checkNotNull(corpus.document(old["project"] as String,old["id"] as String));val bytes=checkNotNull(corpus.bytes(row.project,row.id));check(ContentId.of(bytes).value==row.cid)
  if(id in listOf("S12","G03")){check(row.cid!=old["cid"] && row.rev!=old["rev"] && row.seq!=(old["seq"] as Number).toLong());File(export,"actual-amended-$id-source.txt").writeBytes(bytes)}else check(row.cid==old["cid"] && row.rev==old["rev"] && row.seq==(old["seq"] as Number).toLong())
  row.toMap()}
 scopes.drain();cas.close();GuestModules.closeAll();check(stamp(pack)==packBefore && owners()==ownerBefore)
 File(out,"reopened.json").writeText(jsonOf(mapOf("result" to "PASS","writerPid" to writer["pid"],"readerPid" to ProcessHandle.current().pid(),"writerCleanup" to writer,"readbacks" to readbacks,"newInspections" to newInspections,"currentRows" to rows,"packBeforeOpen" to packBefore,"packAfterClose" to stamp(pack),"ownerFilesBeforeOpen" to ownerBefore,"ownerFilesAfterClose" to owners(),"codeSources" to mapOf("PackCasStore" to PackCasStore::class.java.protectionDomain.codeSource.location.toString(),"EnglishObservationGraph" to EnglishObservationGraph::class.java.protectionDomain.codeSource.location.toString(),"JvmProjectCorpus" to JvmProjectCorpus::class.java.protectionDomain.codeSource.location.toString()),"guestModulesInstalled" to GuestModules.installed(),"guestModulesMountedAfterClose" to GuestModules.mounted(),"guestModulesClosed" to GuestModules.closed.isCompleted,"closed" to true,"scope" to "Separate production bounded-reader readback only; original/fresh receipts and historical source availability do not confer current authority after actual amendments")))
}
