"""Read-only static/retained-input preparation; launches no runtime or parser."""
import hashlib,json,runpy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CORE=ROOT/'receipt-core.py.txt'
assert hashlib.sha256(CORE.read_bytes()).hexdigest()=='8236cc40432334f746a4ff5e8e9d80845ae92c09b720ed4cc50840826324d763'
C=runpy.run_path(str(CORE));need=C['need'];cid=C['cid'];load=C['load'];decode=C['decode_cbor']
proof=Path('/workspace/library-files/guard-corpus-v79-native-proof')
observed={}
for key in ['G03','G04','G07','G13']:
    folder=proof/'inputs'/key;body=load(folder/'response.json');source=(folder/'source.txt').read_bytes()
    raw=(folder/'cas-readbacks'/(body['receiptCid'][7:]+'.cbor')).read_bytes()
    need(cid(raw)==body['receiptCid'] and decode(raw)=={k:v for k,v in body.items() if k!='receiptCid'},'Original actual canonical receipt')
    need(cid(source)==body['originalCid']==body['extractedTextCid'],'Original source content identity')
    sentences=[]
    for s in body['sentences']:
        edges=s['dependencies'];nodes=s['nodes'];markers=s['markers']
        links=[e for e in edges if e['relation'].lower()=='advcl' or e['relation'].lower().startswith('advcl:')]
        marker_rows=[]
        for ordinal,m in enumerate(markers):
            if m['kind'] not in ['condition','exception','negation']:continue
            aligned=[n['id'] for n in nodes if n['begin']>=m['begin'] and n['end']<=m['end']]
            marker_rows.append({'ordinal':ordinal,'kind':m['kind'],'quote':m['quote'],'begin':m['begin'],'end':m['end'],'nodeIds':aligned,
              'incomingEdges':[e for e in edges if e['dependentNode'] in aligned]})
        sentences.append({'index':s['index'],'quote':s['quote'],'advclEdges':links,'directMarkersAndCues':marker_rows,
          'nodeWords':{n['id']:n['word'] for n in nodes},'quoteIndicatorNodeIds':[n['id'] for n in nodes if any(c in n['word'] for c in '\"“”‘’')]})
    observed[key]={'inspectionCid':body['receiptCid'],'sourceCid':body['originalCid'],'sourceUtf8':source.decode('utf8'),'sentences':sentences,
      'historicalNormDiagnostics':load(folder/'condition-diagnostics.json'),'meaning':'raw observed dependencies/lexical markers and separately recorded diagnostic only; no legal force or accuracy gold'}
(ROOT/'raw-retained-observations.json').write_text(json.dumps(observed,indent=2,ensure_ascii=False)+'\n')
closure=Path('/workspace/library-files/corpus-concordance-v79-preparation/static-closure.json')
need(hashlib.sha256(closure.read_bytes()).hexdigest()=='9424b0a673e7f9a0189d216304a7e38ebcbb76bf572e13188c11e51aad4574ab','Pinned static closure metadata')
meta=load(closure);origin=Path(meta['origin']['directory']);rows=meta['closure']['files']
actual={str(p.relative_to(origin)) for p in origin.rglob('*') if p.is_file()}
need(actual=={r['relativePath'] for r in rows} and len(rows)==29,'Exact29-file static SDK closure')
for row in rows:
    p=origin/row['relativePath'];need(not p.is_symlink() and p.stat().st_size==row['bytes'],'Actual static closure bytes/type')
    with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    need(digest==row['sha256'],'Actual static closure file hash')
summary={'result':'PASS_STATIC_FILES_AND_ORIGINAL_RETAINED_BYTES_ONLY','closureMetadataSha256':hashlib.sha256(closure.read_bytes()).hexdigest(),
 'closureFiles':len(rows),'closureBytes':sum(r['bytes'] for r in rows),'rawGuardCases':len(observed),'observedAdvclEdges':sum(len(s['advclEdges']) for c in observed.values() for s in c['sentences']),
 'modelJar':meta['modelJar'],'freshParserRequests':'NOT_EXECUTED_BY_AUDITOR','native':'NOT_RUN_NOT_VERIFIED','scope':'Only read-only static files and already recorded source/CBOR consistency; no JVM/GuestModules/parser/build/browser execution or legal-accuracy claim.'}
(ROOT/'static-and-retained-preparation-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['modelJar','scope']}))
