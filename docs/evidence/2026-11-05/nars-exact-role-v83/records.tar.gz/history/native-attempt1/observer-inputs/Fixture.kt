package proof.exactrole

import borg.trikeshed.agent.modelmux.Airgap
import borg.trikeshed.couch.*
import borg.trikeshed.cursor.BudgetCoord
import borg.trikeshed.dag.*
import borg.trikeshed.forge.server.*
import borg.trikeshed.graal.ConfixBlackboard
import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.*
import borg.trikeshed.kanban.module.KanbanModule
import borg.trikeshed.lcnc.*
import borg.trikeshed.lib.*
import borg.trikeshed.litebike.*
import borg.trikeshed.modelmux.*
import borg.trikeshed.memory.*
import borg.trikeshed.module.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.rdf.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.util.oroboros.*
import kotlinx.coroutines.*
import java.io.File

class ObserverMarker

/** External public composition only; no replacement intake, selector, query, attention or run service. */
fun main(args:Array<String>)=runBlocking(Airgap()) {
 val out=File(args[0]).canonicalFile;val snapshot=File(args[1]).canonicalFile;val port=args[2].toInt()
 val go=reifyStrict(File(out,"GO.json").readText()) as Map<*,*>;check(ContentId.of(File(snapshot,"main.jar").readBytes()).hex==go["mainSha256"])
 val runtime=File(out,"runtime").apply{mkdirs()};val empty=File(out,"empty-subvm").apply{mkdirs()};check(empty.listFiles().orEmpty().isEmpty())
 java.lang.System.setProperty(GuestModules.HOME_PROPERTY,empty.path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 val files=JvmFileOperations();val cas=PackCasStore(files,File(runtime,"cas").path);val pack=File(runtime,"cas/pack")
 val owner=SupervisorJob(coroutineContext[Job]);val scope=CoroutineScope(coroutineContext+Dispatchers.IO+owner+files)
 val beliefWalFile=File(runtime,"beliefs.wal");val beliefWal=DocumentAppendLog.open(beliefWalFile.path,runtime.path)
 val bag=BeliefBagElement(cas=cas,wal=beliefWal,flushEvery=1000,priorityFloor=.5f,parentJob=owner);bag.open()
 val review=TurnReviewElement(bag);review.open();val beliefWire=BeliefWire(bag,review,null)
 val store=CouchStoreFactory.casBacked(cas);val gateway=CouchAttachmentGateway(store,cas)
 fun stamp(file:File):Map<String,Any?> {val bytes=file.readBytes();return _m["bytes" j bytes.size,"sha256" j ContentId.of(bytes).hex]}
 fun bagRows()=bag.snapshot().values.sortedBy{it.angular}.map{signal->val budget=checkNotNull(bag.budgetOf(signal.angular));val bytes=SignalCodec.encode(signal);_m[
  "angular" j signal.angular.toString(),"signalUtf8" j bytes.decodeToString(),"signalBase64" j java.util.Base64.getEncoder().encodeToString(bytes),"signalSha256" j ContentId.of(bytes).hex,
  "propositionCid" j signal.propositionCid,"subjectCid" j signal.subjectCid,"objectCid" j signal.objectCid,"relation" j signal.relation.name,"evidencePacked" j signal.evidence.packed.toString(),"provenanceCid" j signal.provenanceCid,"basisBloom" j signal.basisBloom.toString(),"evidence" j _m["positive" j signal.evidence.positive,"negative" j signal.evidence.negative],
  "budget" j _m["packed" j budget.packed.toString(),"p" j budget.pf,"d" j budget.df,"q" j budget.qf],"gloss" j bag.glossOf(signal.angular)]}
 val ctx=ModuleContext(Couch("exact-role-v82",store,cas),ReteNetwork(),ReteProductionRegistry(),bag,review,ConfixBlackboard.empty(),cas,gateway,ModuleRouteRegistry(),scope,{java.lang.System.currentTimeMillis()},File(runtime,"host").apply{mkdirs()})

 val primitiveRecords=mutableListOf<Map<String,Any?>>()
 fun primitiveState()=_m["bagRows" j bagRows(),"pack" j stamp(pack),"beliefWal" j stamp(beliefWalFile)]
 fun observed(kind:String,delegate:LcncNodeRunner)=LcncNodeRunner{node,inputs->
  val before=primitiveState()
  try {val output=delegate.run(node,inputs);primitiveRecords.add(_m["kind" j kind,"nodeId" j node.id,"params" j node.params,"inputs" j inputs,"delegateCodeSource" j delegate.javaClass.protectionDomain.codeSource.location.toString(),"before" j before,"after" j primitiveState(),"output" j output]);File(out,"primitive-boundaries.json").writeText(jsonOf(primitiveRecords));output}
  catch(t:Throwable){primitiveRecords.add(_m["kind" j kind,"nodeId" j node.id,"params" j node.params,"inputs" j inputs,"delegateCodeSource" j delegate.javaClass.protectionDomain.codeSource.location.toString(),"before" j before,"after" j primitiveState(),"refusal" j _m["type" j t.javaClass.name,"message" j t.message]]);File(out,"primitive-boundaries.json").writeText(jsonOf(primitiveRecords));throw t}
 }
 ctx.lcncRunners.putAll(PureNodes.registry(ctx.clock));ctx.lcncRunners.putAll(TribunalNodes.registry(TribunalDialog{_,_,_->error("No provider configured")}).filterKeys{it=="display"});ctx.lcncRunners["nal.recall"]=observed("nal.recall",NalNodes.recallRunner(bag));ctx.lcncRunners["nal.attend"]=observed("nal.attend",BeliefsNodes.attendRunner(bag))
 val module=KanbanModule().open(ctx);val brain=BrainClient(endpointSpecs=emptyList());check(!brain.hasEndpoints()&&brain.modelMux().listModels().isEmpty())
 val projectRegistry=ProjectDbRegistry("primary");val scopes=ProjectScopes(files,gateway,CouchIndexBridge(gateway,MemoryIndexLayer(MemoryStore(cas,store))),cas,null,projectDbs=projectRegistry,ledgerFile=File(runtime,"projects.tsv"),filesRoot=File(runtime,"files"));val patch=PatchWire(brain,scopes,attachments=gateway)
 val couchWire=CouchWire(CouchWireRouter(ctx.couch,attachmentPrefix=""),null,scope)
 val fixtures=linkedMapOf<String,Any?>();val sourceC2=File(out,"inputs/C2.kif").readBytes();check(ContentId.of(sourceC2).hex=="856e48302ec7ce9e8db378cad6244b49c8510d80376b914c95c37a811420ba05")
 for(name in _l["unsupported.kif","missing-definition.kif","bounded-65.kif"]) {
  val bytes=File(out,"inputs/$name").readBytes();val text=bytes.decodeToString(throwOnInvalidSequence=true)
  val definitions=if(name=="bounded-65.kif") {val batch=KgRetention.prepare(text,KgNalBridge.bridge(text));bag.retainKg(batch);batch.definitions.view.map{it.cid.value}}else {cas.put(bytes);emptyList<String>()}
  fixtures[name]=_m["sourceCid" j ContentId.of(bytes).value,"bytes" j bytes.size,"definitionCids" j definitions,"expectedMissingDefinitionCid" j if(name=="missing-definition.kif")KgNalBridge.bridge(text).single().propositionCid(ContentId.of(bytes).value).value else null,"policy" j if(name=="bounded-65.kif")"public actor-retained source+definitions; no assertion admission" else "raw source-only negative fixture; no assertion/definition admission"]
 }
 cas.sync()
 suspend fun state():Map<String,Any?> {bag.awaitProcessed();return _m[
  "pid" j ProcessHandle.current().pid(),"bagRows" j bagRows(),"bagSize" j bag.size,"pack" j stamp(pack),"beliefWal" j stamp(beliefWalFile),"boardWal" j stamp(File(ctx.stateDir,".kanban/board.wal")),
  "blackboard" j ctx.blackboard.snapshot().values,"reteFacts" j ctx.rete.snapshot().view.map{f->_m["partition" j f.factId.a,"id" j f.factId.b,"fields" j f.fields,"versionCid" j f.versionCid.value]},
  "beliefBagPresent" j (ctx.beliefBag!=null),"kifBankPresent" j (ctx.kifBank!=null),"narsRetePresent" j (ctx.narsRete!=null),"guestInstalled" j GuestModules.installed(),"guestMounted" j GuestModules.mounted(),"modelEndpointsPresent" j brain.hasEndpoints(),"configuredModelCount" j brain.modelMux().listModels().size,
  "lastAdmissionRefusal" j bag.lastAdmissionRefusal?.let{_m["issue" j it.issue.name,"angular" j it.angular.toString(),"message" j it.message]},"networkNamespace" j java.nio.file.Files.readSymbolicLink(java.nio.file.Path.of("/proc/self/ns/net")).toString()]}
 val classes=_m["PackCasStore" j PackCasStore::class.java,"DocumentAppendLog" j DocumentAppendLog::class.java,"BeliefBagElement" j BeliefBagElement::class.java,"BeliefWire" j BeliefWire::class.java,"KgRetention" j KgRetention::class.java,"KgNalBridge" j KgNalBridge::class.java,"SignalCodec" j SignalCodec::class.java,"NalNodes" j NalNodes::class.java,"BeliefsNodes" j BeliefsNodes::class.java,"JvmKanbanServer" j JvmKanbanServer::class.java,"KanbanModule" j KanbanModule::class.java,"BoardStoreElement" j BoardStoreElement::class.java,"CouchWire" j CouchWire::class.java,"CouchWireRouter" j CouchWireRouter::class.java,"SparqlWire" j SparqlWire::class.java,"SparqlSurface" j SparqlSurface::class.java,"QuadStore" j QuadStore::class.java]
 val origins=classes.mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also{check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))}}.toMutableMap()
 origins["LcncRunService"]=Class.forName("borg.trikeshed.kanban.module.LcncRunService").protectionDomain.codeSource.location.toString()
 val baseline=state();val meta=_m["go" j go,"baseline" j baseline,"origins" j origins,"negativeFixtures" j fixtures,"sourceC2" j _m["cid" j ContentId.of(sourceC2).value,"bytes" j sourceC2.size,"text" j sourceC2.decodeToString()],"ownerConfiguration" j _m["priorityFloor" j .5,"decay" j "identity","flushEvery" j 1000,"beliefWal" j beliefWalFile.canonicalPath,"sourceAdmission" j "manual KIF claims; actual production HTTP intake occurs after startup"],"observerCodeSource" j ObserverMarker::class.java.protectionDomain.codeSource.location.toString()]
 File(out,"startup.json").writeText(jsonOf(meta));val finish=CompletableDeferred<Unit>()
 val control:ExtraRoute={method,path,text,respond->when{
  method=="GET"&&path=="/__v83/meta"->JvmKanbanServer.HttpResponse(200,jsonOf(meta))
  method=="GET"&&path=="/__v83/state"->JvmKanbanServer.HttpResponse(200,jsonOf(state()))
  method=="POST"&&path=="/__v83/finish"->{File(out,"writer-final-state.json").writeText(jsonOf(state()));finish.complete(Unit);JvmKanbanServer.HttpResponse(200,"{}")}
  method=="GET"&&path.startsWith("/api/panels")->patch.route(method,path,text,respond)
  path.startsWith("/api/beliefs")->beliefWire.route(method,path,text,respond)
  else->null
 }}
 val raw:RawRoute={method,path,payload,respond->if(method=="GET"&&path.substringBefore('?')=="/api/v0/block/get")couchWire.route(method,path,payload,respond)else null}
 val server=JvmKanbanServer(extraRoutes=_l[control],rawRoutes=_l[raw],stateDir=ctx.stateDir,moduleRoutes=ctx.routes);val listener=launch(Dispatchers.IO){server.run(port,null)}
 try{finish.await()}finally{withContext(NonCancellable){listener.cancelAndJoin();ctx.routes.release("kanban");module.drain();module.close();scopes.drain();review.drain();bag.drain();beliefWal.close();owner.complete();owner.join();cas.sync();cas.close();GuestModules.closeAll()
  File(out,"cleanup.json").writeText(jsonOf(_m["pid" j ProcessHandle.current().pid(),"listenerJoined" j listener.isCompleted,"moduleDrained" j true,"reviewOwnerCompleted" j review.admission.isCompleted,"bagOwnerCompleted" j bag.supervisor.isCompleted,"bagWorkerCompleted" j (bag.worker?.isCompleted==true),"ownerCompleted" j owner.isCompleted,"remainingChildren" j owner.children.count(),"casClosed" j true,"guestModulesClosed" j GuestModules.closed.isCompleted,"closedPack" j stamp(pack),"closedBeliefWal" j stamp(beliefWalFile),"closedBoardWal" j stamp(File(ctx.stateDir,".kanban/board.wal"))]))
 }}
}
