package proof.exactrole

import borg.trikeshed.graal.subvm.GuestModules
import borg.trikeshed.job.*
import borg.trikeshed.kanban.*
import borg.trikeshed.lib.*
import borg.trikeshed.narsese.*
import borg.trikeshed.parse.*
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import kotlinx.coroutines.*
import java.io.File

/** Readback/replay of the explicitly configured production logs; no selector/attention/mint call. */
fun main(args:Array<String>)=runBlocking {
 val out=File(args[0]).canonicalFile;val runtime=File(out,"runtime");val writer=reifyStrict(File(out,"cleanup.json").readText()) as Map<*,*>;val snapshot=File((reifyStrict(File(out,"GO.json").readText()) as Map<*,*>)["snapshot"] as String).canonicalFile
 check(ProcessHandle.current().pid()!=(writer["pid"] as Number).toLong());java.lang.System.setProperty(GuestModules.HOME_PROPERTY,File(out,"empty-subvm").path);check(GuestModules.installed().isEmpty()&&GuestModules.mounted().isEmpty())
 fun stamp(file:File):Map<String,Any?> {val b=file.readBytes();return _m["bytes" j b.size,"sha256" j ContentId.of(b).hex]}
 val pack=File(runtime,"cas/pack");val beliefWalFile=File(runtime,"beliefs.wal");val boardDir=File(runtime,"host/.kanban");val boardWalFile=File(boardDir,"board.wal")
 val before=_m["pack" j stamp(pack),"beliefWal" j stamp(beliefWalFile),"boardWal" j stamp(boardWalFile)]
 val cas=PackCasStore(JvmFileOperations(),File(runtime,"cas").path);val owner=SupervisorJob(coroutineContext[Job]);val beliefWal=DocumentAppendLog.open(beliefWalFile.path,runtime.path);val beliefFrames=mutableListOf<Map<String,Any?>>()
 beliefWal.replay{seq,bytes->beliefFrames.add(_m["sequence" j seq,"payloadUtf8" j bytes.decodeToString(throwOnInvalidSequence=true),"payloadSha256" j ContentId.of(bytes).hex])}
 val bag=BeliefBagElement(cas=cas,wal=beliefWal,flushEvery=1000,priorityFloor=.5f,parentJob=owner);bag.open();bag.awaitProcessed()
 val finalWriter=reifyStrict(File(out,"writer-final-state.json").readText()) as Map<*,*>;check((finalWriter["bagRows"] as List<*>).isEmpty()&&bag.size==0)
 val boardWal=BoardFileWal(JvmFileOperations(),boardDir.path);val boardFrames=mutableListOf<Map<String,Any?>>()
 boardWal.replay{seq,bytes->boardFrames.add(_m["sequence" j seq,"payloadUtf8" j bytes.decodeToString(throwOnInvalidSequence=true),"payloadSha256" j ContentId.of(bytes).hex])}
 val board=BoardStoreElement(wal=boardWal,cas=cas,parentJob=owner);board.open()
 val result=reifyStrict(File(out,"http-result.json").readText()) as Map<*,*>;val runs=result["runs"] as List<*>
 val cards=runs.mapNotNull{raw->val run=raw as Map<*,*>;val response=(run["http"] as Map<*,*>)["response"] as Map<*,*>;val job=response["jobId"] as? String?:return@mapNotNull null;val row=checkNotNull(board.card(job));check(checkNotNull(row.commandCid).value==response["receiptCid"]);val command=checkNotNull(board.command(job));val saved=command["lcncRun"] as Map<*,*>;check(saved["runId"]==response["runId"]&&saved["programCid"]==response["programCid"]);_m["label" j run["label"],"jobId" j job,"column" j row.col.toString(),"commandCid" j checkNotNull(row.commandCid).value,"revision" j row.revision,"sequence" j row.lastSequence,"command" j command]}
 val readbackDir=File(out,"after-close-readbacks").apply{mkdirs()};val index=reifyStrict(File(out,"readback-index.json").readText()) as List<*>;val readbacks=index.map{raw->val e=raw as Map<*,*>;val cid=ContentId(e["cid"] as String);val bytes=checkNotNull(cas.getBounded(cid,4*1024*1024));check(ContentId.of(bytes)==cid&&bytes.contentEquals(File(out,e["file"] as String).readBytes()));val target=File(readbackDir,cid.hex+".bin");target.writeBytes(bytes);_m["cid" j cid.value,"bytes" j bytes.size,"sha256" j ContentId.of(bytes).hex,"file" j target.relativeTo(out).path,"role" j e["role"]]}
 val bagRows=bag.snapshot().values.map{_m["angular" j it.angular.toString(),"signalBase64" j java.util.Base64.getEncoder().encodeToString(SignalCodec.encode(it)),"propositionCid" j it.propositionCid,"budgetPacked" j bag.budgetOf(it.angular)?.packed?.toString()]}
 board.drain();board.close();bag.drain();beliefWal.close();owner.complete();owner.join();cas.close();GuestModules.closeAll()
 val after=_m["pack" j stamp(pack),"beliefWal" j stamp(beliefWalFile),"boardWal" j stamp(boardWalFile)];check(before==after)
 val origins=_m["PackCasStore" j PackCasStore::class.java,"DocumentAppendLog" j DocumentAppendLog::class.java,"BeliefBagElement" j BeliefBagElement::class.java,"BoardFileWal" j BoardFileWal::class.java,"BoardStoreElement" j BoardStoreElement::class.java].mapValues{(_,c)->c.protectionDomain.codeSource.location.toString().also{check(File(java.net.URI(it)).canonicalFile==File(snapshot,"main.jar"))}}
 File(out,"reopened.json").writeText(jsonOf(_m["result" j "PASS","readerPid" j ProcessHandle.current().pid(),"writerPid" j writer["pid"],"writerCleanup" j writer,"beforeOpen" j before,"afterClose" j after,"beliefFrames" j beliefFrames,"boardFrames" j boardFrames,"replayedBagRows" j bagRows,"recoveredBoardCards" j cards,"readbacks" j readbacks,"origins" j origins,"bagOwnerCompleted" j bag.supervisor.isCompleted,"boardOwnerCompleted" j board.supervisor.isCompleted,"ownerCompleted" j owner.isCompleted,"remainingChildren" j owner.children.count(),"casClosed" j true,"guestModulesClosed" j GuestModules.closed.isCompleted,"scope" j "Actual configured production DocumentAppendLog replay and retained byte readbacks after writer processed eviction. Empty final replay projection is compared to writer; not evidence from an unconfigured fresh bag, and no active priority recovery is claimed.")))
}
