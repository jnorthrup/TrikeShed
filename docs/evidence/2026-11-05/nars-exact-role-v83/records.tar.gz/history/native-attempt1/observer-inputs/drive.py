"""Actual loopback HTTP protocol only. Does not reproduce the selector/engine/actor."""
from pathlib import Path
import os,json,base64,hashlib,urllib.request,urllib.error,subprocess
out=Path(os.environ['PROOF_ARTIFACTS']);base=os.environ['PROOF_URL'];http=urllib.request.build_opener(urllib.request.ProxyHandler({}));records=[];reads=[];states=[];runs=[]
def encode(v):return json.dumps(v,separators=(',',':'),ensure_ascii=False).encode()
def digest(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
def request(label,path,body=None,method=None):
 data=body if isinstance(body,bytes) else None if body is None else encode(body);method=method or ('GET' if data is None else 'POST');req=urllib.request.Request(base+path,data=data,method=method,headers={'Content-Type':'application/json'})
 try:r=http.open(req,timeout=120)
 except urllib.error.HTTPError as e:r=e
 raw=r.read();status=r.status;name=label+'-response.bin';(out/name).write_bytes(raw)
 if data is not None:(out/(label+'-request.bin')).write_bytes(data)
 record={'label':label,'method':method,'path':path,'status':status,'requestBase64':None if data is None else base64.b64encode(data).decode(),'responseFile':name,'responseBytes':len(raw),'responseSha256':digest(raw),'response':json.loads(raw) if raw[:1] in [b'{',b'['] else None};records.append(record);(out/'http-progress.json').write_text(json.dumps(records,indent=2)+'\n');return record

def state(label):
 r=request(label+'/state' if False else label+'-state','/__v83/state');assert r['status']==200;states.append({'label':label,'state':r['response']});return r['response']
def read(cid,role):
 from urllib.parse import quote
 r=request('cas-'+str(len(reads)),'/api/v0/block/get?arg='+quote(cid));assert r['status']==200;raw=(out/r['responseFile']).read_bytes();assert digest(raw)==cid
 folder=out/'cas-readbacks';folder.mkdir(exist_ok=True);file='cas-readbacks/'+cid[7:]+'.bin';(out/file).write_bytes(raw);reads.append({'cid':cid,'role':role,'bytes':len(raw),'sha256':digest(raw),'file':file});return raw

def role(context,predicate='pays',subject='Tenant',obj=None):
 r={'sourceContext':context,'predicate':predicate,'subject':subject}
 if obj is not None:r['object']=obj
 return r

def recall_program(name,r,port='request',null=False):
 return {'name':name,'nodes':[{'id':'request','type':'json.value','params':{'value':'null' if null else encode(r).decode()}},{'id':'recall','type':'nal.recall','params':{'mode':'exact-role','request':encode(role(source)).decode()}}],'wires':[{'from':['request','value'],'to':['recall',port]}],'controls':{'humanOversight':True,'matingPoints':[]}}
def attend_program(name,pid,p):return {'name':name,'nodes':[{'id':'attend','type':'nal.attend','params':{'angular':angular,'propositionCid':pid,'p':str(p)}}],'wires':[],'controls':{'humanOversight':True,'matingPoints':[]}}

def run(label,document,success=True):
 before=state(label+'-before')
 if label=='pays-primary-structured':
  (out/'primary-document.json').write_text(json.dumps(document,indent=2)+'\n')
  subprocess.run(['node',str(Path(__file__).with_name('browser-primary.cjs'))],check=True,timeout=180)
  native=json.loads((out/'browser-primary-result.json').read_text());record=native['http'];records.append(record)
 else:record=request(label,'/api/lcnc/run',{'name':document['name'],'document':document,'inputs':{}})
 reply=record['response'];assert isinstance(reply,dict)
 if success:assert record['status']==200 and reply['ok'] is True and reply['status']=='completed'
 else:assert record['status']>=400 or reply.get('ok') is False
 complete=reply
 if reply.get('outputCid'):complete=json.loads(read(reply['outputCid'],label+'-full-output'))
 for key in ['programCid','receiptCid','invocationsCid']:
  if reply.get(key):read(reply[key],label+'-'+key)
 after=state(label+'-after');r={'label':label,'document':document,'http':record,'complete':complete,'before':before,'after':after};runs.append(r);return r

def unchanged_signal(before,after,budget=True):
 assert len(before['bagRows'])==len(after['bagRows'])==1
 a,b=before['bagRows'][0],after['bagRows'][0];assert a['signalBase64']==b['signalBase64'] and a['evidence']==b['evidence'] and a['basisBloom']==b['basisBloom']
 if budget:assert a['budget']==b['budget']
 return b

def selection(run):return run['complete']['outputs']['recall']['selection']
try:
 meta=request('meta','/__v83/meta')['response'];source=meta['sourceC2']['cid'];states.append({'label':'startup','state':meta['baseline']});assert meta['baseline']['bagSize']==0
 c2=(out/'inputs/C2.kif').read_bytes();assert digest(c2)==source
 imported=request('manual-C2-real-KG-intake','/api/beliefs/kg',c2);assert imported['status']==409;assert imported['response']['admission']['issue']=='PROPOSITION_MISMATCH';assert imported['response']['processing']=='earlier-statements-may-have-been-processed'
 baseline=state('after-partial-C2-intake');assert baseline['bagSize']==1;initial=baseline['bagRows'][0];angular=initial['angular'];pays_pid=initial['propositionCid'];signal_bytes=base64.b64decode(initial['signalBase64']);assert digest(signal_bytes)[7:]==initial['signalSha256'];read(source,'C2-exact-source');read(pays_pid,'C2-pays-definition')
 primary=recall_program('v83-pays-primary',role(source))
 primary['nodes'] += [
  {'id':'angular','type':'confix.pickPath','x':800,'y':100,'params':{'path':'matches.0.angular','geometry':'kotlin'}},
  {'id':'pid','type':'confix.pickPath','x':800,'y':390,'params':{'path':'matches.0.propositionCid','geometry':'kotlin'}},
  {'id':'attend','type':'nal.attend','x':1150,'y':100,'params':{'p':'.95'}},
  {'id':'selection','type':'display','x':400,'y':600,'params':{}},
  {'id':'acknowledgement','type':'display','x':1500,'y':100,'params':{}},
  {'id':'instructions','type':'note','x':40,'y':20,'params':{'text':'Manual KIF claims; exact one-source lexical selection. Explicit Run performs read-only selection, then a separate wired attention node targets ONLY the unique exact resident through typed id outputs. Budget only; no evidence or truth update. Confix is inspection only.'}}]
 primary['nodes'][0].update(x=40,y=150);primary['nodes'][1].update(x=400,y=150)
 primary['wires'] += [{'from':['recall','selection'],'to':[id,'json?']} for id in ['angular','pid']]+[{'from':['recall','angular'],'to':['attend','angular']},{'from':['recall','propositionCid'],'to':['attend','propositionCid']},{'from':['attend','attended'],'to':['acknowledgement','x']},{'from':['recall','selection'],'to':['selection','x']}]
 first=run('pays-primary-structured',primary);s=selection(first);assert s['status']=='MATCHES_IN_COMPLETE_SOURCE' and s['complete'] is True and s['definitions']==2 and s['persistence']=='request-local';assert s['source']['quote']==c2.decode();m=s['matches'];assert len(m)==1 and m[0]['residentStatus']=='MATCH_RESIDENT' and m[0]['predicate']=='pays' and m[0]['subject']=='Tenant' and m[0]['object']=='Landlord' and m[0]['propositionCid']==pays_pid;assert len(first['complete']['outputs']['recall']['beliefs'])==1;unchanged_signal(first['before'],first['after'],False)
 assert first['complete']['outputs']['recall']['angular']==angular and first['complete']['outputs']['recall']['propositionCid']==pays_pid
 att=first;a=att['complete']['outputs']['attend']['attended'];assert a['processed'] is True and a['propositionCid']==pays_pid and a['identityScope']=='exact-resident-proposition';unchanged_signal(att['before'],att['after'],False);assert att['before']['bagRows'][0]['budget']['packed']!=att['after']['bagRows'][0]['budget']['packed']
 duplicate=run('duplicate-pays-attention',attend_program('v83-attend-repeat',pays_pid,.95));assert duplicate['complete']['outputs']['attend']['attended']['changed'] is False;unchanged_signal(duplicate['before'],duplicate['after'])
 repeated=run('pays-repeat-selection',recall_program('v83-pays-repeat',role(source)));unchanged_signal(repeated['before'],repeated['after']);assert selection(repeated)['matches'][0]['propositionCid']==pays_pid
 owes=run('owes-documentary-mismatch',recall_program('v83-owes-documentary',role(source,'owes'),port='request?'));o=selection(owes);assert o['status']=='MATCHES_IN_COMPLETE_SOURCE' and o['complete'] is True;assert len(o['matches'])==1;om=o['matches'][0];assert om['residentStatus']=='RESIDENT_PID_MISMATCH' and om['angular']==angular and om['propositionCid']!=pays_pid and owes['complete']['outputs']['recall']['beliefs']==[];owes_pid=om['propositionCid'];read(owes_pid,'C2-owes-definition');unchanged_signal(owes['before'],owes['after'])
 null_target=recall_program('v83-null-typed-target-stale-authored',role(source,'owes'))
 null_target['nodes'].append({'id':'attend','type':'nal.attend','params':{'angular':angular,'propositionCid':pays_pid,'p':'.2'}})
 null_target['wires'] += [{'from':['recall','angular'],'to':['attend','angular']},{'from':['recall','propositionCid'],'to':['attend','propositionCid']}]
 guard=run('typed-null-target-no-authored-fallback',null_target);assert guard['complete']['outputs']['recall']['angular'] is None and guard['complete']['outputs']['recall']['propositionCid'] is None
 assert guard['complete']['outputs']['attend']['attended']=={'error':'angular required'};unchanged_signal(guard['before'],guard['after'])
 mismatch=run('owes-attention-writer-refusal',attend_program('v83-attend-wrong-PID',owes_pid,.99),False);unchanged_signal(mismatch['before'],mismatch['after']);assert mismatch['after']['lastAdmissionRefusal']['issue']=='PROPOSITION_MISMATCH'
 reversed_=run('reversed-role-no-match',recall_program('v83-reversed-roles',role(source,subject='Landlord',obj='Tenant')));s=selection(reversed_);assert s['status']=='NO_MATCH_IN_COMPLETE_SOURCE' and s['complete'] is True and s['matches']==[];unchanged_signal(reversed_['before'],reversed_['after'])
 null=run('present-null-no-fallback',recall_program('v83-present-null',role(source),port='request?',null=True),False);unchanged_signal(null['before'],null['after'])
 for name,status in [('unsupported.kif','UNSUPPORTED_SOURCE_PROFILE'),('missing-definition.kif','UNVERIFIED_SOURCE'),('bounded-65.kif','BOUNDED')]:
  fixture=meta['negativeFixtures'][name];read(fixture['sourceCid'],name+'-raw-source')
  for cid in fixture['definitionCids']:read(cid,name+'-retained-definition')
  if fixture.get('expectedMissingDefinitionCid'):
   from urllib.parse import quote
   missing=request('missing-unrelated-definition-block','/api/v0/block/get?arg='+quote(fixture['expectedMissingDefinitionCid']));assert missing['status']==404
  r=run(name.split('.')[0]+'-incomplete-control',recall_program('v83-'+name.split('.')[0],role(fixture['sourceCid'])));s=selection(r);assert s['status']==status and s['complete'] is False and s['matches']==[];assert r['complete']['outputs']['recall']['beliefs']==[];unchanged_signal(r['before'],r['after'])
 lowered=run('explicit-lower-priority-for-eviction',attend_program('v83-attend-low-priority',pays_pid,.1));unchanged_signal(lowered['before'],lowered['after'],False)
 tick=request('public-decay-eviction-tick','/api/beliefs/tick',{});assert tick['status']==200;evicted=state('after-public-tick-eviction');assert evicted['bagSize']==0
 absent=run('evicted-documentary-selection',recall_program('v83-evicted-selection',role(source)));s=selection(absent);assert len(s['matches'])==1 and s['matches'][0]['residentStatus']=='MATCH_NOT_RESIDENT';assert absent['complete']['outputs']['recall']['beliefs']==[] and absent['after']['bagSize']==0
 revival=run('evicted-attention-writer-refusal',attend_program('v83-attend-evicted',pays_pid,.99),False);assert revival['after']['bagSize']==0 and revival['after']['lastAdmissionRefusal']['issue']=='RESIDENT_REQUIRED'
 read('sha256:'+initial['signalSha256'],'actual-evicted-SignalCodec-spill');assert read(source,'C2-source-final')==c2;assert digest(read(pays_pid,'C2-pays-definition-final'))==pays_pid;assert digest(read(owes_pid,'C2-owes-definition-final'))==owes_pid
 primitive=json.loads((out/'primitive-boundaries.json').read_text())
 for entry in primitive:
  assert entry['before']['pack']==entry['after']['pack'], 'Registered selection/attention delegate must not write CAS'
  if entry['kind']=='nal.recall':assert entry['before']==entry['after'], 'Selection must preserve bag budget/signal and belief WAL'
  elif entry.get('refusal'):assert entry['before']==entry['after'], 'Refused attention must preserve bag/WAL'
  else:
   if 'error' in entry['output'].get('attended',{}):assert entry['before']==entry['after'], 'Null typed identity must not reach writer/authored fallback'
   else:assert entry['before']['bagRows'][0]['signalBase64']==entry['after']['bagRows'][0]['signalBase64']
 final=state('protocol-complete');assert final['bagSize']==0 and final['beliefBagPresent'] is True and not final['kifBankPresent'] and not final['narsRetePresent'] and final['guestInstalled']==[] and final['guestMounted']==[] and not final['modelEndpointsPresent'] and final['configuredModelCount']==0
 (out/'readback-index.json').write_text(json.dumps(reads,indent=2)+'\n');(out/'http-result.json').write_text(json.dumps({'result':'PASS','meta':meta,'requests':records,'states':states,'runs':runs,'partialIntake':imported,'initialResident':initial,'eviction':{'tick':tick,'after':evicted},'final':final,'reads':reads,'primitiveBoundaries':primitive,'scope':'Manual KIF partial intake, request-local selection and explicit separate attention via real registered LCNC/HTTP owners. No parser/English/legal entailment/model/automatic admission.'},indent=2)+'\n')
except Exception as e:
 import traceback
 (out/'http-failure.json').write_text(json.dumps({'error':str(e),'stack':traceback.format_exc(),'requests':records,'states':states,'runs':runs,'reads':reads},indent=2)+'\n');raise
