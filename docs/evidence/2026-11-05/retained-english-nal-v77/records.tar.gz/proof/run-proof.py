#!/usr/bin/env python3
"""Direct production CLI subprocess records. Requires a separate explicit root GO; no observer overlay."""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, time, urllib.parse

ROOT = pathlib.Path(__file__).resolve().parent
MAIN = 'borg.trikeshed.narsese.SyntheticNalExperimentCli'

def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def fp(path):
    p = pathlib.Path(path)
    if not p.exists():
        return {'path': str(p), 'exists': False}
    return {'path': str(p), 'exists': True, 'bytes': p.stat().st_size,
            'sha256': sha(p), 'mtimeMillis': p.stat().st_mtime_ns // 1000000}

def snapshot(path, source, main):
    path = pathlib.Path(path).resolve()
    assert (path / 'source-head.txt').read_text().strip() == source
    assert sha(path / 'main.jar') == main
    cp = (path / 'classpath.txt').read_text().strip().split(os.pathsep)
    assert len(cp) == 120 and pathlib.Path(cp[0]).resolve() == path / 'main.jar'
    assert all(pathlib.Path(p).is_file() and pathlib.Path(p).suffix == '.jar' for p in cp)
    manifest = json.loads((path / 'sha256.json').read_text())
    hashes = {p: sha(p) for p in cp}
    assert hashes[cp[0]] == main
    assert all(hashes[p] == manifest['dependencies'][p] for p in cp[1:])
    return {'path': str(path), 'sourceHead': source, 'mainJarSha256': main,
            'classpath': cp, 'jarSha256': hashes, 'classpathEntries': len(cp)}

def state(inputs):
    packs = {k: fp(pathlib.Path(v['copyRoot']) / 'cas/pack') for k, v in inputs['runtimes'].items()}
    originals = {k: fp(pathlib.Path(v['originalRoot']) / 'cas/pack') for k, v in inputs['runtimes'].items() if 'originalRoot' in v}
    trees = {}
    references = {}
    for key, runtime in inputs['runtimes'].items():
        for role, field in [('copy', 'copyRoot'), ('producer', 'originalRoot')]:
            if field not in runtime:
                continue
            root = pathlib.Path(runtime[field])
            trees[key + '-' + role] = {str(p.relative_to(root)): fp(p) for p in sorted(root.rglob('*')) if p.is_file()}
        for record in runtime.get('packRecords', []):
            if record['kind'] == 'REF':
                references[record['target']] = fp(record['target'])
    return {'packs': packs, 'originalPacks': originals, 'runtimeTrees': trees, 'referenceTargets': references}

def origins(log, expected):
    found = {}
    scope = {MAIN, 'borg.trikeshed.narsese.SyntheticNalExperiment', 'borg.trikeshed.narsese.Nal',
             'borg.trikeshed.narsese.DerivationReceipt', 'borg.trikeshed.narsese.NlpcoreAxiomatics',
             'borg.trikeshed.rdf.EnglishObservationGraph', 'borg.trikeshed.job.PackCasStore'}
    for line in log.read_text(errors='replace').splitlines():
        match = re.search(r'(borg\.trikeshed\.[^ ]+) source: (file:[^ ]+)', line)
        if match and match.group(1) in scope:
            path = pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(match.group(2)).path)).resolve()
            assert path == pathlib.Path(expected)
            found[match.group(1)] = {'source': match.group(2), 'recordedLine': line}
    assert MAIN in found
    return found

def requested_cas(cli_args):
    if '--cas' not in cli_args:
        return None
    at = cli_args.index('--cas')
    if at + 1 >= len(cli_args):
        return None
    path = pathlib.Path(cli_args[at + 1])
    return {'path': str(path), 'exists': path.exists(), 'isDirectory': path.is_dir(), 'pack': fp(path / 'pack')}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--new-snapshot', required=True)
    parser.add_argument('--new-source', required=True)
    parser.add_argument('--new-main-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--java', default=shutil.which('java'))
    args = parser.parse_args()
    if os.environ.get('ROOT_V77_GO') != '1':
        raise SystemExit('HOLD: ROOT_V77_GO=1 and frozen green artifact pins required; no CLI subprocess started')
    inputs = json.loads((ROOT / 'inputs.json').read_text())
    old = snapshot(inputs['oldSnapshot'], '0219223a3846887fe283b93598942de332214cd2',
                   'd0a8133b10e4b18e1bd4076c1440688ad94a2eeb2bbcdefe743f4759ace75636')
    new = snapshot(args.new_snapshot, args.new_source, args.new_main_sha256)
    out = pathlib.Path(args.output).resolve(); out.mkdir(exist_ok=False)
    result = {'kind': 'retained-nal-cli-execution/1', 'state': 'RUNNING', 'inputsSha256': sha(ROOT / 'inputs.json'),
              'pins': {'old': old, 'new': new, 'java': fp(args.java)}, 'commands': []}
    def save():
        (out / 'execution.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    save()
    def command(label, artifact, cli_args, expected_status=None, refusal=False):
        folder = out / label; folder.mkdir()
        before = state(inputs)
        requested_before = requested_cas(cli_args)
        stdout = folder / 'stdout.json'; stderr = folder / 'stderr.txt'; loads = folder / 'class-load.log'
        argv = [args.java, '-Xmx512m', '-Xlog:class+load=info:file=' + str(loads),
                '-cp', os.pathsep.join(artifact['classpath']), MAIN] + cli_args
        started = time.monotonic()
        timed_out = False; forced_kill = False
        with stdout.open('wb') as output, stderr.open('wb') as error:
            process = subprocess.Popen(argv, stdout=output, stderr=error)
            try:
                exit_code = process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                timed_out = True; forced_kill = True
                process.kill(); process.wait(); exit_code = process.returncode
        after = state(inputs)
        requested_after = requested_cas(cli_args)
        record = {'label': label, 'argv': argv, 'pid': process.pid, 'exitCode': exit_code,
                  'timedOut': timed_out, 'forcedKill': forced_kill,
                  'elapsedSeconds': time.monotonic() - started, 'stdoutPath': str(stdout), 'stderrPath': str(stderr),
                  'classLoadPath': str(loads), 'stdout': fp(stdout), 'stderr': fp(stderr),
                  'packBefore': before['packs'], 'packAfter': after['packs'],
                  'originalPackBefore': before['originalPacks'], 'originalPackAfter': after['originalPacks'],
                  'sourceAndREFBefore': before, 'sourceAndREFAfter': after,
                  'requestedCasBefore': requested_before, 'requestedCasAfter': requested_after,
                  'productionClassOrigins': origins(loads, pathlib.Path(artifact['path']) / 'main.jar')}
        result['commands'].append(record); (folder / 'record.json').write_text(json.dumps(record, indent=2) + '\n'); save()
        assert before == after, label + ': historical input or canonical producer changed'
        assert requested_before == requested_after, label + ': requested CAS path changed'
        assert not timed_out and not forced_kill, label + ': timeout is not a refusal'
        if refusal:
            reasons = {'bad-missing-flag': 'Usage: SyntheticNalExperimentCli',
                       'bad-duplicate-flag': 'Usage: SyntheticNalExperimentCli',
                       'bad-manual-input': 'Usage: SyntheticNalExperimentCli',
                       'bad-cid': 'ContentId must be',
                       'missing-receipt': 'Retained English source or receipt unavailable',
                       'missing-pack': 'Existing readable CAS pack required',
                       'torn-tail': 'Historical CAS pack has a torn header'}
            error = stderr.read_text()
            assert exit_code == 1 and stdout.stat().st_size == 0 and 'IllegalArgumentException' in error and reasons[label] in error, label
            return None
        assert exit_code == 0, label + ': see raw stderr'
        report = json.loads(stdout.read_text())
        if expected_status:
            assert report['kind'] == 'retained-nal-implication-report/1'
            assert report['status'] == expected_status and report['mode'] == 'historical-snapshot'
            assert report['currentness'] == 'not-checked' and report['parserExecution'] == 'not-reverified'
            assert report['admission'] == 'not-performed'
        return report
    command('zeroarg-old-v76', old, [])
    command('zeroarg-new-v77', new, [])
    old_bytes = (out / 'zeroarg-old-v76/stdout.json').read_bytes()
    new_bytes = (out / 'zeroarg-new-v77/stdout.json').read_bytes()
    result['zeroArgBytesEqual'] = old_bytes == new_bytes
    assert result['zeroArgBytesEqual']
    cases = {case['id']: case for case in inputs['cases']}
    for name in ('S12', 'G01', 'G03', 'G04', 'G13'):
        case = cases[name]; cas = str(pathlib.Path(inputs['runtimes'][case['runtimeKey']]['copyRoot']) / 'cas')
        report = command(name, new, ['--cas', cas, '--inspection', case['inspectionCid']], case['expectedStatus'])
        assert report['source']['inspectionCid'] == case['inspectionCid']
        assert report['source']['extractedTextCid'] == case['sourceCid']
        if name != 'S12':
            assert report['premises'] == [] and report['derivations'] == [] and report['attemptedPairs'] == 0
            continue
        premises = report['premises']; derived = report['derivations']
        assert len(premises) == 4 and sum(len(p['occurrences']) for p in premises) == 5 and report['attemptedPairs'] == 12
        assert sorted(len(p['occurrences']) for p in premises) == [1, 1, 1, 2]
        basis = sorted(set([report['source']['originalCid'], report['source']['extractedTextCid']]))
        assert all(p['basis'] == basis and p['positive'] == 900 and p['negative'] == 0 for p in premises)
        assert len(derived) == 3 and all(d['basis'] == basis for d in derived)
        labels = {term['cid']: term['surface'] for term in report['terms']}
        shapes = {(d['rule'], labels[d['subjectCid']], labels[d['predicateCid']], d['status']) for d in derived}
        assert shapes == {('DEDUCTION', 'ALPHA', 'GAMMA', 'deduced-hypothesis'),
                          ('INDUCTION', 'DELTA', 'GAMMA', 'weak-induction-hypothesis'),
                          ('INDUCTION', 'GAMMA', 'DELTA', 'weak-induction-hypothesis')}
        cids = {p['contributionCid'] for p in premises}
        assert all(set(d['premiseCids']).issubset(cids) for d in derived)
        result['S12'] = {'occurrences': 5, 'premises': 4, 'attemptedPairs': 12, 'derivations': 3,
                         'frameCid': report['frameCid'], 'evaluatorCid': report['evaluatorCid'],
                         'duplicateInflation': False, 'recursion': False, 'fullSourceBasis': basis}
    cas = str(pathlib.Path(inputs['runtimes']['remaining']['copyRoot']) / 'cas')
    missing = 'sha256:' + '0' * 64
    command('bad-missing-flag', new, ['--cas', cas], refusal=True)
    command('bad-duplicate-flag', new, ['--cas', cas, '--cas', cas], refusal=True)
    command('bad-manual-input', new, ['--cas', cas, '--input', 'manual.json'], refusal=True)
    command('bad-cid', new, ['--cas', cas, '--inspection', 'sha256:invalid'], refusal=True)
    command('missing-receipt', new, ['--inspection', missing, '--cas', cas], refusal=True)
    absent = out / 'must-not-be-created'
    command('missing-pack', new, ['--cas', str(absent), '--inspection', cases['S12']['inspectionCid']], refusal=True)
    assert not absent.exists()
    torn = str(pathlib.Path(inputs['runtimes']['torn']['copyRoot']) / 'cas')
    command('torn-tail', new, ['--cas', torn, '--inspection', cases['S12']['inspectionCid']], refusal=True)
    result['state'] = 'PASS'; result['scope'] = 'Actual direct production CLI calls only; no fresh parser, gold input, KIF, observer overlay, currentness or source-independence claim'
    save()
    print(json.dumps({'result': 'PASS', 'path': str(out), 'commands': len(result['commands']), 'zeroArgBytesEqual': True, 'S12': result['S12']}))

if __name__ == '__main__':
    main()
